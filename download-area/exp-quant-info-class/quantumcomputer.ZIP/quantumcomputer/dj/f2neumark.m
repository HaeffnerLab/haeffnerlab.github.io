th=1/sqrt(2)*pi;
dp=acos(cos(th)*(1+cos(2*th))/(sin(th)*sin(2*th)))/pi;
po= 0.02785;
%po=0;

fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('Case 2: itproj(Ublue(1/sqrt(2),po)*Ublue(2/sqrt(2),dp+po)*Ublue(1/sqrt(2),po)\n   *Ucar(0.5,dp)*Ucar(1,0.5+dp)*Ucar(0.5,1+dp)\n   *(Ublue(1/sqrt(2),po+1)*Ublue(2/sqrt(2),dp+po+1)*Ublue(1/sqrt(2),po+1))\n');
fprintf('---------------------------------------------------------------------------------------------\n');

UBob=itproj(Ublue(1/sqrt(2),po)*Ublue(2/sqrt(2),dp+po)*Ublue(1/sqrt(2),po)...
   *Ucar(0.5,0)*Ucar(1,0.5)*Ucar(0.5,1)...
   *(Ublue(1/sqrt(2),po+1)*Ublue(2/sqrt(2),dp+po+1)*Ublue(1/sqrt(2),po+1)));
fprintf('Implemented function: \n')
%Num2str(Umhad'*itproj(Uexpswap*Ucar(1,0.303)*Uexpswap)*Umhad,'%7.2f')
Umhad'*UBob*Umhad
fprintf('Complete Alg.:\n')
itproj(Ucar(0.5,0))*UBob*itproj(Ucar(0.5,1))
