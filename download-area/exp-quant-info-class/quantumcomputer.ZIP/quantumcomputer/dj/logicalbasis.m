function ba=logicalbasis

       %0s 1s 0d 1d
ba=   [	0  1  0  0;  %  00 Basistrafo for 1->S and motinal 1 -> 0 Phonons 
	   	1  0  0  0;  %  01
         0  0  0  1;  %  10 
         0  0  1  0;];%  11;
      
%ba=eye(4);