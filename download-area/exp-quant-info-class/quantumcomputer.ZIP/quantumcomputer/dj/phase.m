clear T;
clear Y;
clear pulse;

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi*25e3;
parameters.sbomegacarrier=2*pi*155e3;

parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;


%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%****************** Pulse definition  ***********************%

%  Rcarrier(theta,phi,ion,transition,fp,time)
%     Rblue(theta,phi,ion,transition,fp,time)

%p = p + 1;[pulse(p),time] = Rcarrier(0.5,0,1,1,fxpa,time+12*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,1,1,fxpa,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0.5,1,1,fxpa,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,1,1,fxpa,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0.5,1,1,fxpa,time+0*delayunit); 

%p = p + 1;[pulse(p),time] = Rcarrier(0.5,1,1,1,fxpa,time+(28)*delayunit); 


%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0; 1],hspace);
endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
hold on;
%************* and now plot some data ************************************%

dat=read_data('p:\daten\20020711\qf0317',3);
plot(dat(1,:),dat(2,:),'k.');

mean(dat(2,86:101))
std(dat(2,86:101))/sqrt(101-86)
