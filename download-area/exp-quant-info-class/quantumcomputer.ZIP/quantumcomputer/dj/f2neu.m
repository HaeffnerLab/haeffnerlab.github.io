fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('Case 2: Ucar(1,1)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5) \n       *Ucar(1,0)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5) \n')
fprintf('---------------------------------------------------------------------------------------------\n');

UBob=itproj(Ucar(1,1)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)...
           *Ucar(1,0)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5));
%UBob=Umhad*[0 1 0 0; 1 0 0 0; 0 0 0 1; 0 0 1 0]*Umhad';
fprintf('Implemented function: \n')
%Num2str(Umhad'*itproj(Uexpswap*Ucar(1,0.303)*Uexpswap)*Umhad,'%7.2f')
Umhad'*UBob*Umhad
fprintf('Complete Alg.:\n')
Uehad*UBob*Uehad'
