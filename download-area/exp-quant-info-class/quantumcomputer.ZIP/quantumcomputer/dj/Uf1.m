%

function u = Uf1
sma = zeros(4,4);
sma(1,1) = 1;
sma(2,2) = 1;
sma(3,3) = 1;
sma(4,4) = 1;

% sigma-minus otimes 

u = sma;

