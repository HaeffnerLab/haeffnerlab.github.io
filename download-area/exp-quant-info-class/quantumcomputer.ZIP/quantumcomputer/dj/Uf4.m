function u = Uf4

sma = zeros(4,4);
sma(4,3) = 1;

sma=sma+sma';

sma(1,1) = 1;
sma(2,2) = 1;

u = sma;

