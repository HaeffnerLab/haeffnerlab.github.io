
dispabsmat(Ublue(1,0,adr2)*Ublue(0.12,1.2,adr2)*Ucar(0.5,0,adr1)*Ublue(1,0,adr1)*Ublue(1/sqrt(2),0.5,adr1)*Ublue(1,0,adr1)*Ublue(1/sqrt(2),0.5,adr1)*Ucar(0.5,1,adr1)*Ublue(0.1,1.2,adr2)*Ublue(1,1,adr2),3)
dispabsmat(Ublue(3.4,0.5,[1 0.5]))