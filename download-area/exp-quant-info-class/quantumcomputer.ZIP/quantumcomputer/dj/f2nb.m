th=1/sqrt(2)*pi;
dp=acos(cos(th)*(1+cos(2*th))/(sin(th)*sin(2*th)))/pi
po= 0.02785;

fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('Case 2: Ublue(1/sqrt(2),po)*Ublue(2/sqrt(2),dp+po)*Ublue(1/sqrt(2),po)\n   *Ucar(1,dp)\n   *(Ublue(1/sqrt(2),po)*Ublue(2/sqrt(2),dp+po)*Ublue(1/sqrt(2),po)) \n')
fprintf('---------------------------------------------------------------------------------------------\n');

UBob=itproj(Ublue(1/sqrt(2),po)*Ublue(2/sqrt(2),dp+po)*Ublue(1/sqrt(2),po)...
   *Ucar(1,dp)...
   *(Ublue(1/sqrt(2),po)*Ublue(2/sqrt(2),dp+po)*Ublue(1/sqrt(2),po)));
fprintf('Implemented function: \n')
%Num2str(Umhad'*itproj(Uexpswap*Ucar(1,0.303)*Uexpswap)*Umhad,'%7.2f')

      
round(inv(logicalbasis)*Umhad*UBob*Umhad'*logicalbasis*1000)/1000
fprintf('Complete Alg.:\n')
round(inv(logicalbasis)*Uephad*UBob*Uephad'*logicalbasis*1000)/1000
      