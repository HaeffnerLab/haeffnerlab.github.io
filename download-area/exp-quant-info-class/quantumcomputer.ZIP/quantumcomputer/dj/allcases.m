


case1;
states=[index(0,[1],hspace),...
        index(1,[1],hspace),...
     	  index(2,[1],hspace)];

TI(1,:)=T;
EP(1,:)=(abs(Y(:,states(1))).^2+abs(Y(:,states(2))).^2+abs(Y(:,states(3))).^2)';
D(1,1:size(dat,1),1:size(dat,2))=dat;

case2;
TI(2,:)=T;
EP(2,:)=(abs(Y(:,states(1))).^2+abs(Y(:,states(2))).^2+abs(Y(:,states(3))).^2)';
D(2,1:size(dat,1),1:size(dat,2))=dat;

case3;
TI(3,:)=T;
EP(3,:)=(abs(Y(:,states(1))).^2+abs(Y(:,states(2))).^2+abs(Y(:,states(3))).^2)';
D(3,1:size(dat,1),1:size(dat,2))=dat;

case4;
TI(4,:)=T;
EP(4,:)=(abs(Y(:,states(1))).^2+abs(Y(:,states(2))).^2+abs(Y(:,states(3))).^2)';
D(4,1:size(dat,1),1:size(dat,2))=dat;

figall