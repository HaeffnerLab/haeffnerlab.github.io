fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('Case 4: Ucar(1,0)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ucar(1,1)\n');
fprintf('---------------------------------------------------------------------------------------------\n');
UBob=itproj(Ucar(1,0)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ucar(1,1));
fprintf('Implemented function:  \n')
%Num2str(Umhad'*itproj(Uexpswap*Ucar(1,0.303)*Uexpswap)*Umhad,'%7.2f')

       
round(inv(logicalbasis)*UmRy'*UBob*UmRy*logicalbasis*1000)/1000
fprintf('Complete Alg.:\n')
round(inv(logicalbasis)*itproj(Ucar(0.5,0))*UBob*itproj(Ucar(0.5,1))*logicalbasis*1000)/1000
      