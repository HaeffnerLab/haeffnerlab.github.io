%

function u = Uf2
sma = zeros(4,4);
sma(4,3) = 1;
sma(2,1) = 1;

sma=sma-sma';
% sigma-minus otimes 
sma(3,4)=1;
sma(1,2)=1;

u = sma;

