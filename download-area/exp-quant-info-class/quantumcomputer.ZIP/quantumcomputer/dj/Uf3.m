%

function u = Uf3

sma = zeros(4,4);
sma(2,1) = 1;

sma=sma+sma';

sma(3,3) = 1;
sma(4,4) = 1;
% sigma-minus otimes 

u = sma;

