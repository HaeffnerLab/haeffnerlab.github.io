fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('Case 3: Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5)\n');
fprintf('---------------------------------------------------------------------------------------------\n');

UBob=itproj(Ublue(1/sqrt(2),0)*Ublue(1,0.5)*Ublue(1/sqrt(2),0)*Ublue(1,0.5));
fprintf('Implemented function: \n')
      
round(inv(logicalbasis)*UmRy'*UBob*UmRy*logicalbasis*1000)/1000
fprintf('Complete Alg.:\n')
round(inv(logicalbasis)*itproj(Ucar(0.5,0))*UBob*itproj(Ucar(0.5,1))*logicalbasis*1000)/1000
      