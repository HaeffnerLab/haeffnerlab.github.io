f=figure(1);
hold on;
clf;

alice1(1,:) = [14 14+11];
alice2(1,:) = [225 225+11];
bob(1,:) = [0];
alice1(2,:) = [10 10+10];
alice2(2,:) = [233 233+10];
bob(1) = [0];
alice1(3,:) = [12 12+11];
alice2(3,:) = [240 240+11];
bob(1) = [0];
alice1(4,:) = [12 12+11];
alice2(4,:) = [242 242+11];
bob(1) = [0];


for i0=1:4
	ax=subplot(4,1,i0);
	set(ax,'xtick',0);
	set(ax,'LineWidth',1)
   set(ax,'FontSize',12);
   hold on;     
   p1=plot(TI(i0,:),EP(i0,:),'k-');
   set(p1,'LineWidth',1.5)
   p1=plot(squeeze(D(i0,1,:)),squeeze(D(i0,2,:)),'k.');
   set(p1,'MarkerSize',14)
   axis([0 275 -0.0 1.0])
   set(ax,'Box','on')
   s=sprintf('Case %d',i0);
   te=text(248,0.67,s);
   set(te,'FontSize',12);
   
  % li=line([alice1(i0,1),alice1(i0,1),],[0 1.005]);
%   set(li,'LineWidth',1)
 %  	set(li,'LineStyle','--')
   li=line([alice1(i0,2),alice1(i0,2),],[0 1.005]);
   set(li,'LineWidth',1)
      set(li,'LineStyle','--')
      set(li,'Color',[ 0 0 0 ])
   li=line([alice2(i0,1),alice2(i0,1),],[0 1.005]);
   set(li,'LineWidth',1)
      set(li,'LineStyle','--')
      set(li,'Color',[ 0 0 0 ])

      %  li=line([alice2(i0,2),alice2(i0,2),],[0 1.005]);
  % set(li,'LineWidth',1)
   %   set(li,'LineStyle','--')
end;
set(ax,'xtick',[0:25:275]);
l=xlabel('Time (\mus)');
set(l,'FontSize',13);
l=ylabel('D_{5/2} population');
set(l,'FontSize',13);

print -dps figall