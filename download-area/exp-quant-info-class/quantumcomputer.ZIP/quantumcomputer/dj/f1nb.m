fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('Case 1: UBob = Ucar(0,0) \n')
fprintf('---------------------------------------------------------------------------------------------\n');

UBob=itproj(Ucar(0,0));
fprintf('Implemented function: logicalbasis^-1*Umhad*UBob*Umhad+*logicalbasis \n')
%Num2str(Umhad'*itproj(Uexpswap*Ucar(1,0.303)*Uexpswap)*Umhad,'%7.2f')

 logicalbasis=[	0  0  0  1;  %  00 logicalbasistrafo for 1->S and motinal 1 -> 0 Phonons 
	   	0  0 -1  0;  %  01
         0  1  0  0;  %  10 
        -1  0  0  0;];%  11;
      
      
%      logicalbasis=eye(4);
      
round(inv(logicalbasis)*Umhad*UBob*Umhad'*logicalbasis*1000)/1000
fprintf('Complete Alg.: logicalbasis^-1*Uehad*UBob*Uehad+*logicalbasis\n')
round(inv(logicalbasis)*Uephad*UBob*Uephad'*logicalbasis*1000)/1000
      