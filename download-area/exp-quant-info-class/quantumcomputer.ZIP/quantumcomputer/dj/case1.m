clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,1);

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*160e3;
%*****************************************************************************%
parameters=recalculateparameters(parameters);


%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;


%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

%****************** Pulse definition  ***********************%
%  Rcarrier(theta,phi,ion,transition,fp,time)
%     Rblue(theta,phi,ion,transition,fp,time)
time+14*delayunit
p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+14*delayunit); 
time+(200)*delayunit
p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+(200)*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0; 1],hspace);
endpopulations(T,Y,hspace)
tracedpopulations(T,Y,hspace,1);
hold on;
%*****************************************************************************%

%******** And to something completely different: the real data ***************%
dat=read_data('p:\daten\20020711\qf1423',3);
plot(dat(1,:),dat(2,:),'k.');
%*****************************************************************************%

%****************And now evaluate the fidelity    ************************%
range=74:81;
mean(dat(2,range))
std(dat(2,range))/sqrt(length(range))
%*****************************************************************************%