fprintf('---------------------------------------------------------------------------------------------\n');
fprintf('Case 1: UBob = Ucar(0,0) \n')
fprintf('---------------------------------------------------------------------------------------------\n');

UBob=itproj(Ucar(0,0));
fprintf('Implemented function: Umhad+*UBob*Umhad \n')
%Num2str(Umhad'*itproj(Uexpswap*Ucar(1,0.303)*Uexpswap)*Umhad,'%7.2f')
Umhad'*UBob*Umhad
fprintf('Complete Alg.: Uehad*UBob*Uehad+\n')
Uephad*UBob*Uephad'