path(path,[cd,filesep,'qctools']);
path(path,[cd,filesep,'normal']);
type qcini.txt
global hspace;
global messagehandle;
messagehandle=0;
global fastproj
fastproj=0;
hspace=definehspace
setstatevisibility