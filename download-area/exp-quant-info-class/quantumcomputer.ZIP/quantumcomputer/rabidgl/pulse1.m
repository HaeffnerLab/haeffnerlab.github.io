function p=pulse1(t,piover4time);

delay = (1*13.5) / 1e6; % delay sensitive to 0.1e-6
if t>=(0*piover4time + delay) & t<((1*piover4time) + delay)
   p=1;
else
   p=0;
end;
%p=0;