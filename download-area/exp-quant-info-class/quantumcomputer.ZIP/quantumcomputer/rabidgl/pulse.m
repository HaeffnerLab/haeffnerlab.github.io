function p=pulse(t,delay,length);

if  t>=delay & t<delay+length
   p=1;
else 
   p=0;   
end;
%p=0;