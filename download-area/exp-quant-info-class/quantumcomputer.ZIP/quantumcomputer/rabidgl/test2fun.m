
function v=test2fun(t,x,flag,om,omc,d,D)

om =om/2 ;
omc=omc/2;

a0  = -i*om *exp(+i*  d    *t);
a0c = -i*om *exp(-i*  d    *t);
a1  = -i*omc*exp(+i*(d - D)*t);
a1c = -i*omc*exp(-i*(d - D)*t);
a2  = -i*om *exp(+i*(d-2*D)*t);
a2c = -i*om *exp(-i*(d-2*D)*t);
a02 = a0 * sqrt(2);
a02c= a0c* sqrt(2);
a22 = a2 * sqrt(2);
a22c= a2c* sqrt(2);

A = [0        a2c     a1c      0      0       0  ; 
     a2        0       0       a1     0      a02 ;
     a1        0       0       a0     0       0  ;
     0        a1c     a0c      0     a22c     0  ;
     0         0       0      a22     0       a1 ;
     0        a02c     0       0     a1c      0 ];

v = A*x;
