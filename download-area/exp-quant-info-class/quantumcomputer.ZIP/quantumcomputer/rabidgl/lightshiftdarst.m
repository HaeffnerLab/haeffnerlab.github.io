load lightshiftdarst

	f=figure(1);
   clf
	ax=subplot(3,1,1);
   set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
   pl=plot(T,abs(PYG(:,1)).^2,'b');
   set(pl,'LineWidth',2)
   hold on;   
	pl=plot(T,abs(PYG(:,4)).^2,'r--');
   set(pl,'LineWidth',2)
	h1=sprintf('<0ss|: %1.3f, %4.2f pi',PF(1),PH(1));
	h2=sprintf('<1ss|: %1.3f, %4.2f pi',PF(4),PH(4));
	h=legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])
   
	%ax=subplot(5,1,2);
   %set(ax,'FontSize',13);
   %set(ax,'xtick',0);
   %hold on;   
	%plot(T,abs(PYG(:,7)).^2,'b');
	%plot(T,abs(PYG(:,6)).^2,'r--');
	%h1=sprintf('<0dd|: %1.3f, %4.2f pi',PF(7),PH(7));
	%h2=sprintf('<1dd|: %1.3f, %4.2f pi',PF(6),PH(6));
	%legend(h1,h2,0);
   %ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   %axis([min(T), max(T), 0, 1])
   

	ax=subplot(3,1,2);
   set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
   pl=plot(T,abs(PYG(:,3)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(PYG(:,2)).^2,'r--');
   set(pl,'LineWidth',2)
   h1=sprintf('<0ds|: %1.3f, %4.2f pi',PF(3),PH(3));
	h2=sprintf('<1ds|: %1.3f, %4.2f pi',PF(2),PH(2));
	legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])

	%ax=subplot(5,1,4);
	%set(ax,'FontSize',13);
   %set(ax,'xtick',0);
   %hold on;   
	%plot(T,abs(PYG(:,5)).^2,'b');
	%plot(T,abs(PYG(:,8)).^2,'r--');
	%h1=sprintf('<0sd|: %1.3f, %4.2f pi',PF(5),PH(5));
	%h2=sprintf('<1sd|: %1.3f, %4.2f pi',PF(8),PH(8));
   %legend(h1,h2,0);
   %ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   %axis([min(T), max(T), 0, 1])
   
   
   
 	ax=subplot(3,1,3);
	set(ax,'FontSize',13);
   hold on;   
   pl=plot(T,abs(PYG(:,13)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(PYG(:,14)).^2,'r--');
   set(pl,'LineWidth',2)
   h1=sprintf('<0sd_{hilf}|: %1.3f, %4.2f pi',PF(13),PH(13));
	h2=sprintf('<0sd_{hilf}|: %1.3f, %4.2f pi',PF(14),PH(14));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])

  
   xlabel('Time / \mus','FontSize',18,'FontName','Timesnewroman');
   
   
     R=[1  0  1  0;
      0  1  0 -1;
     -1  0  1  0;
      0  1  0  1;];
   
   E=eye(4);  
   O=zeros(4);
   
   %RT=[[R , O];
   %    [O ,R];];
    
   RT=[[R , R];
       [R ,-R];];
    
   
    
   RO=zeros(21);
   RO(1:8,1:8)=RT/2;
   YP=(RO*Y')';
   
   PFR=YP(length(YP),:).*conj(YP(length(YP),:));
	PHR=angle(YP(length(YP),:))/pi;

   
 	f=figure(10);
   clf
   
   
  	ax=subplot(4,1,1);
	set(ax,'FontSize',13);
   hold on;   
   pl=plot(T,abs(YP(:,1)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(YP(:,4)).^2,'r--');
   set(pl,'LineWidth',2)
	h1=sprintf('<0++|: %1.4f,  %6.4f pi',PFR(1),PHR(1));
	h2=sprintf('<1++|: %1.4f,  %6.4f pi',PFR(4),PHR(4));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1e-4+1.1*max(max(abs(YP(:,1)).^2),max(abs(YP(:,4)).^2))])
   
   
  	ax=subplot(4,1,2);
	set(ax,'FontSize',13);
   hold on;   
   pl=plot(T,abs(YP(:,3)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(YP(:,2)).^2,'r--');
   set(pl,'LineWidth',2)
	h1=sprintf('<0-+|: %1.4f,  %6.4f pi',PFR(3),PHR(3));
	h2=sprintf('<1-+|: %1.4f,  %6.4f pi',PFR(2),PHR(2));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1e-4+1.1*max(max(abs(YP(:,3)).^2),max(abs(YP(:,2)).^2))])



  	ax=subplot(4,1,3);
	set(ax,'FontSize',13);
   hold on;   
   pl=plot(T,abs(YP(:,5)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(YP(:,8)).^2,'r--');
   set(pl,'LineWidth',2)
	h1=sprintf('<0+-|: %1.4f,  %6.4f pi',PFR(5),PHR(5));
	h2=sprintf('<1+-|: %1.4f,  %6.4f pi',PFR(8),PHR(8));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1e-4+1.1*max(max(abs(YP(:,5)).^2),max(abs(YP(:,8)).^2))])
   
   
  	ax=subplot(4,1,4);
	set(ax,'FontSize',13);
   hold on;   
   pl=plot(T,abs(YP(:,7)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(YP(:,6)).^2,'r--');
   set(pl,'LineWidth',2)
	h1=sprintf('<0--|: %1.4f,  %6.4f pi',PFR(7),PHR(7));
	h2=sprintf('<1--|: %1.4f,  %6.4f pi',PFR(6),PHR(6));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1e-4+1.1*max(max(abs(YP(:,7)).^2),max(abs(YP(:,6)).^2))])

  
   
	t=sprintf('Time (10^{-6} s)');
%	t=sprintf('Time [10^{-6} s]\n\nAnfangsbedingungen: %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f    Rabi frequency: %2.0f kHz',y0(1).*conj(y0(1)),y0(2).*conj(y0(2)),y0(3).*conj(y0(3)),y0(4).*conj(y0(4)),y0(5).*conj(y0(5)),y0(6).*conj(y0(6)),y0(7).*conj(y0(7)),y0(8).*conj(y0(8)),omc/2/pi/1000);
   xlabel(t)
   ylabel('Population')
   %print -dwin
   

   
