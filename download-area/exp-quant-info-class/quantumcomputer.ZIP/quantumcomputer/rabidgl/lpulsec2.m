function p=lpulsec1(t,piover4time,rabitime);

delay1=5/1e6;
delay2=(6*14)/1e6;

if  t>=(0*piover4time + delay1) & t<((0*piover4time) + 3/4*rabitime + delay1)
   p=1;
elseif  t>=(1*piover4time + delay2) & t<((1*piover4time) + 1*rabitime/4 + delay2)
   p=0;
else 
   p=0;   
end;
p=0;