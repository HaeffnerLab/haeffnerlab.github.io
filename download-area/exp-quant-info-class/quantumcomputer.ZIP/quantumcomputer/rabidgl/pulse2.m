function p=pulse2(t,piover4time);

delay = (3.5*14) / 1e6; % delay sensitive to 0.1e-6

if t>=(2*piover4time + delay) & t<((6*piover4time) + delay)
   p=1;
else
   p=0;
end;
%p=0;