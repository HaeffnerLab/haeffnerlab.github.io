function p=pulse3(t,piover4time);

delay = (4.2*14)/1e6;
if  t>=(6*piover4time + delay) & t<((7*piover4time) + delay)
   p=1;
else
   p=0;
end;
%p=0;