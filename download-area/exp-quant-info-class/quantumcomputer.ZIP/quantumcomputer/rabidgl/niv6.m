% 17.11.99
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4 -5 - 6
% 1-3,2-4,5-6 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2,4-5   : Kopplung    om  /  sqrt(2)om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

omc = 2*pi*1090e3;
om  = omc*.045;
d   = -2*pi*355e3;  
nu  =  2*pi*1850e3;

%omc = 2*pi*2000e3;
%om  = omc*.2;
%d   = -2*pi*1800e3;  
%nu  =  2*pi*1850e3;

%d=-omc^2/2/nu      % optimale Verstimmung aus adiab. Elimination 

t0=0;
tfinal=15e-6;

options = odeset('RelTol',1e-4);  
y0=[1 0 0 0 0 0];
tspan=[0 tfinal];
[T,Y]=ode45('niv6fun',tspan,y0,options,om,omc,d,nu);

T=T*1e6;
%%%%%%%% Darstellung : So ...
if(1)
 subplot(4,1,1);
 plot(T,abs(Y(:,3)).^2+abs(Y(:,2)).^2+abs(Y(:,5)).^2,'r');

 subplot(4,1,2);
 plot(T,abs(Y(:,1)).^2+abs(Y(:,3)).^2,'r');

 subplot(4,1,3);
 plot(T,abs(Y(:,2)).^2+abs(Y(:,4)).^2,'r');

 subplot(4,1,4);
 plot(T,abs(Y(:,5)).^2+abs(Y(:,6)).^2,'r');

 %axis([0 3e-5 0 1])

%%%%% oder so:
else
 clf;
 subplot(2,1,1)  
 plot(T,abs(Y(:,3)).^2+abs(Y(:,2)).^2,'r');
 hold on
 axis([0 45 0 1])
 hold off

 subplot(2,1,2)  
 plot(T,abs(Y(:,3)).^2+abs(Y(:,2)).^2,'r');
 hold on
% plot(t1,pd1,t2,pd2)
 plot(t-.13,p)
 axis([0 5 0 1])
 hold off
end



