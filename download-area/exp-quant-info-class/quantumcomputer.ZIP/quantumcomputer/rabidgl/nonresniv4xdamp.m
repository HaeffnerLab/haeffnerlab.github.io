% 17.11.99
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 
%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 

% Modelliert nichtresonante Traegeranregungen, wenn das +y - Band nach 
% Seitenbandkuehlung auf y getrieben wird. Der beobachtete Kontrastverlust in
% den experimentellen Daten stammt wahrscheinlich von einem n_x-abhaengigen
% ac-Stark-Shift, der vom Programm modelliert wird durch Annahme einer 
% thermischen Verteilung im x-Oszillator, die zu einer verstimmung auf dem 
% (S,n=0) <-> (D,n=1) Uebergang fuehrt.  
% acx : ist dieser n-abhaengige Anteil
% Das Programm loest das 4-Niveau-System fuer verschiedene x-Werte und mittelt
% ueber eine thermische Verteilung mit <n> = nbar.
% Beste Resultate mit omc=1090,nu_y=1850,nu_x-nu_y=75,d=-375 (alle in kHz),
%                     eta_y=0.045,eta_x=0.01,n_x=25

nmax=100;
nbar=25;
n=0:1:nmax;
pn=(nbar/(nbar+1)).^n;
pn=pn/sum(pn);

sumPI=0;
sumpn=0;
delt=2*pi*(.01*1090e3)^2/(2*75e3);

for j=0:2:200
  omc = 2*pi*1090e3;
  om  = omc*.045/.95;
  d   = -2*pi*375e3+delt*(j+1);
  acx = delt*(j+1);
  nu  =  2*pi*1850e3;

  j
  acx/2/pi/1000

  t0=0;
  tfinal=45e-6;

  options = odeset('RelTol',1e-4);  
  y0=[1 0 0 0];
  tspan=[0 tfinal];
  [T,Y]=ode45('nonresniv4xdamp_fun',tspan,y0,options,om,omc,d+acx,d+nu);

  T=T*1e6;
  P=abs(Y(:,3)).^2+abs(Y(:,2)).^2;
  TI=0:(tfinal*1e6/1000):(tfinal*1e6);
  PI = interp1(T,P,TI);
  sumpn=sumpn+pn(j+1);
  sumPI=sumPI+PI*pn(j+1);
  subplot(2,1,1);
  plot(T,P,'b');
  subplot(2,1,2);
  plot(TI,sumPI/sumpn,'r');
  pause(.25)
  subplot(2,1,1);
  plot(T,P);
end







