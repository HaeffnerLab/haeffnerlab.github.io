
function v=testfun(t,x,flag,om,om2,f,D)

om =om/2 ;
om2=om2/2;
% f : Ungleiche Rabifrequenz auf Ion 1 u. 2

A = [0        -i*om     -i*om*f      0    ;
     -i*om      0         0       -i*om2*f;
     -i*om*f    0         0       -i*om2  ;
     0        -i*om2*f  -i*om2      0    ];

v = A*x;
