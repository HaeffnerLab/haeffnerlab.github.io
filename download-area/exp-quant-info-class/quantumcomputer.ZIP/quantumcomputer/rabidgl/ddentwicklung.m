load ddentwicklung

s
	f=figure(1);
	clf

   t=sprintf('Zeit (10^{-6} s)')
	subplot(2,1,1);
	hold on;   
	plot(T,abs(Y(:,7)).^2,'b');
	plot(T,abs(Y(:,6)).^2,'r--');
	h1=sprintf('<0dd|: %1.4f,  %6.4f pi',PF(7),PH(7));
	h2=sprintf('<1dd|: %1.4f,  %6.4f pi',PF(6),PH(6));
	legend(h1,h2,0);
   ylabel('Population')
   xlabel(t)   

	subplot(2,1,2);
	hold on;   
	plot(T,abs(Y(:,5)).^2,'b');
	plot(T,abs(Y(:,8)).^2,'r--');
	h1=sprintf('<0sd|: %1.4f,  %6.4f pi',PF(5),PH(5));
	h2=sprintf('<1sd|: %1.4f,  %6.4f pi',PF(8),PH(8));
   legend(h1,h2,0);
   ylabel('Population')
   
   xlabel(t)