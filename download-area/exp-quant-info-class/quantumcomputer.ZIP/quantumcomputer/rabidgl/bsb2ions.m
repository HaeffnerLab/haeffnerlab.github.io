% 12.3.00
% 2 2-Niveau-Atome mit Niveaus g und e  
% Niveaus 1 = gg
%         2 = ge
%         3 = eg
%         4 = ee 
% Anregung auf Traeger (gg0,ge0,eg0,ee0) oder Seitenband (gg0,eg1,ge1,ee2) etc.
% Kopplung : 1 - 2 - 4 - 3 - 1
% 1-2,1-3 : Kopplung    om (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
% 2-4, 3-4: Kopplung    om2=om*sqrt(2) bei Anregung auf dem 1. Seitenband
%                       om2=om         bei Traegeranregung  

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

om = 2*pi*50e3;         % Rabifrequenz
om2  = om*sqrt(4);      % Rabifrequenz auf den (eg/ge <-> ee)-Uebergaengen 
d   = -2*pi*0; 
nu  =  2*pi*0;
f=1;                    % f=0..1 = (Rabifrequenz Ion2) / (Rabifrequenz Ion 1)

t0=0;
tfinal=50e-6;

options = odeset('RelTol',1e-4);  
%y0=[sqrt(.5) 0 0 sqrt(.5)];
%y0=[sqrt(.25) i*sqrt(.25) i*sqrt(.25) sqrt(.25)];
y0=[1 0 0 0];
tspan=[0 tfinal];
[T,Y]=ode45('bsb2ionsfun',tspan,y0,options,om,om2,f,0);

T=T*1e6;
%%%%%%%% Darstellung
 subplot(4,1,1);
 plot(T,abs(Y(:,1)).^2,'r');

 subplot(4,1,2);
 %plot(T,abs(Y(:,2)).^2+abs(Y(:,3)).^2,'c');
 plot(T,abs(Y(:,2)).^2,'r');

 subplot(4,1,3);
 plot(T,abs(Y(:,4)).^2,'r');


 subplot(4,1,4);
  plot(T,abs(Y(:,4)).^2+0.5*abs(Y(:,2)).^2+0.5*abs(Y(:,3)).^2,'b');
%  plot(T,abs(Y(:,1)).^2+abs(Y(:,4)).^2,'b');
% plot(T,abs(Y(:,4)).^2,'r');


