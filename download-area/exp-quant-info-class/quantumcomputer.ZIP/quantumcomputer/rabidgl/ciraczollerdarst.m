   load ciraczollerdarst

	f=figure(1);
   clf
	ax=subplot(3,1,1);
   set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
   pl=plot(T,abs(Y(:,1)).^2,'b');
   set(pl,'LineWidth',2)
   hold on;   
	pl=plot(T,abs(Y(:,4)).^2,'r--');
   set(pl,'LineWidth',2)
	h1=sprintf('<0ss|: %1.3f, %4.2f pi',PF(1),PH(1));
	h2=sprintf('<1ss|: %1.3f, %4.2f pi',PF(4),PH(4));
	h=legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])
   
	%ax=subplot(5,1,2);
   %set(ax,'FontSize',13);
   %set(ax,'xtick',0);
   %hold on;   
	%plot(T,abs(Y(:,7)).^2,'b');
	%plot(T,abs(Y(:,6)).^2,'r--');
	%h1=sprintf('<0dd|: %1.3f, %4.2f pi',PF(7),PH(7));
	%h2=sprintf('<1dd|: %1.3f, %4.2f pi',PF(6),PH(6));
	%legend(h1,h2,0);
   %ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   %axis([min(T), max(T), 0, 1])
   

	ax=subplot(3,1,2);
   set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
   pl=plot(T,abs(Y(:,3)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(Y(:,2)).^2,'r--');
   set(pl,'LineWidth',2)
   h1=sprintf('<0ds|: %1.3f, %4.2f pi',PF(3),PH(3));
	h2=sprintf('<1ds|: %1.3f, %4.2f pi',PF(2),PH(2));
	legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])

	%ax=subplot(5,1,4);
	%set(ax,'FontSize',13);
   %set(ax,'xtick',0);
   %hold on;   
	%plot(T,abs(Y(:,5)).^2,'b');
	%plot(T,abs(Y(:,8)).^2,'r--');
	%h1=sprintf('<0sd|: %1.3f, %4.2f pi',PF(5),PH(5));
	%h2=sprintf('<1sd|: %1.3f, %4.2f pi',PF(8),PH(8));
   %legend(h1,h2,0);
   %ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   %axis([min(T), max(T), 0, 1])
   
   
   
 	ax=subplot(3,1,3);
	set(ax,'FontSize',13);
   hold on;   
   pl=plot(T,abs(Y(:,13)).^2,'b');
   set(pl,'LineWidth',2)
   pl=plot(T,abs(Y(:,14)).^2,'r--');
   set(pl,'LineWidth',2)
   h1=sprintf('<0sd_{hilf}|: %1.3f, %4.2f pi',PF(13),PH(13));
	h2=sprintf('<0sd_{hilf}|: %1.3f, %4.2f pi',PF(14),PH(14));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])

  
   xlabel('Time / \mus','FontSize',18,'FontName','Timesnewroman');
   

   
