% 17.11.99 erweitert am 15.11.01
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

clear;

omc = 2*pi*400e3;
omz = 2*pi*940e3*sqrt(3);
eta = lambdicke(729*10^-9,940000,68)/sqrt(2);
om1 = omc*eta/(1-eta^2);
om2 = omc*eta/(1-eta^2);

dest = -omc^2/2/omz  ;    % optimale Verstimmung aus adiab. Elimination 
bereich=100;
kanz=1;
est=1.015 % 1.0227 f�r omc = 2*pi*500e3;
%est=2.37;
%est=2.21;


dest*est

y0=[1 0 0 0 1 0 0 0];   %  Anfangsbedingungen


t0=0;
tfinal=1/(om/pi)*3;

for k=1:kanz
   d=dest*(est+(k-kanz/2)/bereich);
	options = odeset('RelTol',1e-6);  
	tspan=[0 tfinal];
	[T,Y]=ode45('2niv4funpulse',tspan,y0,options,om1,om2,omc,d,omz);
	m(k)=max(abs(Y(:,2)).^2)
end;

if kanz~=1
	[ma,bestk]=max(m)
	d=dest*(est+(bestk-kanz/2)/bereich);
	newestimate=(est+(bestk-kanz/2)/bereich)

	options = odeset('RelTol',1e-6);  
	tspan=[0 tfinal];
	[T,Y]=ode45('niv4funpulse',tspan,y0,options,om,omc,omrescar,d,omz);
	max(abs(Y(:,2)).^2)
end;
T=T*1e6;
%%%%%%%% Darstellung : So ...


figure(1)
clf
   
subplot(4,1,1);
plot(T,abs(Y(:,1)).^2,'b');
xlabel('guter s-Zustand')

subplot(4,1,2);
plot(T,abs(Y(:,2)).^2,'b');
xlabel('guter d-Zustand')

subplot(4,1,3);
plot(T,abs(Y(:,3)).^2,'b');
xlabel('b�ser d-Zustand')


subplot(4,1,4);
plot(T,abs(Y(:,4)).^2,'b');
   xlabel('b�ser s-Zustand')
   
   
figure(2)
clf
   
subplot(4,1,1);
plot(T,abs(Y(:,5)).^2,'r');
xlabel('guter s-Zustand')

subplot(4,1,2);
plot(T,abs(Y(:,6)).^2,'r');
xlabel('guter d-Zustand')

subplot(4,1,3);
plot(T,abs(Y(:,7)).^2,'r');
xlabel('b�ser d-Zustand')

subplot(4,1,8);
plot(T,abs(Y(:,4)).^2,'r');
   xlabel('b�ser s-Zustand')

   
%figure(2)
%clf
%subplot(4,1,1);
%plot(T,atan(imag(Y(:,1))./real(Y(:,1)))/pi,'r');
%xlabel('guter s-Zustand')

%subplot(4,1,2);
%plot(T,atan(imag(Y(:,2))./real(Y(:,2)))/pi,'r');
%xlabel('guter d-Zustand')

%subplot(4,1,3);
%plot(T,atan(imag(Y(:,3))./real(Y(:,3)))/pi,'r');
%xlabel('b�ser d-Zustand')

%subplot(4,1,4);
%plot(T,atan(imag(Y(:,4))./real(Y(:,4)))/pi,'r');
%   xlabel('b�ser s-Zustand')
   
   
%figure(3);
%plot(T,pulse(T/1e6,sqrt(omc^2+omz^2)));