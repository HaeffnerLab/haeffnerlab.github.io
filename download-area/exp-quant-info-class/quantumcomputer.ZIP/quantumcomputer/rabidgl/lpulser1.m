function p=lpulser1(t,piover4time,rabitime);

delay1=10/1e6;

if  t>=(0*piover4time + delay1) & t<((7*piover4time) + 0*rabitime + delay1)
   p=1;
else 
   p=0;   
end;