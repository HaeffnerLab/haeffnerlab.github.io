% 17.11.99
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

omc = 2*pi*600e3;
om  = omc*.027/sqrt(2);
d   = -2*pi*115e3;   % d=-2*pi*355e3;
nu  =  2*pi*940e3*sqrt(3);

%d=-omc^2/2/nu      % optimale Verstimmung aus adiab. Elimination 

t0=0;
tfinal=100e-6;

options = odeset('RelTol',1e-4);  
y0=[1 0 0 0];
tspan=[0 tfinal];
[T,Y]=ode45('niv4fun',tspan,y0,options,om,omc,d,nu);

T=T*1e6;
%%%%%%%% Darstellung : So ...
if(1)
 subplot(4,1,1);
 plot(T,abs(Y(:,3)).^2,'r');

 subplot(4,1,2);
 plot(T,abs(Y(:,1)).^2,'r');

 subplot(4,1,3);
 plot(T,abs(Y(:,2)).^2,'r');

 subplot(4,1,4);
 plot(T,abs(Y(:,4)).^2,'r');

 %axis([0 3e-5 0 1])

%%%%% oder so:
else
load nonres.dat;
t=nonres(:,1)-.13;
p=nonres(:,2);
t1 = t(t<35);
pd1= p(t<35);
t2 = t(t>35);
pd2= p(t>35);
%  load ../../../daten/99/991110/qf0257t
%  t=qf0257t(:,1);
%  p=qf0257t(:,3);
 clf;
 subplot(2,1,1)  
 plot(T,abs(Y(:,3)).^2+abs(Y(:,2)).^2,'r');
 hold on
% plot(t1,pd1,t2,pd2)
 plot(t-.13,p)
 axis([0 45 0 1])
 hold off

 subplot(2,1,2)  
 plot(T,abs(Y(:,3)).^2+abs(Y(:,2)).^2,'r');
 hold on
% plot(t1,pd1,t2,pd2)
 plot(t-.13,p)
 axis([0 5 0 1])
 hold off
end

	max(abs(Y(:,2)).^2)


