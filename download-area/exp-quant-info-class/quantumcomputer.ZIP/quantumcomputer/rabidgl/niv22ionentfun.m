function v=niv2ionentfun(t,x,flag,om01,om02,omc0,d,D,piover4time)

addrefehler=0.1;   %Adressing error
omc1 = epulse01(t,piover4time,pi*20/omc0)*omc0/20;
omc2 = epulse02(t,piover4time,pi*20/omc0)*omc0/20;

omsc1 = epulse1(t,piover4time)*omc0/2;
om1 = epulse1(t,piover4time)*om01/2 ;

omsc2 = epulse2(t,piover4time)*omc0/2;
om2 = epulse2(t,piover4time)*om02/2 ;

omsc3 = 0;
om3 = 0;
%om1=0;
%om2=0;
%om3=0;

sr1 = -i*(om1*exp(-i*(-d+2*D)*t)) ...
	   -i*(om3*exp(-i*(-d+2*D)*t)); 
   
sr2 = -i*(om2*exp(-i*(d+0*D)*t));

ar2 = 0;   % is red sideband on auxilary transition
ab2 = 0;

ar1 = 0;
ab1 = 0;

sb1 = -i*(om1*exp(-i*(-d+0*D)*t)) ...
	   -i*(om3*exp(-i*(-d+0*D)*t));

sb2 = -i*(om2*exp(-i*(d+2*D)*t));;


ca1 = (omsc1*exp(-i*(-d-D)*t)) ...
      +(omsc3*exp(-i*(-d-D)*t)) ...
      +(omc1*exp(-i*0*t)); 
   
ca2 = (omsc2*exp(-i*(d+D)*t)) ...
     +(omc2*exp(-i*0*t)); 

ac2 = 0;

ac1 = 0;

tempca1=ca1+addrefehler*ca2;
tempsb1=sb1+addrefehler*sb2;
tempsr1=sr1+addrefehler*sr2;
tempar1=ar1+addrefehler*ar2;
tempab1=ab1+addrefehler*ab2;

ca2=ca2+addrefehler*ca1;
sb2=sb2+addrefehler*sb1;
sr2=sr2+addrefehler*sr1;
ar2=ar2+addrefehler*ar1;
ab2=ab2+addrefehler*ab1;

ca1=tempca1;
sb1=tempsb1;
sr1=tempsr1;
ar1=tempar1;
ab1=tempab1;

w=sqrt(2);   
   
A = [%0,s,s          1,d,s     0,d,s          1,s,s           0,s,d      1,d,d    0,d,d       1,s,d      2,s,s     2,d,s,    2,d,d,     2,s,d       0asd       1asd       0add       1add        0ads       1ads        0add       1add      2ass             
      0               sb1       ca1             0              ca2         0         0         sb2         0          0        0          0          ac2        ab2         0          0          ac1        ab1         0          0         0;          % 0,s,s
    -conj(sb1)         0         0         -conj(ca1)           0         ca2       sr2         0    -conj(w*sr1)     0       w*sb2       0           0          0         ar2        ac2          0          0          0          0         0;          % 1,d,s
    -conj(ca1)         0         0         -conj(sr1)           0         sb2       ca2         0          0          0        0          0           0          0         ac2        ab2          0          0          0          0         0;          % 0,d,s
      0               ca1       sr1             0              sr2         0         0         ca2         0         w*sb1     0         w*sb2       ar2        ac2         0          0          ar1        ac1         0          0         0;          % 1,s,s
    -conj(ca2)         0         0         -conj(sr2)           0         sb1       ca1         0          0          0        0          0           0          0          0          0           0          0         ac1        ab1        0;          % 0,s,d
      0           -conj(ca2)   -conj(sb2)       0           -conj(sb1)     0         0     -conj(ca1)      0   -conj(w*sr2)    0     -conj(w*sr1)     0     -conj(ac1)      0          0           0          0          0          0         0;          % 1,d,d
      0           -conj(sr2)   -conj(ca2)       0           -conj(ca1)     0         0     -conj(sr1)      0          0        0          0      -conj(ac1) -conj(ar1)      0          0           0          0          0          0         0;          % 0,d,d  
    -conj(sb2)         0         0         -conj(ca2)           0         ca1       sr1         0    -conj(w*sr2)     0      w*sb1        0           0          0          0          0           0          0         ar1        ac1        0;          % 1,s,d
   	0					 w*sr1		0			      0               0          0         0	        w*sr2       0         ca1       0         ca2          0	   w*ar2        0          0           0	       w*ar1       0          0         0;          % 2,s,s
      0                0         0       -conj(w*sb1)           0        w*sr2       0          0      -conj(ca1)     0       ca2         0           0	     0          0        w*ar2         0	        0          0          0         0;          % 2,d,s
      0          -conj(w*sb2)    0              0               0          0         0     -conj(w*sb1)    0      -conj(ca2)   0      -conj(ca1)      0          0          0          0           0          0          0          0         0;          % 2,d,d         
      0                0         0       -conj(w*sb2)           0        w*sr1       0          0      -conj(ca2)     0       ca1         0           0          0          0          0           0          0          0        w*ar1       0;          % 2,s,d
    -conj(ac2)         0         0         -conj(ar2)           0          0        ac1         0          0          0        0          0           0          0          0          0           0          0          0          0         0;          % 0asd         
    -conj(ab2)         0         0        -conj(ac2)            0         ac1       ar1         0    -conj(w*ar2)     0        0          0           0          0          0          0           0          0          0          0         0;          % 1asd        
      0          -conj(ar2)  -conj(ac2)         0               0          0         0          0          0          0        0          0           0          0          0          0           0          0          0          0         0;          % 0add         
      0          -conj(ac2)  -conj(ab2)         0               0          0         0          0          0      -conj(w*ar2) 0          0           0          0          0          0           0          0          0          0         0;          % 1add        
    -conj(ac1)         0         0         -conj(ar1)           0          0         0          0          0          0        0          0           0          0          0          0           0          0          0          0         0;          % 0ads         
    -conj(ab1)         0         0         -conj(ac1)           0          0         0          0    -conj(w*ar1)     0        0          0           0          0          0          0           0          0          0          0         0;          % 1ads        
      0                0         0              0         -conj(ac1)       0         0       -conj(ar1)    0          0        0          0           0          0          0          0           0          0          0          0         0;          % 0add         
      0                0         0              0         -conj(ab1)       0         0       -conj(ac1)    0          0        0    -conj(w*ar1)      0          0          0          0           0          0          0          0         0;          % 1add        
      0                0         0              0               0          0         0          0          0          0        0          0           0          0          0          0           0          0          0          0         0]';        % 2ass
v = ((A)*x);
