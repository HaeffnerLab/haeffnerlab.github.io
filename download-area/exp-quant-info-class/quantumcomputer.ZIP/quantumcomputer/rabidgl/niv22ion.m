% 17.11.99 erweitert am 15.11.01
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

clear;

omz = 2*pi*940e3*sqrt(3);
eta = lambdicke(729*10^-9,omz/2/pi,68)/sqrt(2);
kanz = 1;

omc = 2*pi*292e3;
omstep = 0.5*pi*2e3;  
adjust = 0;
omc=omc-(kanz-1)/2*omstep;
omcini = (omc+(kanz-1)/2*omstep);

det=-0*1e3*2*pi;    % detuning
detstep=0.0*1e3*2*pi;
det=det-(kanz-1)/2*detstep;


rabifl = sqrt(3)*3*eta^2+0.005;   % Rabi frequency fluctuations
rabifl = 0;

 dest = -omc^2/2/omz;    % optimale Verstimmung aus adiab. Elimination 
 sprintf('Rabi frequency: %4.4f kHz\n      Detuning: %4.4f kHz\n',omc/2/pi/1000,dest/2/pi/1000)


for k=1:kanz
	dest = -omc^2/2/omz; 
   g=1;                     %  Grundzustandswahrscheinlichkeit
	e=0;
   en=0;
   Y1=0;
	for l=1:1
   
   poss=0;                     % Hier Anfangsbedingungen eintragen, wird dann automatisch unten in den Vektor eingef�gt.
	pods=1;
	posd=0;
	podd=0;
  	y0=1/sqrt(poss+pods+posd+podd)*[sqrt(poss*g)   sqrt(pods*en)    sqrt(pods*g)    sqrt(poss*en)     sqrt(posd*g)    sqrt(podd*en)   sqrt(podd*g)    sqrt(posd*en)         0 0 0 0    0         0          0          0          0           0           0           0      0 ];  
                          %     0,s,s       |  1,d,s         |   0,d,s         | 1,s,s        |  0,s,d        |  1,d,d       |  0,d,d       |   1,s,d              |2xx     0asd     1asd       0add       1add        0asd       1asd         0add       1add    2ass
   
   
   omcre=omc*adjust+omcini*(1-adjust);
   dest = -omcre^2/2/omz;    % optimale Verstimmung aus adiab. Elimination 
   d=dest+det;
   om1 = omc*eta/(1-eta^2);
   om2 = omc*eta/(1-eta^2);
   piover4time=pi/2/(omcre*eta/(1-eta^2));    %/1.02;
   t0=0;
   tfinal=piover4time*8.1+8.4*14e-6;
%   tfinal=piover4time*0+1*14e-6;
   %   tfinal=30e-6
   tspan=[0:2e-8:tfinal];

   options = odeset('AbsTol',1e-6,'RelTol',1e-5,'MaxStep',1e-7,'InitialStep',1e-7);  
   [T,Y]=ode45('niv22ioncnotfun',tspan,y0,options,om1,om2,omc*(1+rabifl),d,omz,eta,piover4time);
  	m(k)=max(abs(Y(:,1)).^2);
   if l==1   % erster Durchlauf (f�r den Grundzustand)
	   en=e;
   	g=0;
   	Y0=Y;
   else
	   Y1=Y;
	end;
end;    
     
	T=T*1e6;
%%%%%%%% Darstellung : So ...
  Y=Y0;
   PYG=abs(Y0).^2+abs(Y1).^2;   % inkoh�rente Summe
   PF=PYG(length(PYG),:);
 
	PH=angle(Y(length(Y),:))/pi;
	s=[sprintf('Final populations and phases (only for pop starting in the groundstate) after %6.6f s:\n',tfinal),...
	sprintf('<0ss|: %1.4f,  %6.4f pi\n',PF(1),PH(1)),... 
	sprintf('<1ds|: %4.4f,  %6.4f pi\n',PF(2),PH(2)),...
	sprintf('<0ds|: %4.4f,  %6.4f pi\n',PF(3),PH(3)),...
	sprintf('<1ss|: %4.4f,  %6.4f pi\n',PF(4),PH(4)),...
	sprintf('<0sd|: %4.4f,  %6.4f pi\n',PF(5),PH(5)),...
	sprintf('<1dd|: %4.4f,  %6.4f pi\n',PF(6),PH(6)),...
	sprintf('<0dd|: %4.4f,  %6.4f pi\n',PF(7),PH(7)),...
	sprintf('<1sd|: %4.4f,  %6.4f pi\n',PF(8),PH(8)),...
	sprintf('<2ss|: %1.4f,  %6.4f pi\n',PF(9),PH(9)),... 
	sprintf('<2ds|: %4.4f,  %6.4f pi\n',PF(10),PH(10)),...
	sprintf('<2dd|: %4.4f,  %6.4f pi\n',PF(11),PH(11)),...
	sprintf('<2sd|: %4.4f,  %6.4f pi\n',PF(12),PH(12)),...
  	sprintf('<0asd|: %4.4f,  %6.4f pi\n',PF(13),PH(13)),...
	sprintf('<1asd|: %4.4f,  %6.4f pi\n',PF(14),PH(14)),...
  	sprintf('<0add|: %4.4f,  %6.4f pi\n',PF(15),PH(15)),...
	sprintf('<1add|: %4.4f,  %6.4f pi\n',PF(16),PH(16)),...
	sprintf('<2ass|: %4.4f,  %6.4f pi\n',PF(17),PH(17)),...
   sprintf('\nSumme: %4.5f\n',sum(PF))];

	s
   
   
	f=figure(1);
   clf
	ax=subplot(5,1,1);
   set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
	plot(T,abs(Y(:,1)).^2,'b');
	plot(T,abs(Y(:,4)).^2,'r--');
	h1=sprintf('<0ss|: %1.3f, %4.2f pi',PF(1),PH(1));
	h2=sprintf('<1ss|: %1.3f, %4.2f pi',PF(4),PH(4));
	h=legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])
   
	ax=subplot(5,1,2);
   set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
	plot(T,abs(Y(:,7)).^2,'b');
	plot(T,abs(Y(:,6)).^2,'r--');
	h1=sprintf('<0dd|: %1.3f, %4.2f pi',PF(7),PH(7));
	h2=sprintf('<1dd|: %1.3f, %4.2f pi',PF(6),PH(6));
	legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])
   

	ax=subplot(5,1,3);
   set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
	plot(T,abs(Y(:,3)).^2,'b');
	plot(T,abs(Y(:,2)).^2,'r--');
	h1=sprintf('<0ds|: %1.3f, %4.2f pi',PF(3),PH(3));
	h2=sprintf('<1ds|: %1.3f, %4.2f pi',PF(2),PH(2));
	legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])

	ax=subplot(5,1,4);
	set(ax,'FontSize',13);
   set(ax,'xtick',0);
   hold on;   
	plot(T,abs(Y(:,5)).^2,'b');
	plot(T,abs(Y(:,8)).^2,'r--');
	h1=sprintf('<0sd|: %1.3f, %4.2f pi',PF(5),PH(5));
	h2=sprintf('<1sd|: %1.3f, %4.2f pi',PF(8),PH(8));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])
   
   
   
 	ax=subplot(5,1,5);
	set(ax,'FontSize',13);
   hold on;   
	plot(T,abs(Y(:,13)).^2,'b');
	plot(T,abs(Y(:,14)).^2,'r--');
	h1=sprintf('<0asd|: %1.3f, %4.2f pi',PF(13),PH(13));
	h2=sprintf('<0asd|: %1.3f, %4.2f pi',PF(14),PH(14));
   legend(h1,h2,0);
   ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   axis([min(T), max(T), 0, 1])

  
   xlabel('Time / \mus','FontSize',18,'FontName','Timesnewroman');
   

   
   
   %print -dwin
   PFA(:,k)=PF(:);
   PHA(:,k)=PH(:);
   nuca(k)=omc/2/pi/1e3;
   nudet(k) = det/2/pi/1e3;
   omc=omc+omstep;
   det=det+detstep;
   drawnow;
   uiresume(f);
   k
end;
if k~=1
   if detstep~=0
		figure(2);
		clf;
		hold on;
		plot(nudet,PFA(1,:),'bo-');
		plot(nudet,PFA(3,:),'r.--');
		plot(nudet,PFA(5,:),'gx--');
		plot(nudet,PFA(7,:),'cd--');
		plot(nudet,PFA(13,:),'k>--');
		plot(nudet,PFA(4,:),'m<--');
		legend('<0ss|','<0ds|','<0sd|','<0dd|','<0asd|','<1ss|',0)
		xlabel('729-Detuning / kHz')
		ylabel('Population')

		figure(3);
		clf;
		hold on;
		plot(nudet,PHA(1,:),'bo-');
      plot(nudet,PHA(3,:),'gx--');
      plot(nudet,PHA(5,:),'ms--');
		plot(nudet,PHA(7,:),'cd--');
		legend('Phase of <0ss|','<0ds|','<0sd|','<0dd|',0)
		xlabel('729-Detuning / kHz')
      ylabel('Phase / pi')
      
  		figure(4);
		clf;
		hold on;
		plot(nudet,PFA(1,:),'bo-');
		plot(nudet,PFA(3,:),'r.--');
		plot(nudet,(PHA(3,:)-PHA(1,:)),'gx--');
		legend('<0ss|','<0ds|','Phase difference',0)
		xlabel('729-Detuning / kHz')
		ylabel('Population | Phase / pi')
      
      figure(5);
		clf;
		hold on;
		plot(nudet,PFA(5,:),'bo-');
		plot(nudet,PFA(7,:),'r.--');
		plot(nudet,(PFA(7,:)+PFA(5,:)),'gx:')
		plot(nudet,(PFA(7,:)+PFA(5,:)+PFA(1,:)+PFA(3,:)),'md:')
		legend('<0sd|','<0dd|','<0sd|+<0dd|','Alle guten',0)
		xlabel('729-Detuning / kHz')
		ylabel('Population')

      
   else 
		figure(2);
		clf;
		hold on;
		plot(nuca,PFA(1,:),'bo-');
		plot(nuca,PFA(3,:),'r.--');
		plot(nuca,PFA(5,:),'gx-');
		plot(nuca,PFA(7,:),'md--');
      plot(nuca,(PFA(1,:)+PFA(3,:)+PFA(5,:)+PFA(7,:)),'kd:')
		legend('<0ss|','<0ds|','<0sd|','<0dd|','Alle guten',0)
		xlabel('Rabi frequency / kHz')
		ylabel('Population')
      
		figure(3);
		clf;
		hold on;
		plot(nuca,PHA(1,:),'bo-');
      plot(nuca,PHA(3,:),'gx--');
      plot(nuca,PHA(5,:),'ms--');   
      plot(nuca,PHA(7,:),'cd--');
		legend('Phase of <0ss|','<0ds|','<0sd|','<0dd|',0)
		xlabel('Rabi frequency / kHz')
      ylabel('Phase / pi')
      
    end;
end;
save niv22ion
