function p=epulse01(t,piover4time,rabitime);

delay1=2/1e6;
delay2=(6*14)/1e6;

if  t>=(0*piover4time + delay1) & t<((0*piover4time) + rabitime/10 + delay1)
   p=1;
elseif  t>=(8*piover4time + delay2) & t<((8*piover4time) + 1*rabitime/4 + delay2)
   p=1;
else 
   p=0;   
end;

p=0;