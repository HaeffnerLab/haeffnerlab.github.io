function v=shape(t,d,D)

%v = (1+exp(i*(2.1*D+2*d)*t))/2;
f=[-0.5:0.01:0.5];
ph=[-0.5:0.01:0.5];
v = sum(exp(i*f/1000*D*t-ph*0.1*pi));
v=v/length(f);