
function v=2niv4fun(t,x,flag,om1,om2,omc,d,D)

omc1 = pulse1(t,o)*omc/2;
om1 = pulse1(t,o)*om1/2 ;

sb1 = -i*(om*exp(-i*d*t)); 
ca1 = -i*(omc*exp(-i*(d+D)*t)); 


omc2 = pulse2(t,o)*omc/2;
om2 = pulse2(t,o)*om2/2 ;

sb2 = -i*(om*exp(-i*d*t)); 
ca2 = -i*(omc*exp(-i*(d+D)*t)); 

   
A = [0           sb1      ca1          0            0          0         0          0;
    -conj(sb1)     0        0     -conj(ca1)        0          0         0          0
    -conj(ca1)     0        0          0            0          0         0          0
     0           ca1        0          0            0          0         0          0
     0            0         0          0            0         sb2       ca2         0  
     0            0         0          0        -conj(sb1)     0         0     -conj(ca1)        
     0            0         0          0        -conj(ca1)     0         0          0            
     0            0         0          0           ca2         0         0          0];
  
  
  
    
    
  
  
v = A*x;
