% 17.11.99 erweitert am 15.11.01
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

clear;

eta = lambdicke(729*10^-9,940000,68)/sqrt(2);
kanz=1;

omz = 2*pi*940e3*sqrt(3);
omc = 2*pi*325e3;
omstep = 1*pi*2e3;
adjust = 0;
omc=omc-(kanz-1)/2*omstep;
omcini = (omc+(kanz-1)/2*omstep);

det=0 *2*pi;    % Laser x kHz off resonant
detstep=0e3 *2*pi;
det=det-(kanz-1)/2*detstep;

est=1.000; % 1.0227 f�r omc = 2*pi*500e3;
%est=2.37;
%est=2.21;

dest = -omc^2/2/omz; 
sprintf('Rabi frequency: %4.4f kHz\n      Detuning: %4.4f kHz\n',omc/2/pi/1000,dest*est/2/pi/1000)

g=0.0;                     %  Grundzustandswahrscheinlichkeit
e=1-g;

pos=1;                     % Hier Anfangsbedingungen eintragen, wird dann automatisch unten in den Vektor eingef�gt.
pod=0;

y0=[sqrt(pos*g)   sqrt(pod*e)    sqrt(pod*g)    sqrt(pos*e)            0 0 ];  
%     0,s       |  1,d         |   0,d        | 1,s               |2xx ;


for k=1:kanz
   omcre=omc*adjust+omcini*(1-adjust);
   dest = -omcre^2/2/omz;    % optimale Verstimmung aus adiab. Elimination 
   d=dest*est+det;
   om1 = omc*eta/(1-eta^2);
   piover4time=pi/2/(omcre*eta/(1-eta^2))*est;    %/1.02;
   t0=0;
   tfinal=piover4time*2.1+1*14e-6;
   %   tfinal=30e-6
   tspan=[0 tfinal];

   options = odeset('AbsTol',1e-6,'RelTol',1e-5,'MaxStep',1e-7,'InitialStep',1e-7);  
   [T,Y]=ode45('niv1ionfun',tspan,y0,options,om1,omc,d,omz,piover4time);
  	m(k)=max(abs(Y(:,1)).^2);
     
	T=T*1e6;
%%%%%%%% Darstellung : So ...

	PF=Y(length(Y),:).*conj(Y(length(Y),:));
	PH=angle(Y(length(Y),:))/pi;
	s=[sprintf('Final populations and phases after %6.6f s:\n',tfinal),...
	sprintf('<0s|: %1.4f,  %6.4f pi\n',PF(1),PH(1)),... 
	sprintf('<1d|: %4.4f,  %6.4f pi\n',PF(2),PH(2)),...
	sprintf('<0d|: %4.4f,  %6.4f pi\n',PF(3),PH(3)),...
	sprintf('<1s|: %4.4f,  %6.4f pi\n',PF(4),PH(4)),...
	sprintf('<2s|: %1.4f,  %6.4f pi\n',PF(5),PH(5)),... 
	sprintf('<2d|: %4.4f,  %6.4f pi\n',PF(6),PH(6)),...
   sprintf('\nSumme: %4.5f\n',sum(PF))];

	s
	f=figure(1);
	clf
	subplot(3,1,1);
	hold on;   
	plot(T,abs(Y(:,1)).^2,'b');
	plot(T,abs(Y(:,4)).^2,'r--');
	h1=sprintf('<0s|: %1.4f,  %6.4f pi',PF(1),PH(1));
	h2=sprintf('<1s|: %1.4f,  %6.4f pi',PF(4),PH(4));
	legend(h1,h2,0);
   ylabel('Population')

	subplot(3,1,2);
	hold on;   
	plot(T,abs(Y(:,3)).^2,'b');
	plot(T,abs(Y(:,2)).^2,'r--');
	h1=sprintf('<0d|: %1.4f,  %6.4f pi',PF(3),PH(3));
	h2=sprintf('<1d|: %1.4f,  %6.4f pi',PF(2),PH(2));
	legend(h1,h2,0);
   ylabel('Population')

	subplot(3,1,3);
	hold on;   
	plot(T,abs(Y(:,5)).^2,'b');
	plot(T,abs(Y(:,6)).^2,'r--');
	h1=sprintf('<2s|: %1.4f,  %6.4f pi',PF(5),PH(5));
	h2=sprintf('<2d|: %1.4f,  %6.4f pi',PF(6),PH(6));
   legend(h1,h2,0);
   ylabel('Population')
   
   max(abs((Y(:,2)).^2))
   
	t=sprintf('Time [10^{-6} s]     |     Initial population: %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f',y0(1).*conj(y0(1)),y0(2).*conj(y0(2)),y0(3).*conj(y0(3)),y0(4).*conj(y0(4)));
%	t=sprintf('Time [10^{-6} s]\n\nAnfangsbedingungen: %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f    Rabi frequency: %2.0f kHz',y0(1).*conj(y0(1)),y0(2).*conj(y0(2)),y0(3).*conj(y0(3)),y0(4).*conj(y0(4)),y0(5).*conj(y0(5)),y0(6).*conj(y0(6)),y0(7).*conj(y0(7)),y0(8).*conj(y0(8)),omc/2/pi/1000);
   xlabel(t)
   ylabel('Population')
   %print -dwin
   PFA(:,k)=PF(:);
   PHA(:,k)=PH(:);
   nuca(k)=omc/2/pi/1e3;
   nudet(k) = det/2/pi/1e3;
   omc=omc+omstep;
   det=det+detstep;
   drawnow;
   uiresume(f);
   k
end;
save cirac