% Resonantes Moelmer-Soerensen-Gatter mit zwei Ionen (Naeherungsformeln)

% Parameter :
eta = 0.031;
nu  = 1;
om  = .161*nu;
del = 0.99*nu;
tmax= 800;
t   = 0:1:tmax;

% Basisfunktionen 
f  = sqrt(2)*eta*om/(nu-del)*sin((nu-del)*t);
g  = sqrt(2)*eta*om/(nu-del)*(1-cos((nu-del)*t));
a  = (eta*om)^2/(nu-del)*(t-1/(2*(nu-del))*sin(2*(nu-del)*t));
fg = f.^2 + g.^2;
afg= a + .5*f.*g;
 
% therm. Verteilung :
nmax = 300;
nbar = 25;
n    = 0:1:nmax;
pn   = (nbar/(nbar+1)).^n/(nbar+1);

% In Matrizenform :
FG = ones(length(pn),1)*fg;
AFG= ones(length(pn),1)*afg;

PN = pn'*ones(1,length(t)); 

% Laguerre-Polynome :
x=fg/2;
L1_2(1:1:nmax+1,1:length(t))=0;
L1_2(1,:)=1;
L1_2(2,:)=1-x;
for m=1:1:nmax-1
  L1_2(m+2,:) = ((2*m+1-x).*L1_2(m+1,:)-m*L1_2(m,:))/(m+1);
end
x=fg*2;
L2(1:1:nmax+1,1:length(t))=0;
L2(1,:)=1;
L2(2,:)=1-x;
for m=1:1:nmax-1
  L2(m+2,:) = ((2*m+1-x).*L2(m+1,:)-m*L2(m,:))/(m+1);
end

% Dichtematrix-Elemente

rho_gg_gg=sum(PN.*(3/8+1/2*exp(-FG/4).*L1_2.*cos(AFG)+1/8*exp(-FG).*L2));
rho_ee_ee=sum(PN.*(3/8-1/2*exp(-FG/4).*L1_2.*cos(AFG)+1/8*exp(-FG).*L2));
rho_gg_ee=sum(PN.*(1/8*(1-exp(-FG).*L2)-i/2*exp(-FG/4).*L1_2.*sin(AFG)));

% Darstellung

if(0)
  clf;
  subplot(3,1,1)
  plot(t,rho_gg_gg);
  subplot(3,1,2)
  plot(t,rho_ee_ee);
  subplot(3,1,3)
  plot(t,abs(rho_gg_ee));
else
%  clf;
%  plot(t,rho_gg_gg,t,rho_ee_ee,t,real(rho_gg_ee),'--',t,imag(rho_gg_ee),'--') 
   plot(t,rho_gg_gg,t,rho_ee_ee,t,1-(rho_gg_gg+rho_ee_ee),'--')
end



