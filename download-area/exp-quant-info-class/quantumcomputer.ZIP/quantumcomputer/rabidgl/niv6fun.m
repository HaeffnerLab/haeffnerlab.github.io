
function v=niv6fun(t,x,flag,om,omc,d,D)

om =om/2 ;
omc=omc/2;

a0 = -i*omc*exp(i*(d+D)*t);
a0c= -i*omc*exp(-i*(d+D)*t);
a1 = -i*om *exp(i*d*t);
a1c=-i*om *exp(-i*d*t);
a12= a1*sqrt(2);
a12c=a1c*sqrt(2);


A = [0        a1c     a0c      0      0       0 ;
     a1        0       0       a0     0       0 ;
     a0        0       0       0      0       0 ;
     0        a0c      0       0     a12c     0 ;
     0         0       0       a12    0       a0;
     0         0       0       0     a0c      0 ];

v = A*x;
