
function v=niv4fun(t,x,flag,om,omc,omrescar,d,D)

omc = pulse(t,om)*omc/2;
om = pulse(t,om)*om/2 ;
omrescar = pulse(t,om)*omrescar/2;

sb = -i*om*exp(-i*d*t);
ca = -i*(omc*exp(-i*(d+D)*t)+omrescar*exp(-i*d*t));

A = [0           sb      ca        0   ;
   
     conj(sb)    0        0     conj(ca) ;
     
     conj(ca)    0        0        0   ;
     
     0           ca       0        0  ];
  
  
v = A*x;
