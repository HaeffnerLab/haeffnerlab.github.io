% Berechnung von Binomialkoeffizienten

function b=bino(n,k)

b = gamma(n+1) / (gamma(k+1)*gamma(n-k+1));