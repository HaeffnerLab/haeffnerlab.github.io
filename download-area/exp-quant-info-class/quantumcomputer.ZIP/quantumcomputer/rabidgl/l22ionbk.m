% 17.11.99 erweitert am 15.11.01
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

clear;

eta = lambdicke(729*10^-9,940000,68)/sqrt(2);
kanz=1;

omz = 2*pi*940000*sqrt(3);

omc = omz/2*1.000;
omstep = 2*pi*2;
adjust = 1;
omc=omc-(kanz-1)/2*omstep;
omcini = (omc+(kanz-1)/2*omstep);

det=0e3;    % Laser x kHz off resonant
detstep=0*2*pi;
det=det-(kanz-1)/2*detstep;

est=1.000; % 1.0227 f�r omc = 2*pi*500e3;
%est=2.37;
%est=2.21;

dest = -omc^2/2/omz; 
sprintf('Rabi frequency: %4.4f kHz\n  Light shift: %4.4f kHz\n',omc/2/pi/1000,dest*est/2/pi/1000)

g=1;                     %  Grundzustandswahrscheinlichkeit
e=1-g;


if 0
   poss=1;                     % Hier Anfangsbedingungen eintragen, wird dann automatisch unten in den Vektor eingef�gt.
	pods=1;
	posd=1;
	podd=1;

	qubit1=0;    %  1 is + and 0 is -
	qubit2=1;

	qubit1=(qubit1*2-1);
	qubit2=(qubit2*2-1);

	y0=[sqrt(poss*g)   qubit1*sqrt(pods*e)      qubit1*sqrt(pods*g)    sqrt(poss*e)      qubit2*sqrt(posd*g)     qubit1*qubit2*sqrt(podd*e)   qubit1*qubit2*sqrt(podd*g)    qubit2*sqrt(posd*e)         0 0 0 0    0         0          0          0          0           0           0           0      0 ];  
%     0,s,s       |       1,d,s         |      0,d,s                | 1,s,s       |       0,s,d                 |       1,d,d           |             0,d,d           |       1,s,d                     |2xx     0asd     1asd       0add       1add        0asd       1asd         2asd       2add    2ads

else
   poss=1;                     % Hier Anfangsbedingungen eintragen, wird dann automatisch unten in den Vektor eingef�gt.
	pods=0;
	posd=0;
	podd=0;

   y0=[sqrt(poss*g)   sqrt(pods*e)      sqrt(pods*g)    sqrt(poss*e)      sqrt(posd*g)     sqrt(podd*e)    sqrt(podd*g)    sqrt(posd*e)         0 0 0 0    0         0          0          0          0           0           0           0      0 ];  
%     0,s,s       |    1,d,s         |    0,d,s         | 1,s,s       |   0,s,d        |       1,d,d    |     0,d,d     |    1,s,d                  |2xx     0asd     1asd       0add       1add        0asd       1asd         0add       1add    2ass
end;   

y0=y0/norm(y0);

for k=1:kanz
   omcre=omc*adjust+omcini*(1-adjust);
   dest = -omcre^2/2/omz;    % optimale Verstimmung aus adiab. Elimination 
   d=det;
   om1 = omc*eta/(1-eta^2);
   om2 = omc*eta/(1-eta^2);
   piover4time=pi/2/(omcre*eta/(1-eta^2))*est;    %/1.02;
   t0=0;
   tfinal=piover4time*4+38e-6;
   %   tfinal=30e-6
   tspan=[0 tfinal];

   options = odeset('AbsTol',1e-6,'RelTol',1e-5,'MaxStep',1e-7,'InitialStep',1e-7);  
   [T,Y]=ode45('l22ionfun',tspan,y0,options,om1,om2,omc,d,omz,piover4time);
  	m(k)=max(abs(Y(:,1)).^2);
     
	T=T*1e6;
%%%%%%%% Darstellung : So ...
   	PF=Y(length(Y),:).*conj(Y(length(Y),:));
	PH=angle(Y(length(Y),:))/pi;
	s=[sprintf('Final populations and phases after %6.6f s:\n',tfinal),...
	sprintf('<0ss|: %1.4f,  %6.4f pi\n',PF(1),PH(1)),... 
	sprintf('<1ds|: %4.4f,  %6.4f pi\n',PF(2),PH(2)),...
	sprintf('<0ds|: %4.4f,  %6.4f pi\n',PF(3),PH(3)),...
	sprintf('<1ss|: %4.4f,  %6.4f pi\n',PF(4),PH(4)),...
	sprintf('<0sd|: %4.4f,  %6.4f pi\n',PF(5),PH(5)),...
	sprintf('<1dd|: %4.4f,  %6.4f pi\n',PF(6),PH(6)),...
	sprintf('<0dd|: %4.4f,  %6.4f pi\n',PF(7),PH(7)),...
	sprintf('<1sd|: %4.4f,  %6.4f pi\n',PF(8),PH(8)),...
	sprintf('<2ss|: %1.4f,  %6.4f pi\n',PF(9),PH(9)),... 
	sprintf('<2ds|: %4.4f,  %6.4f pi\n',PF(10),PH(10)),...
	sprintf('<2dd|: %4.4f,  %6.4f pi\n',PF(11),PH(11)),...
	sprintf('<2sd|: %4.4f,  %6.4f pi\n',PF(12),PH(12)),...
  	sprintf('<0asd|: %4.4f,  %6.4f pi\n',PF(13),PH(13)),...
	sprintf('<1asd|: %4.4f,  %6.4f pi\n',PF(14),PH(14)),...
  	sprintf('<0add|: %4.4f,  %6.4f pi\n',PF(15),PH(15)),...
	sprintf('<1add|: %4.4f,  %6.4f pi\n',PF(16),PH(16)),...
	sprintf('<2ass|: %4.4f,  %6.4f pi\n',PF(17),PH(17)),...
   sprintf('\nSumme: %4.5f\n',sum(PF))];

	s

	f=figure(1);
	clf
	subplot(5,1,1);
	hold on;   
	plot(T,abs(Y(:,1)).^2,'b');
	plot(T,abs(Y(:,4)).^2,'r--');
	h1=sprintf('<0ss|: %1.4f,  %6.4f pi',PF(1),PH(1));
	h2=sprintf('<1ss|: %1.4f,  %6.4f pi',PF(4),PH(4));
	legend(h1,h2,0);
   ylabel('Population')


	subplot(5,1,2);
	hold on;   
	plot(T,abs(Y(:,7)).^2,'b');
	plot(T,abs(Y(:,6)).^2,'r--');
	h1=sprintf('<0dd|: %1.4f,  %6.4f pi',PF(7),PH(7));
	h2=sprintf('<1dd|: %1.4f,  %6.4f pi',PF(6),PH(6));
	legend(h1,h2,0);
   ylabel('Population')
   

	subplot(5,1,3);
	hold on;   
	plot(T,abs(Y(:,3)).^2,'b');
	plot(T,abs(Y(:,2)).^2,'r--');
	h1=sprintf('<0ds|: %1.4f,  %6.4f pi',PF(3),PH(3));
	h2=sprintf('<1ds|: %1.4f,  %6.4f pi',PF(2),PH(2));
	legend(h1,h2,0);
   ylabel('Population')

	subplot(5,1,4);
	hold on;   
	plot(T,abs(Y(:,5)).^2,'b');
	plot(T,abs(Y(:,8)).^2,'r--');
	h1=sprintf('<0sd|: %1.4f,  %6.4f pi',PF(5),PH(5));
	h2=sprintf('<1sd|: %1.4f,  %6.4f pi',PF(8),PH(8));
   legend(h1,h2,0);
   ylabel('Population')
   
  	subplot(5,1,5);
	hold on;   
	plot(T,abs(Y(:,13)).^2,'b');
	plot(T,abs(Y(:,14)).^2,'r--');
	h1=sprintf('<0asd|: %1.4f,  %6.4f pi',PF(13),PH(13));
	h2=sprintf('<0add|: %1.4f,  %6.4f pi',PF(15),PH(15));
	legend(h1,h2,0);
   ylabel('Population')
   
   
   
%    R=[ 1  0  1  0  1  0  1  0;
%        0  1  0 -1  0  1  0 -1;
%       -1  0  1  0 -1  0  1  0;
%        0  1  0  1  0  1  0  1;     
%        1  0  1  0 -1  0 -1  0;
%        0  1  0 -1  0 -1  0  1;
%       -1  0  1  0  1  0 -1  0;
%        0  1  0  1  0 -1  0 -1;];

   R=[1  0  1  0;
      0  1  0 -1;
     -1  0  1  0;
      0  1  0  1;];
   
   RT=[[R , R];
       [R ,-R];];

   RO=zeros(21);
   RO(1:8,1:8)=RT/2;
   YP=(RO*Y')';
   
   PF=YP(length(YP),:).*conj(YP(length(YP),:));
	PH=angle(YP(length(YP),:))/pi;
	s=[sprintf('Final populations and phases after %6.6f s:\n',tfinal),...
	sprintf('<0++|: %1.4f,  %6.4f pi\n',PF(1),PH(1)),... 
	sprintf('<1++|: %4.4f,  %6.4f pi\n',PF(4),PH(4)),...
	sprintf('<0-+|: %4.4f,  %6.4f pi\n',PF(3),PH(3)),...
	sprintf('<1-+|: %4.4f,  %6.4f pi\n',PF(2),PH(2)),...
	sprintf('<0+-|: %4.4f,  %6.4f pi\n',PF(5),PH(5)),...
	sprintf('<1+-|: %4.4f,  %6.4f pi\n',PF(8),PH(8)),...
	sprintf('<0--|: %4.4f,  %6.4f pi\n',PF(7),PH(7)),...
	sprintf('<1--|: %4.4f,  %6.4f pi\n',PF(6),PH(6)),...
	sprintf('<2ss|: %1.4f,  %6.4f pi\n',PF(9),PH(9)),... 
	sprintf('<2ds|: %4.4f,  %6.4f pi\n',PF(10),PH(10)),...
	sprintf('<2dd|: %4.4f,  %6.4f pi\n',PF(11),PH(11)),...
	sprintf('<2sd|: %4.4f,  %6.4f pi\n',PF(12),PH(12)),...
  	sprintf('<0asd|: %4.4f,  %6.4f pi\n',PF(13),PH(13)),...
	sprintf('<1asd|: %4.4f,  %6.4f pi\n',PF(14),PH(14)),...
  	sprintf('<0add|: %4.4f,  %6.4f pi\n',PF(15),PH(15)),...
	sprintf('<1add|: %4.4f,  %6.4f pi\n',PF(16),PH(16)),...
	sprintf('<2ass|: %4.4f,  %6.4f pi\n',PF(17),PH(17)),...
   sprintf('\nSumme: %4.5f\n',sum(PF))];

	s

   
 	f=figure(10);
   clf
	subplot(4,1,1);
	hold on;   
	plot(T,abs(YP(:,1)).^2,'b');
	plot(T,abs(YP(:,4)).^2,'r--');
	h1=sprintf('<0++|: %1.4f,  %6.4f pi',PF(1),PH(1));
	h2=sprintf('<1++|: %1.4f,  %6.4f pi',PF(4),PH(4));
	legend(h1,h2,0);
   ylabel('Population')
   axis([min(T), max(T), 0, 1.1*max(max(abs(YP(:,1)).^2),max(abs(YP(:,4)).^2))])


	subplot(4,1,2);
	hold on;   
   plot(T,abs(YP(:,3)).^2,'b');
	plot(T,abs(YP(:,2)).^2,'r--');
	h1=sprintf('<0-+|: %1.4f,  %6.4f pi',PF(3),PH(3));
	h2=sprintf('<1-+|: %1.4f,  %6.4f pi',PF(2),PH(2));
   legend(h1,h2,0);
   ylabel('Population')
   axis([min(T), max(T), 0, 1.1*max(max(abs(YP(:,3)).^2),max(abs(YP(:,2)).^2))])
   

	subplot(4,1,3);
	hold on;   
   plot(T,abs(YP(:,5)).^2,'b');
	plot(T,abs(YP(:,8)).^2,'r--');
	h1=sprintf('<0+-|: %1.4f,  %6.4f pi',PF(5),PH(5));
	h2=sprintf('<1+-|: %1.4f,  %6.4f pi',PF(8),PH(8));
   legend(h1,h2,0);
   ylabel('Population')
   axis([min(T), max(T), 0, 1.1*max(max(abs(YP(:,5)).^2),max(abs(YP(:,8)).^2))])

	subplot(4,1,4);
	hold on;   
   plot(T,abs(YP(:,7)).^2,'b');
	plot(T,abs(YP(:,6)).^2,'r--');
	h1=sprintf('<0--|: %1.4f,  %6.4f pi',PF(7),PH(7));
	h2=sprintf('<1--|: %1.4f,  %6.4f pi',PF(6),PH(6));
   legend(h1,h2,0);
   ylabel('Population')
   axis([min(T), max(T), 0, 1.1*max(max(abs(YP(:,7)).^2),max(abs(YP(:,6)).^2))])
   
   
   
   
	t=sprintf('Time [10^{-6} s]     |     Initial population: %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f',y0(1).*conj(y0(1)),y0(2).*conj(y0(2)),y0(3).*conj(y0(3)),y0(4).*conj(y0(4)),y0(5).*conj(y0(5)),y0(6).*conj(y0(6)),y0(7).*conj(y0(7)),y0(8).*conj(y0(8)));
%	t=sprintf('Time [10^{-6} s]\n\nAnfangsbedingungen: %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f    Rabi frequency: %2.0f kHz',y0(1).*conj(y0(1)),y0(2).*conj(y0(2)),y0(3).*conj(y0(3)),y0(4).*conj(y0(4)),y0(5).*conj(y0(5)),y0(6).*conj(y0(6)),y0(7).*conj(y0(7)),y0(8).*conj(y0(8)),omc/2/pi/1000);
   xlabel(t)
   ylabel('Population')
   %print -dwin
   PFA(:,k)=PF(:);
   PHA(:,k)=PH(:);
   nuca(k)=omc/2/pi/1e3;
   nudet(k) = det/2/pi/1e3;
   omc=omc+omstep;
   det=det+detstep;
   drawnow;
   uiresume(f);
   k
end;
if k~=1
   if detstep~=0
		figure(2);
		clf;
		hold on;
		plot(nudet,PFA(1,:),'bo-');
		plot(nudet,PFA(3,:),'r.--');
		plot(nudet,(PFA(1,:)+PFA(3,:)),'gx:')
		legend('<0ss|','<0ds|','<0ss|+<0ds|',0)
		xlabel('729-Detuning / kHz')
		ylabel('Population')

		figure(3);
		clf;
		hold on;
		plot(nudet,PHA(1,:),'bo-');
      plot(nudet,PHA(3,:),'gx--');
      plot(nudet,PHA(5,:),'ms--');
		plot(nudet,PHA(7,:),'cd--');
		legend('Phase of <0ss|','<0ds|','<0sd|','<0dd|',0)
		xlabel('729-Detuning / kHz')
      ylabel('Phase / pi')
      
  		figure(4);
		clf;
		hold on;
		plot(nudet,PFA(1,:),'bo-');
		plot(nudet,PFA(3,:),'r.--');
		plot(nudet,(PHA(3,:)-PHA(1,:)),'gx--');
		legend('<0ss|','<0ds|','Phase difference',0)
		xlabel('729-Detuning / kHz')
		ylabel('Population | Phase / pi')
      
      figure(5);
		clf;
		hold on;
		plot(nudet,PFA(5,:),'bo-');
		plot(nudet,PFA(7,:),'r.--');
		plot(nudet,(PFA(7,:)+PFA(5,:)),'gx:')
		plot(nudet,(PFA(7,:)+PFA(5,:)+PFA(1,:)+PFA(3,:)),'md:')
		legend('<0sd|','<0dd|','<0sd|+<0dd|','Alle guten',0)
		xlabel('729-Detuning / kHz')
		ylabel('Population')

      
   else 
		figure(2);
		clf;
		hold on;
		plot(nuca,PFA(1,:),'bo-');
		plot(nuca,PFA(3,:),'r.--');
		plot(nuca,PFA(5,:),'gx-');
		plot(nuca,PFA(7,:),'md--');
      plot(nuca,(PFA(1,:)+PFA(3,:)+PFA(5,:)+PFA(7,:)),'kd:')
		legend('<0ss|','<0ds|','<0sd|','<0dd|','Alle guten',0)
		xlabel('Rabi frequency / kHz')
		ylabel('Population')
      
		figure(3);
		clf;
		hold on;
		plot(nuca,PHA(1,:),'bo-');
      plot(nuca,PHA(3,:),'gx--');
      plot(nuca,PHA(5,:),'ms--');   
      plot(nuca,PHA(7,:),'cd--');
		legend('Phase of <0ss|','<0ds|','<0sd|','<0dd|',0)
		xlabel('Rabi frequency / kHz')
      ylabel('Phase / pi')
      
    end;
end;
save cirac