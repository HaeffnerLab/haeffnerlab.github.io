

function v=niv4fun(t,x,flag,om,omc,omrescar,d,D)

om =om/2 ;
omc=omc/2;

A = [0                -i*om*exp(-i*d*t)  -i*omc*exp(-i*(d+D)*t)       0   ;
     -i*om *exp(i*d*t)            0            0    -i*omc*exp(i*(d+D)*t) ;
     -i*omc*exp(i*(d+D)*t)        0            0                      0   ;
     0                -i*omc*exp(-i*(d+D)*t)   0                      0  ];

v = A*x;
