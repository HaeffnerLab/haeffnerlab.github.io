% 15.11.98
% berechnet die Kopplungsstaerken fuer Uebergaenge auf dem Traeger
% Vergleich der exakten Loesung mit Entwicklungen nach eta fuer eta<<1

eta=.1;
etaquad=eta^2;


for j=0:1:100
  k  (j+1) = j;
  oml(j+1) = laguerre(j,0,etaquad);
  om1(j+1) = 1-j*etaquad;
  om2(j+1) = 1-j*etaquad + (j*etaquad)^2/6;
end

plot(k,oml,k,om1,k,om2)