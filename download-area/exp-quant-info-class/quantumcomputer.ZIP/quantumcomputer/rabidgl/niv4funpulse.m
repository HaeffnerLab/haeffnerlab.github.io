
function v=niv4fun(t,x,flag,om,omc,omrescar,d,D)

o=sqrt(omc^2+D^2);
omc = pulse(t,o)*omc/2;
om = pulse(t,o)*om/2 ;
omrescar = pulse(t,o)*omrescar/2;
ph = 0; %1*sin(2*o*t+pi/4);
delta = 0.15*D;
rela = sqrt(omc^2+(D+delta)^2)/sqrt(omc^2+(D+0)^2);

sb = -i*(om*exp(-i*d*t+ph)); ...
   	%	- rela*om*exp(-i*(d+delta)*t+ph));
		
ca = -i*(omc*exp(-i*(d+D)*t+ph)); ...
      %   - rela*omc*exp(-i*(d+D+delta)*t+ph));

A = [0           sb      ca        0   ;
    -conj(sb)    0        0     -conj(ca)  
    -conj(ca)    0        0        0   
     0           ca       0        0  ];
  
  
v = A*x;
