
function v=niv4fun(t,x,flag,om,omc,d,D)

% d : Verstimmung auf 1-2
% D : Verstimmung auf 1-3 und 4-2

om =om/2 ;
omc=omc/2;

A = [0                -i*om*exp(-i*d*t)  -i*omc*exp(-i*(D)*t)       0   ;
     -i*om *exp(i*d*t)            0            0    -i*omc*exp(i*(D)*t) ;
     -i*omc*exp(i*(D)*t)          0            0                    0   ;
     0                -i*omc*exp(-i*(D)*t)     0                    0  ];

v = A*x;
