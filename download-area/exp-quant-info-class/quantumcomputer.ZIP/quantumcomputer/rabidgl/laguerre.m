% Berechnung der generalisierten Laguerre-Polynome
% x   : Argument
% a=0 : das "nicht generalisierte" Polynom

function y=laguerre(n,a,x)

m = 0:1:n;
y = sum((((-x).^m)./gamma(m+1)).*binovekt(n+a,n-m));
