function p=epulse1(t,piover4time);

delay = (1.2*14) / 1e6; % delay sensitive to 0.1e-6
if t>=(0*piover4time + delay) & t<((piover4time) + delay)
   p=1;
else
   p=0;
end;
%p=0;