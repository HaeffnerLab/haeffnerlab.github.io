% 17.11.99 erweitert am 15.11.01
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

clear;

eta = lambdicke(729*10^-9,940000,68)/sqrt(2);
kanz=1;

omc = 2*pi*100e3;
omstep = 0.1*pi*2e3;
adjustpi4 = 1;
om1ini = (omc+kanz/2*omstep)*eta/(1-eta^2);

det=0.5e3*2*pi;    % Laser 1 kHz off-resonant
detstep=0;%0.5*2*pi;


omz = 2*pi*940e3*sqrt(3);

dest = -omc^2/2/omz  ;    % optimale Verstimmung aus adiab. Elimination 

est=1.000; % 1.0227 f�r omc = 2*pi*500e3;
%est=2.37;
%est=2.21;


dest*est/2/pi
po0=sqrt(0.95);
po1=sqrt(1-po0^2);

y0=[po0         0         0     po1       0         0         0         0         0 0 0 0    0         0          0          0 ];  
%  0,s,s  | 1,d,s |   0,d,s | 1,s,s  |  0,s,d   |  1,d,d |  0,d,d  |   1,s,d        |2xx    0asd       1asd       0add       1add  

for k=1:kanz
   d=dest*est+det;
   om1 = omc*eta/(1-eta^2);
   om2 = omc*eta/(1-eta^2);
   piover4time=pi/2/(om1*adjustpi4+om1ini*(1-adjustpi4))*est;
   t0=0;
   tfinal=piover4time*13;
   %   tfinal=30e-6
   tspan=[0 tfinal];

   options = odeset('RelTol',1e-8);  
   [T,Y]=ode45('niv22ionfuni',tspan,y0,options,om1,om2,omc,d,omz,piover4time);
  	m(k)=max(abs(Y(:,1)).^2);
     
	T=T*1e6;
%%%%%%%% Darstellung : So ...

	PF=Y(length(Y),:).*conj(Y(length(Y),:));
	PH=angle(Y(length(Y),:))/pi;
	s=[sprintf('Final populations and phases after %6.6f s:\n',tfinal),...
	sprintf('<0ss|: %1.4f,  %6.4f pi\n',PF(1),PH(1)),... 
	sprintf('<1ds|: %4.4f,  %6.4f pi\n',PF(2),PH(2)),...
	sprintf('<0ds|: %4.4f,  %6.4f pi\n',PF(3),PH(3)),...
	sprintf('<1ss|: %4.4f,  %6.4f pi\n',PF(4),PH(4)),...
	sprintf('<0sd|: %4.4f,  %6.4f pi\n',PF(5),PH(5)),...
	sprintf('<1dd|: %4.4f,  %6.4f pi\n',PF(6),PH(6)),...
	sprintf('<0dd|: %4.4f,  %6.4f pi\n',PF(7),PH(7)),...
	sprintf('<1sd|: %4.4f,  %6.4f pi\n',PF(8),PH(8)),...
	sprintf('<2ss|: %1.4f,  %6.4f pi\n',PF(9),PH(9)),... 
	sprintf('<2ds|: %4.4f,  %6.4f pi\n',PF(10),PH(10)),...
	sprintf('<2dd|: %4.4f,  %6.4f pi\n',PF(11),PH(11)),...
	sprintf('<2sd|: %4.4f,  %6.4f pi\n',PF(12),PH(12)),...
  	sprintf('<0asd|: %4.4f,  %6.4f pi\n',PF(13),PH(13)),...
	sprintf('<1asd|: %4.4f,  %6.4f pi\n',PF(14),PH(14)),...
  	sprintf('<0add|: %4.4f,  %6.4f pi\n',PF(15),PH(15)),...
	sprintf('<1add|: %4.4f,  %6.4f pi\n',PF(16),PH(16)),...
   sprintf('\nSumme: %4.5f\n',sum(PF))...
	sprintf('\n <0ss| + <0ds|: %4.4f %6.4f pi\n',(PF(1)+PF(3)),(PH(1)-PH(3)))];

	s
	f=figure(1);
	clf
	subplot(5,1,1);
	hold on;   
	plot(T,abs(Y(:,1)).^2,'b');
	plot(T,abs(Y(:,4)).^2,'r--');
	h1=sprintf('<0ss|: %1.4f,  %6.4f pi',PF(1),PH(1));
	h2=sprintf('<1ss|: %1.4f,  %6.4f pi',PF(4),PH(4));
	legend(h1,h2,0);

	%'[<0|s|s|',]     1,d,s    0,d,s      1,s,s            0,s,d      1,d,d    0,d,d       1,s,d


	subplot(5,1,2);
	hold on;   
	plot(T,abs(Y(:,7)).^2,'b');
	plot(T,abs(Y(:,6)).^2,'r--');
	h1=sprintf('<0dd|: %1.4f,  %6.4f pi',PF(7),PH(7));
	h2=sprintf('<1dd|: %1.4f,  %6.4f pi',PF(6),PH(6));
	legend(h1,h2,0);
   

	subplot(5,1,3);
	hold on;   
	plot(T,abs(Y(:,3)).^2,'b');
	plot(T,abs(Y(:,2)).^2,'r--');
	h1=sprintf('<0ds|: %1.4f,  %6.4f pi',PF(3),PH(3));
	h2=sprintf('<1ds|: %1.4f,  %6.4f pi',PF(2),PH(2));
	legend(h1,h2,0);

	subplot(5,1,4);
	hold on;   
	plot(T,abs(Y(:,5)).^2,'b');
	plot(T,abs(Y(:,8)).^2,'r--');
	h1=sprintf('<0sd|: %1.4f,  %6.4f pi',PF(5),PH(5));
	h2=sprintf('<1sd|: %1.4f,  %6.4f pi',PF(8),PH(8));
   legend(h1,h2,0);
   
  	subplot(5,1,5);
	hold on;   
	plot(T,abs(Y(:,13)).^2,'b');
	plot(T,abs(Y(:,14)).^2,'r--');
	h1=sprintf('<0asd|: %1.4f,  %6.4f pi',PF(13),PH(13));
	h2=sprintf('<0add|: %1.4f,  %6.4f pi',PF(15),PH(15));
	legend(h1,h2,0);

	t=sprintf('Anfangbedingungen: %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f %2.2f    Rabifrequency: %2.0f kHz',y0(1).*conj(y0(1)),y0(2).*conj(y0(2)),y0(3).*conj(y0(3)),y0(4).*conj(y0(4)),y0(5).*conj(y0(5)),y0(6).*conj(y0(6)),y0(7).*conj(y0(7)),y0(8).*conj(y0(8)),omc/2/pi/1000);
	xlabel(t)
   %print -dwin
   PFA(:,k)=PF(:);
   PHA(:,k)=PH(:);
   nuca(k)=omc/2/pi/1e3;
   nudet(k) = det/2/pi/1e3;
   omc=omc+omstep;
   det=det+detstep;
   drawnow;
   uiresume(f);
   k
end;
if k~=1
   if detstep~=0
		figure(2);
		clf;
		hold on;
		plot(nudet,PFA(1,:),'b');
		plot(nudet,PFA(3,:),'r--');
		plot(nudet,(PFA(1,:)+PFA(3,:)),'g:')
		legend('<0ss|','<0ds|','<0ss|+<0ds|',0)
		xlabel('729-Detuning / kHz')
		ylabel('Population')

		figure(3);
		clf;
		hold on;
		plot(nuca,PHA(1,:),'r');
		plot(nuca,(PHA(3,:)-PHA(1,:)),'g--');
		legend('Phase of <0ss|','Phase difference to <0ds|',0)
		xlabel('Rabi frequency / kHz')
      ylabel('Phase / pi')
   else 
		figure(2);
		clf;
		hold on;
		plot(nuca,PFA(1,:),'b');
		plot(nuca,PFA(3,:),'r--');
		plot(nuca,(PFA(1,:)+PFA(3,:)),'g:')
		legend('<0ss|','<0ds|','<0ss|+<0ds|',0)
		xlabel('Rabi frequency / kHz')
		ylabel('Population')

		figure(3);
		clf;
		hold on;
		plot(nuca,PHA(1,:),'r');
		plot(nuca,(PHA(3,:)-PHA(1,:)),'g--');
		legend('Phase of <0ss|','Phase difference to <0ds|',0)
		xlabel('Rabi frequency / kHz')
      ylabel('Phase / pi')
   end;
   
	save cirac
end;