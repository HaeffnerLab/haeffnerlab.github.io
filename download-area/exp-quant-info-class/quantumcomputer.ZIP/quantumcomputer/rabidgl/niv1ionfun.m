function v=niv1ionfun(t,x,flag,om01,omc0,d,D,piover4time)

%omsc1 = pulse1(t,piover4time)*omc0/2;
om1 = pulse1ion(t,piover4time)*om01/2 ;
omc1 = pulse1ion(t,piover4time)*omc0/2;

sr1 = -i*(om1*exp(-i*d*t))*shape(t,d,D);
   
sb1 = -i*(om1*exp(-i*(d+2*D)*t))*shape(t,d,D);
   
ca1 = (omc1*exp(-i*(d+D)*t))*shape(t,d,D); 
%ca1=0;   
   
w=0;
   
A = [%0,s             1,d       0,d         1,s               2,s         2,d              
      0               sb1       ca1             0               0          0     ;   % 0,s,s
    -conj(sb1)         0         0         -conj(ca1)     -conj(w*sr1)     0     ;   % 1,d,s
    -conj(ca1)         0         0         -conj(sr1)           0          0     ;   % 0,d,s
      0               ca1       sr1             0               0         w*sb1  ;   % 1,s,s
   	0					 w*sr1		0			      0               0         ca1    ;   % 2,s,s
      0                0         0       -conj(w*sb1)       -conj(ca1)     0   ]';	 % 2,d,s
      
   
   
  v = ((A)*x);
  
 