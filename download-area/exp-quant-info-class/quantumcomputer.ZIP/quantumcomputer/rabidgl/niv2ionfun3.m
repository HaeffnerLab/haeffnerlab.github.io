function v=niv2ionfun(t,x,flag,om01,om02,omc,d,D,piover4time)

omc1 = pulse1(t,piover4time)*omc/2;
om1 = pulse1(t,piover4time)*om01/2 ;

omc2 = pulse2(t,piover4time)*omc/2;
om2 = pulse2(t,piover4time)*om02/2 ;

omc3 = pulse3(t,piover4time)*omc/2;
om3 = pulse3(t,piover4time)*om01/2 ;

sr1 = 0;%-i*(om3*exp(-i*d*t));
sr2 = -i*(om2*exp(-i*d*t));

sb1 = -i*(om1*exp(-i*d*t));
	   -i*(om3*exp(-i*d*t)); 
sb2 = 0;%-i*(om2*exp(-i*d*t));

ca1 = -i*(omc1*exp(-i*(d+D)*t)) ...
      -i*(omc3*exp(-i*(d+D)*t)); 

ca2 = -i*(omc2*exp(-i*(d+D)*t)); 


A = [%0,s,s          1,d,s     0,d,s          1,s,s           0,s,d      1,d,d    0,d,d       1,s,d
      0               sb1       ca1             0              ca2         0         0         sb2;    % 0,s,s
    -conj(sb1)         0         0         -conj(ca1)           0         ca2       sr2         0;     % 1,d,s
    -conj(ca1)         0         0         -conj(sr1)           0         sb2       ca2         0;     % 0,d,s
      0               ca1       sr1             0              sr2         0         0         ca2;    % 1,s,s
    
    -conj(ca2)         0         0         -conj(sr2)           0         sb1       ca1         0;     % 0,s,d
      0           -conj(ca2)   -conj(sb2)       0           -conj(sb1)     0         0     -conj(ca1); % 1,d,d
      0           -conj(sr2)   -conj(ca2)       0           -conj(ca1)     0         0     -conj(sr1); % 0,d,d  
    -conj(sb2)         0         0         -conj(ca2)           0         ca1       sr1         0  ]'; % 1,s,d
  
  
  
 
  v = ((A)*x);
