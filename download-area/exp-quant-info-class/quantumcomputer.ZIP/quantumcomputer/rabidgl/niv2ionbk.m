% 17.11.99 erweitert am 15.11.01
% 4-Niveau-Atom : 
% Niveaus 1,2,3,4 
% Kopplung : 3 - 1 - 2 - 4
% 1-3,2-4 : Kopplung    omc (1/2 Osz.freq der Besetzung= Osz.Fr. der
%			     Wellenfunktionskoeffizienten)
%           Fallenfrequenz D ( = Energieabstand 2-3 und 4-1)  
% 1-2     : Kopplung    om    
%           Verstimmung d   (bezogen auf den Uebergang 1-2) 

%  Loest Diff.Gleichung fuer die fuer das Zeitintervall [t0 tfinal]. 
% 

clear;

omc = 2*pi*300e3;
omz = 2*pi*940e3*sqrt(3);
eta = lambdicke(729*10^-9,940000,68)/sqrt(2);
om1 = omc*eta/(1-eta^2);
om2 = omc*eta/(1-eta^2);

dest = -omc^2/2/omz  ;    % optimale Verstimmung aus adiab. Elimination 
bereich=100;
kanz=1;
est=1.000; % 1.0227 f�r omc = 2*pi*500e3;
%est=2.37;
%est=2.21;


dest*est
piover4time=pi/2/om1*est;

y0=[0 1 0 0 0 0 0 0];   %  Anfangsbedingungen 0,s,s  | 1,d,s |   0,d,s | 1,s,s  |  0,s,d   |  1,d,d |  0,d,d  |   1,s,d



t0=0;
tfinal=1/(om1/pi)*1+1/(om2/pi)*0.6;
%tfinal=30e-6

for k=1:kanz
   d=dest*(est+(k-kanz/2)/bereich);
   options = odeset('AbsTol',1e-6*[1 1 1 1 1 1 1 1]);  
   steps=0.01;
   arle=round(50/steps*tfinal*1e6);
   YT=zeros(arle,8)';
   TT=zeros(arle,1)';
   za=0;
   for l=0:steps:tfinal*1e6
      tspan=[l-1,l]/1e6;
      [TM,YM]=ode45('niv2ionfun2',tspan,y0,options,om1,om2,omc,d,omz,piover4time);
      norm=sum(YM(length(YM),:).*conj(YM(length(YM),:)));
      le=length(TM);
      y0=YM(le,:)/norm;
      YT=YT+[zeros(za,8)',YM(:,1:8)',zeros(arle-za-le,8)'];
      TT=TT+[zeros(za,1)',TM(:)',zeros(arle-za-le,1)'];
      za=za+le;
      if(abs(norm-1))>1e-4
         fprintf('\n%g: Norm mit %g von 1 zu verschieden!\n',l,norm)
      else
         fprintf('%g, ',l);
      end;
   end;
   fprintf('\n')
   Y=YT(1:8,1:za)';
   T=TT(1:za)';
	m(k)=max(abs(Y(:,7)).^2)
end;

if kanz~=1
	[ma,bestk]=max(m)
	d=dest*(est+(bestk-kanz/2)/bereich);
	newestimate=(est+(bestk-kanz/2)/bereich)

	options = odeset('RelTol',1e-6);  
	tspan=[0 tfinal];
	[T,Y]=ode45('niv2ionfun2',tspan,y0,options,om1,om2,omc,d,omz,piover4time);
	max(abs(Y(:,7)).^2)
end;
T=T*1e6;
%%%%%%%% Darstellung : So ...

(Y(length(Y),:).*conj(Y(length(Y),:)))'

abs(Y(length(Y),1))^2+abs(Y(length(Y),7))^2

figure(1)
clf
subplot(4,1,1);
hold on;   
plot(T,abs(Y(:,1)).^2,'b');
plot(T,abs(Y(:,4)).^2,'r--');
legend('<0ss|','<1ss|');

%'[<0|s|s|',]     1,d,s    0,d,s      1,s,s            0,s,d      1,d,d    0,d,d       1,s,d


subplot(4,1,2);
hold on;   
plot(T,abs(Y(:,7)).^2,'b');
plot(T,abs(Y(:,6)).^2,'r--');
legend('<0dd|','<1dd|');


subplot(4,1,3);
hold on;   
plot(T,abs(Y(:,3)).^2,'b');
plot(T,abs(Y(:,2)).^2,'r--');
legend('<0ds|','<1ds|');


subplot(4,1,4);
hold on;   
plot(T,abs(Y(:,5)).^2,'b');
plot(T,abs(Y(:,6)).^2,'r--');
legend('<0sd|','<1sd|');

save cirac