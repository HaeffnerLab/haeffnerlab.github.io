% 14.8.99
% berechnet die Kopplungsstaerken auf dem Traeger und dem Seitenband fuer 
% verschiedene Werte von eta und n;
% eta   : Lamb-Dicke-Parameter
% n     : Phononzahl

% Rekursion -> Galindo/Pascual : QM 1 (Anhang ..) 

clf;
nmax=5000;          % Verteilung wird bei nmax abgeschnitten

eta=0.05;
x=eta^2;

% Fuer den Traeger :

l0(1:1:nmax+1)=0;
l0(1)=1;
l0(2)=1-x;

for m=1:1:nmax-1
  l0(m+2) = ((2*m+1-x)*l0(m+1)-m*l0(m))/(m+1);
end
omcarr=l0;
plot(abs(omcarr))

hold on

% Fuer das Seitenband :

l1(1:1:nmax+1)=0;
l1(1)=1;
l1(2)=2-x;

for m=1:1:nmax-1
  l1(m+2) = (2-x/(m+1)) * l1(m+1) - l1(m);
end
omblau = l1 * eta ./sqrt(1:1:nmax+1);
plot(abs(omblau))


