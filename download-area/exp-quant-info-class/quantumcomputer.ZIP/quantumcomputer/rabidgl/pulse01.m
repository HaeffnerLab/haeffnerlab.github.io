function p=pulse01(t,piover4time,rabitime);

delay1=4/1e6;
delay2=(7*14)/1e6;

if  t>=(0*piover4time + delay1) & t<((0*piover4time) + rabitime + delay1)
   p=1;
elseif  t>=(8*piover4time + delay2) & t<((8*piover4time) + 3*rabitime + delay2)
   p=1;
else 
   p=0;   
end;
