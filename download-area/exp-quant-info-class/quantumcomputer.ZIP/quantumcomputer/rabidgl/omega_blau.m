% berechnet die Kopplungsstaerken auf dem blauen Seitenband fuer 
% verschiedene Werte von eta und n;
% om    : exakter Wert
% omappr: Naeherungsloesung
% eta   : Effektiver Lamb-Dicke-Parameter
% n     : Phononzahl


nmax=100;          % Verteilung wird bei nmax abgeschnitten
eta=.07;

etaquad=eta^2;

for k=0:1:nmax;
   n(k+1)=k;
   om(k+1)=laguerre(k,1,etaquad)/sqrt(k+1)*eta;
   omappr(k+1)=sqrt(k+1)*eta;
end
plot(n,om,n,omappr);
title('Kopplung')
xlabel('n')


