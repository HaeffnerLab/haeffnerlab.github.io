%simulate teleportation data

global homepath;

teledetana;

k=2;
no=1000;
allelstates=[
0 0 0;
1 0 0;
0 1 0;
1 1 0;
0 0 1;
1 0 1;
0 1 1;
1 1 1;
];


dat1(1,1:no)=1:no;
dat2(1,1:no)=1:no;
dat3(1,1:no)=1:no;
for bellcase=1:4
	st=simulatedata(phonontracedpopulations(1,S(bellcase,:),allelstates,parameters.hspace),no);
	dat=createdata(st,allelstates);
	dat1(k,1:no)=dat(1,:);
	dat2(k,1:no)=dat(2,:);
	dat3(k,1:no)=dat(3,:);
	k=k+1;
end;
for bellcase=1:4
	st=simulatedata(phonontracedpopulations(1,D(bellcase,:),allelstates,parameters.hspace),no);
	dat=createdata(st,allelstates);
	dat1(k,1:no)=dat(1,:);
	dat2(k,1:no)=dat(2,:);
	dat3(k,1:no)=dat(3,:);
	k=k+1;
end;
for bellcase=1:4
	st=simulatedata(phonontracedpopulations(1,SDX(bellcase,:),allelstates,parameters.hspace),no);
	dat=createdata(st,allelstates);
	dat1(k,1:no)=dat(1,:);
	dat2(k,1:no)=dat(2,:);
	dat3(k,1:no)=dat(3,:);
	k=k+1;
end;
for bellcase=1:4
	st=simulatedata(phonontracedpopulations(1,SDY(bellcase,:),allelstates,parameters.hspace),no);
	dat=createdata(st,allelstates);
	dat1(k,1:no)=dat(1,:);
	dat2(k,1:no)=dat(2,:);
	dat3(k,1:no)=dat(3,:);
	k=k+1;
end;

form='';
for k=1:no
	form=[form '%d '];
end;
form=[form '\n'];

fid=fopen([homepath '\aus\roi1000_0.sca'],'w');
fprintf(fid,form,dat1');
fclose(fid);
fid=fopen([homepath '\aus\roi1000_1.sca'],'w');
fprintf(fid,form,dat2');
fclose(fid);
fid=fopen([homepath '\aus\roi1000_2.sca'],'w');
fprintf(fid,form,dat3');
fclose(fid);


teleanna('SIMULATE')