% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;


%hspace=definehspace(5,2,[2 1 1],0);
hspace=definehspace(2,3,1,0);
%setstatevisibility(0);
parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegaz=2*pi*1200000*[1];
parameters.eigenvectors=[1 1];
parameters.omegacarrier=2*pi*3e3;
parameters.sbomegacarrier=2*pi*230e3;
parameters.recoilangle=68;
parameters.points=1;
parameters.addressing=ones(parameters.hspace.nuions);
parameters.decoherences.frefluct=1*2*pi*0;
parameters.detuning=0*2*pi*1222;
parameters.ignorelightshift=1;
parameters.intensitymismatch=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%

%parameters.y0(index([0],[0 1],parameters.hspace))=1; %DS
%parameters.y0(index([0],[1 0],parameters.hspace))=1; %SD
parameters.y0(index([0],[1 1],parameters.hspace))=1; %SS


%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%
detun=2*pi*60000;
fxpa2=fxpa;
fxpa2.detuning=fxpa.detuning+(detun)*parameters.frequencyscale;
fxpa3=fxpa2;
fxpa4=fxpa2;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

%

fxpa2.addressingerror=[1 1; 1 1 ];
p = p + 1;[pulse(p),time] = Rblue(0.5*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),1,1,1,1,fxpa2,time+(1)*delayunit);


fxpa2.addressingerror=[1 i; 1 i ];
p = p + 1;[pulse(p),time] = Rblue(1*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),1,1,1,1,fxpa2,time+(1)*delayunit);


fxpa2.addressingerror=[1 1; 1 1 ];
p = p + 1;[pulse(p),time] = Rblue(0.5*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),1,1,1,1,fxpa2,time+(1)*delayunit);



%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
%setstatevisibility(1,ones(1,hspace.nuions),1);
displaypopulations(T,Y,[0 0;  0 1 ;1 0;  1 1 ;],hspace);
[PF,PH]=endpopulations(T,Y',hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;
%*****************************************************************************%
closemessagewindow;

