% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H?fner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,20);

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=100;
parameters.omegacarrier=1.5*2*pi/29.4e-6;
parameters.sbomegacarrier=2*pi/(10e-3*0.03);
%parameters.addressing=[1];
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi;
parameters.detuning=0;
parameters.eta=[0.07];
parameters.odesolve=1;


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state(0,[ 1])';




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters


%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)




oldtime=time;
p = p + 1;[pulse(p),time] = Rblue(5,0,1,1,fxpa,time+15*delayunit);
p = p + 1;[pulse(p),time] = Rred(5,0,1,1,fxpa,oldtime+15*delayunit);


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(9,hspace);
displaypopulations(T,Y,[1 ; 0],hspace);
setstatevisibility(9,hspace);
endpopulations(T,Y,hspace);
phonontracedpopulations(T,Y,[1; 0],hspace);

%*****************************************************************************%
closemessagewindow;
