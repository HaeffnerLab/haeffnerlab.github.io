% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,[1],0); %definehspace(ions, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=1000;
parameters.omegacarrier=2*pi*100e3;
parameters.sbomegacarrier=2*pi*310e3; 
%parameters.addressing=[0.05 1;1 0.05];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1340000;

parameters.detuning=2*pi*300;
parameters.decoherences.detuning_fluctuations=2*pi*300;
parameters.decoherences.intensity_fluctuations=0.05;
parameters.intensitymismatch=0;

parameters.odesolve=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;  % Inital States: states(phonon,electronicstates)
%parameters.y0(index(1,[0],parameters.hspace))=1/sqrt(2); 
%parameters.y0(index(1,[0 0],parameters.hspace))=0.02;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;

fxpacomp=fxpa; % compensation pulse

fxpacomp.detuning=-2*pi*1e6;
%fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;
fxpacomp.sbcarrierrabi=(1-0.425*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;


fxpaoffr=fxpa;
fxpaoffr.carrierrabi=2*pi*300e3;
fxpaoffr.detuning=2*pi*700e3;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

%delayunit=2*1/1.2e6

%ang=acos(-real(exp(pi/2*i*sqrt(2))))/pi;
ph=1.25;
timecomp=time;
p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time);
p = p + 1;[pulse(p),time] = Rblue(1,ph,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),ph+0.5,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,ph,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),ph+0.5,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+delayunit);
%p = p + 1;[pulse(p),time] = Rred(0.1,0,1,1,fxpacomp,timecomp); % compensation laser

timecomp=time;
%p = p + 1;[pulse(p),time] = Rblue(0.1,0,1,1,fxpa,time+delayunit);
%p = p + 1;[pulse(p),time] = Rred(0.1,0,1,1,fxpacomp,timecomp+delayunit); % compensation laser
% timecomp=time;
% p = p + 1;[pulse(p),time] = Rblue(sqrt(2)/2,0.5,1,1,fxpa,time+delayunit);
% p = p + 1;[pulse(p),time] = Rred(sqrt(2)/2,0.5,1,1,fxpacomp,timecomp+delayunit); % compensation laser
% 
% timecomp=time;
% p = p + 1;[pulse(p),time] = Rblue(sqrt(2)/2,-0.5,1,1,fxpa,time+0.5*delayunit);
% p = p + 1;[pulse(p),time] = Rred(sqrt(2)/2,-0.5,1,1,fxpacomp,timecomp+0.5*delayunit); % compensation laser
% 
% timecomp=time;
% p = p + 1;[pulse(p),time] = Rblue(0.5,1,1,1,fxpa,time+delayunit);
% p = p + 1;[pulse(p),time] = Rred(0.5,1,1,1,fxpacomp,timecomp+delayunit); % compensation laser

%timecomp=time;
%p = p + 1;[pulse(p),time] = Rblue(0.5,1,1,1,fxpaoffr,time+2*delayunit);
%p = p + 1;[pulse(p),time] = Rred(0.5,1,1,1,fxpacomp,timecomp+2*delayunit); % compensation laser

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;;
displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;

dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
dlmwrite('kkdP.dat',abs(Y).*abs(Y), 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
