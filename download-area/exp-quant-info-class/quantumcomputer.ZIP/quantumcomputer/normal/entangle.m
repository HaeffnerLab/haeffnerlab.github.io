% simulates the population evolution with experimental imperfections
% requires the scripts in qctools
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at
%
% type <edit simulate> to specify the parameters directly in the script
% 

clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,[1 1],0);
parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=1;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*250.e3;
parameters.omegaz=2*pi*[2100000 1200000];

%parameters.odesolve=1;
parameters.addressing = [1 0.05; 0.05 1];
%*****************************************************************************%
parameters=recalculateparameters(parameters);
initializepulseparameters
fxpa.includelsdetuning=1;
fxpac=fxpa;
fxpac.detuning=-2*pi*100000;



%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fp,time)
%  Rblue(theta,phi,ion,transition,fp,time)
%fxpa.detuning=1e5;


p = p + 1;[pulse(p),time] = Rblue(0.5,0,1,1,1,fxpa,time+1*delayunit); 


p = p + 1;[pulse(p),time] =  Rcar(1,0,2,1,fxpa,time+1*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0.5,2,1,1,fxpa,time+1*delayunit); 
p = p + 1;[pulse(p),time] =  Rcar(1,1,2,1,fxpa,time+1*delayunit); 

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
setstatevisibility([1 1],hspace);
displaypopulations(T,Y,[0 0; 1 1; 1 0; 0 1;],hspace);
%displaypopulations(T,Y,[1 0; 0 1;],hspace);
endpopulations(T,Y,hspace);
%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;