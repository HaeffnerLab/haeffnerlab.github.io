% simulates the Moelmer-Soerense Gate
% Date:   06-Dec-05
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% Contents
% 
% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,[2],0); %definehspace(electronic states, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=400;
parameters.omegacarrier=2*pi*1e3;
parameters.sbomegacarrier=2*pi*240e3; % 2*pi*120e3 in the paper
%parameters.sbomegacarrier=2*pi/(0.15e-3*0.036);
%parameters.addressing=[0.00 0.00 0.01 i*0.04 1; 0.00 0.01 -i*0.04 1 0.03; 0.01 -0.03 1 0.04 0.01; i*0.04 1 -0.03 0.01 0.00; 1 i*0.04 0.01  0.00 0.00;];
parameters.addressing=[0 1 ; 1 0];
parameters.eigenvectors=[1 1];
%parameters.eigenvectors=[1; 1];
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi;
%parameters.omegaz=1200000*2*pi*[1 sqrt(3)];
parameters.detuning=[0; 0; 0];
%parameters.detuning=0;
%parameters.detuning=0*6.*parameters.omegacarrier;  
%parameters.detuning=[6*parameters.omegacarrier; 0;0;] 

parameters.decoherences.intensity_fluctuations=0
parameters.odesolve=1;
%parameters.eta=[0.0361 0.0361; -0.0274 0.0274]; % the values obtained at one ion condition


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([0],[1 0])'; % Inital States: states(phonon,electronicstates)




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;


%************** Pulse parameters for the Raman motional transfer**************%
aL=60; %length of pulse of MS

%************************************************************************%
fxpaB1=fxpa;
fxpaB2=fxpa;
fxpaB1comp=fxpa; % compensation pulse for motional state transfer
fxpaB2comp=fxpa; % compensation pulse for motional state transfer

fxpaB1.detuning=2*sqrt(2)*parameters.sbomegacarrier*parameters.eta;
fxpaB2.detuning=2*sqrt(2)*parameters.sbomegacarrier*parameters.eta;
%fxpaB2.sbcarrierrabi=.997*fxpa.sbcarrierrabi;
fxpaB1comp.detuning=2*pi*30e3;
fxpaB2comp.detuning=2*pi*30e3;
fxpaB1comp.sbcarrierrabi=sqrt(1-fxpaB1comp.detuning(1)/parameters.omegaz)*fxpa.sbcarrierrabi;
fxpaB2comp.sbcarrierrabi=sqrt(1-fxpaB2comp.detuning(1)/parameters.omegaz)*fxpa.sbcarrierrabi;


%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

timeB1=time;
timeB2=time;
timeB1c=time;
timeB2c=time;

p = p + 1;[pulse(p),time] = Rblue(aL,0,1,1,1,fxpaB1,timeB1);  %MS pulse at ion 1
p = p + 1;[pulse(p),time] = Rblue(aL,0,2,1,1,fxpaB2,timeB2);  %MS pulse at ion 2
p = p + 1;[pulse(p),time] = Rred(aL,0,1,1,1,fxpaB1comp,timeB1c); %
p = p + 1;[pulse(p),time] = Rred(aL,0,2,1,1,fxpaB2comp,timeB2c);  %


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(2,hspace);

%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));

%displaypopulations(T,Y,[1; 0;],hspace);

[PF,PH]=endpopulations(T,Y,hspace);

dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdA.dat',angle(Y), 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdP.dat',abs(Y).*abs(Y), 'delimiter', '\t', 'precision', 4);
%displaypopulations(T,Y,[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1],hspace);
%intstates=[index([0;],[1 0 0 0; ]) index([0;],[0 1 0 0; ]) index([0;],[0 0 1 0; ]) index([0;],[ 0 0 0 1; ])]
%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ]) index([0 0;],[0 0; ]) index([0 1;],[2 0; ]) index([0 0;],[0 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));
%sum(PF(intstates))
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace);

%*****************************************************************************%
%closemessagewindow;
