% simulates the population evolution with experimental imperfections
% requires the scripts in qctools
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at
%
% type <edit simulate> to specify the parameters directly in the script
% 

clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,2);

parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*150.e3;
parameters.omegaz=2*pi*1200000;

parameters.odesolve=1;
parameters.ignorelightshift=0;
%*****************************************************************************%
parameters=recalculateparameters(parameters);
initializepulseparameters
detun=2*pi*50000;
fxpa2=fxpa;
fxpa2.detuning=fxpa.detuning+(detun)*parameters.frequencyscale;
fxpa3=fxpa2;
fxpa3.detuning=parameters.omegaz+fxpa2.detuning;
fxpa3.sbcarrierrabi=fxpa2.sbcarrierrabi*parameters.eta(1);


%****************    Start population         ****************************%
parameters.y0(index(0,[0 1],parameters.hspace))=1;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fp,time)
%  Rblue(theta,phi,ion,transition,fp,time)
%fxpa.detuning=1e5;

%p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+1*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+1*delayunit);
timebk=time;
p = p + 1;[pulse(p),time] = Rred(0.25*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),1,1,1,1,fxpa2,time+(1)*delayunit);
p = p + 1;[pulse(p),time] = Rred(0.25*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),1,1,1,1,fxpa3,timebk+(1)*delayunit);

timebk=time;
p = p + 1;[pulse(p),time] = Rred(0.25*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),0,1,1,1,fxpa2,time+(1)*delayunit);
p = p + 1;[pulse(p),time] = Rred(0.25*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),1,1,1,1,fxpa3,timebk+(1)*delayunit);

%p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+1*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+1*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(0.5,lshift+0.5*mod(parameters.hspace.nuions+1,2),1,1,fxpa,time+420*delayunit);


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[1 0; 0 1;],hspace);
%setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
%YTP=tracedpopulations(T,Y,hspace,1);
%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;