% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,3,[2],0); %definehspace(ions, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=2000;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*170e3; 
parameters.addressing=[0.05 1;1 0.05];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1200000;

parameters.detuning=[2*pi*300; 2*pi*300; 2*pi*300]
%parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0.03;
parameters.intensitymismatch=0;

parameters.odesolve=1;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 1],parameters.hspace))=1;  % Inital States: states(phonon,electronicstates)
%parameters.y0(index(1,[0 0],parameters.hspace))=0.02;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;

fxpacomp=fxpa; % compensation pulse

fxpacomp.detuning=2*pi*50e3;
fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)



%ang=acos(-real(exp(pi/2*i*sqrt(2))))/pi;
timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,1,fxpa,time);
p = p + 1;[pulse(p),time] = Rred(1,0,1,1,1,fxpacomp,timecomp); % compensation laser

p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit); % for the hiding control ion D->S
p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit); % for the hiding control S->E (Auxillary state)

p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+(10)*delayunit);

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,2,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rred(1/sqrt(2),0,2,1,1,fxpacomp,timecomp+delayunit); % compensation laser

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1,0.5,2,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rred(1,0.5,2,1,1,fxpacomp,timecomp+delayunit); % compensation laser

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,2,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rred(1/sqrt(2),0,2,1,1,fxpacomp,timecomp+delayunit); %compensation laser

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1,0.5,2,1,1,fxpa,time+delayunit);
p = p + 1;[pulse(p),time] = Rred(1,0.5,2,1,1,fxpacomp,timecomp+delayunit); %compensation laser

p = p + 1;[pulse(p),time] = Rcar(0.5,1,2,1,fxpa,time+(10)*delayunit);

p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit); % for the recovering the hidden control ion E->S
p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit); % S-> D 

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,1,fxpa,time+1*delayunit);
p = p + 1;[pulse(p),time] = Rred(1,0,1,1,1,fxpacomp,timecomp+1*delayunit); %compensation laser


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
%closemessagewindow;
T=T*fs;;
%displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1;],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
%hold on;

dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
