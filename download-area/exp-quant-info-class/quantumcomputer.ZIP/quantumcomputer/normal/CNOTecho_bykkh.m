% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,[2],0); %definehspace(electronic states, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=1000;
parameters.omegacarrier=2*pi*100e3;
parameters.sbomegacarrier=2*pi*200e3; 
%parameters.addressing=[0.05 1;1 0.05];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1340000;

parameters.detuning=2*pi*300;
parameters.decoherences.detuning_fluctuations=2*pi*100;
parameters.decoherences.intensity_fluctuations=0.03;
%parameters.intensitymismatch=0;

parameters.odesolve=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 1],parameters.hspace))=1;  % Inital States: states(phonon,electronicstates)
%parameters.y0(index(1,[0 0],parameters.hspace))=0.02;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;

fxpacomp=fxpa; % compensation pulse
fxpacomp.detuning=-2*pi*1e6;
fxpacomp.sbcarrierrabi=(1-0.45*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)



%ang=acos(-real(exp(pi/2*i*sqrt(2))))/pi;
doEchoM=0; % Spin echo pulse after every half pulse to correct the error
doSwapEchoM=0;

doEchoK=0; % Spin echo pulse at the middle of pulse of which duration time is same to the total pulse length
doSwapEchoK=0;

compensation=0;

%SWAP I
timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp); end % compensation laser

if doSwapEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
    time=time+1/2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+delayunit);
end

if doSwapEchoK
    p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
    time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+delayunit);
end

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp); end % compensation laser

if doSwapEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
    time=time+1/2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+delayunit);
end

%RAMSEY I
p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+(10)*delayunit);

%PHASEGATE
%first composite pulse
timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2/sqrt(2),0,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2/sqrt(2),0,2,1,fxpacomp,timecomp+delayunit); end % compensation laser

if doEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/2/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

if doEchoK
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2/sqrt(2),0,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2/sqrt(2),0,2,1,fxpacomp,timecomp+delayunit); end % compensation laser

if doEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/2/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

%second composite pulse
timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0.5,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0.5,2,1,fxpacomp,timecomp+delayunit); end % compensation laser

if doEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

if doEchoK
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0.5,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0.5,2,1,fxpacomp,timecomp+delayunit); end % compensation laser

if doEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

%third composite pulse
timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2/sqrt(2),0,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2/sqrt(2),0,2,1,fxpacomp,timecomp+delayunit); end %compensation laser

if doEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/2/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

if doEchoK
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2/sqrt(2),0,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2/sqrt(2),0,2,1,fxpacomp,timecomp+delayunit); end %compensation laser

if doEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/2/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

%forth composite pulse
timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0.5,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0.5,2,1,fxpacomp,timecomp+delayunit); end %compensation laser

if doEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1/2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

if doEchoK
    p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
    time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
end

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0.5,2,1,fxpa,time+delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0.5,2,1,fxpacomp,timecomp+delayunit); end %compensation laser

%RAMSEY II
p = p + 1;[pulse(p),time] = Rcar(0.5,1.23,2,1,fxpa,time+(10)*delayunit);

%SWAP II
timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time+1*delayunit);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp+delayunit); end %compensation laser

if doSwapEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
    time=time+1/2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+delayunit);
end

if doSwapEchoK
    p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
    time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+delayunit);
end

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time);
if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp); end % compensation laser

if doSwapEchoM
    p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
    time=time+1/2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+delayunit);
end

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;;
displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1;],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;

%dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
