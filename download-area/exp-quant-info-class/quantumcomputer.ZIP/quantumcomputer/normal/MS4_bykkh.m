% simulates the Moelmer-Soerense Gate
% Date:   06-Dec-05
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% Contents
% 
% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(4,2,2,0); %definehspace(number of ions, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=400;
parameters.omegacarrier=2*pi*10e3;
parameters.sbomegacarrier=2*pi*120e3; % 2*pi*120e3 in the paper
%parameters.sbomegacarrier=2*pi/(0.15e-3*0.036);
%parameters.addressing=[1 1 1 1; 1 1 1 1; 1 1 1 1; 1 1 1 1;];
%parameters.eigenvectors=[1; 1];
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi;
parameters.detuning=0;

parameters.odesolve=0;
%parameters.eta=[0.0361 0.0361; -0.0274 0.0274]; % the values obtained at one ion condition


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([0],[1 0 1 0])'; % Inital States: states(phonon,electronicstates)


%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;


%************** Pulse parameters for the Raman motional transfer**************%
ro=10;
aL=2*ro; %length of pulse of MS

%************************************************************************%
fxpa4=fxpa;

fxpa13=fxpa;
fxpa12=fxpa;
fxpa23=fxpa;

fxpa4.addressingerror=[1 1 1 1; 1 1 1 1; 1 1 1 1; 1 1 1 1;];
fxpa13.addressingerror=[0 1 0 1 ; 0 0 1 0; 0 1 0 1; 1 0 0 0];
fxpa12.addressingerror=[0 0 1 1 ; 0 0 1 1; 0 1 0 0; 1 0 0 0];
fxpa23.addressingerror=[0 0 0 1 ; 0 1 1 0; 0 1 1 0; 1 0 0 0];


fxpa4.detuning=ro*parameters.sbomegacarrier*parameters.eta;
fxpa13.detuning=ro*parameters.sbomegacarrier*parameters.eta;
fxpa12.detuning=ro*parameters.sbomegacarrier*parameters.eta;
fxpa23.detuning=ro*parameters.sbomegacarrier*parameters.eta;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

p = p + 1;[pulse(p),time] = Rblue(aL*4,0,1,1,1,fxpa4,time);
%p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,1,1,1,fxpa12,time);

%p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,1,1,1,fxpa13,time);
%p = p + 1;[pulse(p),time] = Rblue(aL*1.0,0,1,1,1,fxpa12,time);
%p = p + 1;[pulse(p),time] = Rblue(aL*1.0,0,2,1,1,fxpa23,time);
%p = p + 1;[pulse(p),time] = Rblue(aL*1.0,0,1,1,1,fxpa12,time);
%p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,1,1,1,fxpa13,time);

%p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,1,1,1,fxpa12,time);



%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;;
displaypopulations(T,Y,[0 1 0 1; 1 0 0 1; 0 1 1 0; 1 0 1 0;],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;

%dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdA.dat',angle(Y), 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdP.dat',abs(Y).*abs(Y), 'delimiter', '\t', 'precision', 4);
%displaypopulations(T,Y,[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1],hspace);
%intstates=[index([0;],[1 0 0 0; ]) index([0;],[0 1 0 0; ]) index([0;],[0 0 1 0; ]) index([0;],[ 0 0 0 1; ])]
%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ]) index([0 0;],[0 0; ]) index([0 1;],[2 0; ]) index([0 0;],[0 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));
%sum(PF(intstates))
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace);

%*****************************************************************************%
%closemessagewindow;
