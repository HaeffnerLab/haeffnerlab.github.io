% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(4,2,[2],0);

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=1;
parameters.points=400;
parameters.omegacarrier=1.5*2*pi/29.4e-6;
parameters.sbomegacarrier=2*pi/(0.2e-3*0.03);
%parameters.addressing=[
%  0.01    0.01   0.01    0.01   0.01    0.01 1*0.04       1;... 
%  0.01    0.01     0.01    0.01   0.03 i*0.04      1  -i*0.03;...
%  0.01    0.01   0.01    0.01 1*0.06       1   0.06    0.01;... 
%  0.01    0.01   0.01  1*0.06      1  1*0.06   0.01    0.01;...
%  0.01    0.01   i*0.03      1 -1*0.04    0.01   0.01    0.01;...
%  0.01    0.01      1   1*0.04    0.01    0.03   0.01    0.01;...
% -1*0.03      1 -1*0.04    0.01   0.01    0.01 0.01    0.01   ;...
%  1 i*0.04    0.01    0.03   0.01    0.01 0.01    0.01   ;...
%];
%parameters.addressing=parameters.addressing.*exp(2*pi*i*rand(6,6));
parameters.recoilangle=68;
parameters.omegaz=800000*2*pi;
parameters.detuning=2*pi*0*0.200e3; % 
parameters.intensitymismatch=0.0;
%parameters.eta=[0.015 -0.03 0.015];


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state(0,[ 1 0 0 0])';




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;

fxpa1=fxpa;
fxpa2=fxpa;
fxpa3=fxpa;
fxpa4=fxpa;

Bgradpro5mu=10*2*27*parameters.frequencyscale;
fxpa1.detuning=fxpa1.detuning+(2.5-1)*2*pi*Bgradpro5mu;
fxpa2.detuning=fxpa2.detuning+(2.5-2)*2*pi*Bgradpro5mu;
fxpa3.detuning=fxpa3.detuning+(2.5-3)*2*pi*Bgradpro5mu;
fxpa4.detuning=fxpa4.detuning+(2.5-4)*2*pi*Bgradpro5mu;


%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


%p = p + 1;[pulse(p),time] = Rcar(1,0,3,2,fxpa,time+1*delayunit); 




%p = p + 1;[pulse(p),time] = Rcar(   1,0,1,1,fxpa,time*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(   1,0,2,1,fxpa,time*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(   1,0,3,1,fxpa,time*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(   1,0,4,1,fxpa,time*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(   1,0,5,1,fxpa,time*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(   1,0,6,1,fxpa,time*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(   1,0,7,1,fxpa,time*delayunit);

%p = p + 1;[pulse(p),time] = Rblue(1.02*2*acos(1/sqrt(8))/pi,0,8,1,fxpa,time+15*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(0.9*2*asin(1/sqrt(7))/pi,0,7,1,fxpa,time+15*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(0.9*2*asin(1/sqrt(6))/pi,0,6,1,fxpa,time+15*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(0.9*2*asin(1/sqrt(5))/pi,0,5,1,fxpa,time+15*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(0.9*2*asin(1/sqrt(4))/pi,0,4,1,fxpa,time+15*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(0.9*2*asin(1/sqrt(3))/pi,0,3,1,fxpa,time+15*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(0.9*2*asin(1/sqrt(2))/pi,0,2,1,fxpa,time+15*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(1*2*asin(1/sqrt(1))/pi,0,1,1,fxpa,time+15*delayunit);
p = p + 1;[pulse(p),time] = Rblue(2*acos(1/sqrt(4))/pi,0,4,1,fxpa1,time+15*delayunit);
p = p + 1;[pulse(p),time] = Rblue(2*asin(1/sqrt(3))/pi,0,3,1,fxpa2,time+15*delayunit);
p = p + 1;[pulse(p),time] = Rblue(2*asin(1/sqrt(2))/pi,0,2,1,fxpa3,time+15*delayunit);
p = p + 1;[pulse(p),time] = Rblue(2*asin(1/sqrt(1))/pi,0,1,1,fxpa4,time+15*delayunit);



%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(1,hspace);
%displaypopulations(T,Y,[1 0 0 0 0; 0 1 0 0 0; 0 0 1 0 0; 0 0 0 1 0; 0 0 0 0 1],hspace);
intstates=[index([0;],[1 0 0 0 0 0 0 0; ]) index([0;],[0 1 0 0 0 0 0 0; ]) index([0;],[0 0 1 0 0 0 0 0; ]) index([0;],[0 0 0 1  0 0 0 0; ]) index([0;],[0 0 0 0 1 0 0 0; ]) index([0;],[0 0 0 0 0 1 0 0; ]) index([0;],[0 0 0 0 0 0 1 0; ]) index([0;],[0 0 0 0 0 0 0 1; ])]
hspace.visible=zeros(1,hspace.dimensions);
hspace.visible(intstates)=ones(1,length(intstates));
[PF,PH]=endpopulations(T,Y,hspace);

me=sum(PF(intstates))
gm=(prod(PF(intstates)))^(1/length(intstates))*length(intstates)

w=[1 1 1 1 1 1 1 1];

fid=((abs(Y(size(Y,1),intstates)))*[ 1 1 1 1 1 1 1 1]'/sqrt(8))^2

allintstates=find(PF>0.005);
hspace.visible=zeros(1,hspace.dimensions);
hspace.visible(allintstates)=ones(1,length(allintstates));
[PF,PH]=endpopulations(T,Y,hspace);
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace,1);

%*****************************************************************************%
closemessagewindow;
