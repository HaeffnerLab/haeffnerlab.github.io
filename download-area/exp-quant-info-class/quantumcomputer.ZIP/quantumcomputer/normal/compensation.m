% simulates the population evolution with experimental imperfections
% requires the scripts in qctools
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at
%
% type <edit simulate> to specify the parameters directly in the script
% 

clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,2);
parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*300.e3;
parameters.omegaz=2*pi*2100000;
%parameters.decoherences.intensity_fluctuations=0.3;

parameters.odesolve=1;
%*****************************************************************************%
parameters=recalculateparameters(parameters);

initializepulseparameters
fxpa.includelsdetuning=0;

fxpacomp=fxpa;   % compensation pulse
fxpacomp.detuning=2*pi*500000;   % detuning for compensation pulse
fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;


%****************    Start population         ****************************%
parameters.y0(index(0,[1 1],parameters.hspace))=1;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fp,time)
%  Rblue(theta,phi,ion,transition,fp,time)

%p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+1*delayunit);

timbk=time;
p = p + 1;[pulse(p),time] = Rblue(2,1,1,1,fxpa,time+3*delayunit); 
p = p + 1;[pulse(p),time] = Rred(2,1,1,1,fxpacomp,timbk+3*delayunit); 

%p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+3*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0 0; 1 0;],hspace);
setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
%YTP=tracedpopulations(T,Y,hspace,1);
%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;