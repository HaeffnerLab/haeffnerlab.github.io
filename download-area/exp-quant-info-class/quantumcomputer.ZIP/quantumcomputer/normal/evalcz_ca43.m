cz=getsimmatrix('czcnot_ca43');
setstatevisibility(0);
dispabsmat(cz)