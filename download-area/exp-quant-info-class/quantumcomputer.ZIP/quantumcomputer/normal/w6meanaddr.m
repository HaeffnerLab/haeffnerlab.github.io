%calculates the mean influence of addressing errors if w6 is modified
%accordingly

for(i1=1:10)
    w6
    fi(i1)=fid;
end;

meanfid=mean(fi)