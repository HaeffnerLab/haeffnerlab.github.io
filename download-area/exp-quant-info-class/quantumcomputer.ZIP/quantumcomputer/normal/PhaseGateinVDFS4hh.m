% simulates the Moelmer-Soerense Gate
% Date:   06-Dec-05
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% Contents
% 
% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(4,2,2,0); %definehspace(number of ions, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=300;
parameters.omegacarrier=2*pi*100e3;
parameters.sbomegacarrier=2*pi*200.5975e3; % 2*pi*120e3 in the paper
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi;
parameters.detuning=0;

parameters.odesolve=0;
%parameters.eta=[0.0361 0.0361; -0.0274 0.0274]; % the values obtained at one ion condition


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([0],[1 0 0 1])'; % Inital States: states(phonon,electronicstates)

%********************** Pulse Shaping Parameters *********************

shape.steps=20;
shape.time=3;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;


%************** Pulse parameters for the Raman motional transfer**************%

fxpa13a=fxpa;
fxpa13f=fxpa;
fxpa12=fxpa;
fxpa12f=fxpa;
fxpa12r=fxpa;
fxpa12rf=fxpa;
fxpa23=fxpa;
fxpa34=fxpa;

%fxpa13.addressingerror=[0.05 1 0.05 1 ; 0 0 1 0; 0.05 1 0.05 1; 1 0 0 0];
fxpa13.addressingerror=[0 1 0 1 ; 0 0 1 0; 0 1 0 1; 1 0 0 0];
%fxpa13f.addressingerror=[0 1 0 1 ; 0 0 1 0; 0 1 0 1; 1 0 0 0];
fxpa12.addressingerror=[0 0 1 1 ; 0 0 1 1; 0 1 0 0; 1 0 0 0];
%fxpa12f.addressingerror=[0 0 1 1 ; 0 0 1 1; 0 1 0 0; 1 0 0 0];
%fxpa12r.addressingerror=[0 0 1 1 ; 0 0 1 1; 0 1 0 0; 1 0 0 0];
%fxpa12rf.addressingerror=[0 0 1 1 ; 0 0 1 1; 0 1 0 0; 1 0 0 0];
fxpa23.addressingerror=[0 0 0 1 ; 0 1 1 0; 0 1 1 0; 1 0 0 0];
fxpa34.addressingerror=[0 0 0 1 ; 0 0 1 0; 1 1 0 0; 1 1 0 0];

ro=10;
aL=2*ro; %length of pulse of MS

fxpa13.detuning=ro*parameters.sbomegacarrier*parameters.eta;
%fxpa13f.detuning=ro*parameters.sbomegacarrier*parameters.eta;
fxpa12.detuning=ro*parameters.sbomegacarrier*parameters.eta;
%fxpa12f.detuning=ro*parameters.sbomegacarrier*parameters.eta;
%fxpa12r.detuning=ro*parameters.sbomegacarrier*parameters.eta;
%fxpa12rf.detuning=ro*parameters.sbomegacarrier*parameters.eta;
fxpa23.detuning=ro*parameters.sbomegacarrier*parameters.eta;
fxpa34.detuning=ro*parameters.sbomegacarrier*parameters.eta;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,3,1,1,fxpa34,time); % Ramsey Pulse in DFS

p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,1,1,1,fxpa13,time);
p = p + 1;[pulse(p),time] = Rblue(aL*1.0,0,1,1,1,fxpa12,time);
p = p + 1;[pulse(p),time] = Rblue(aL*1.0,0,2,1,1,fxpa23,time);
p = p + 1;[pulse(p),time] = Rblue(aL*1.0,0,1,1,1,fxpa12,time);
p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,1,1,1,fxpa13,time);

p = p + 1;[pulse(p),time] = Rblue(aL*0.5,0,3,1,1,fxpa34,time); % Ramsey Pulse in DFS

%[pulse1,time] = Rshape(aL*0.5,0,1,1,fxpa12,time,shape); pulse=pulse1;

%[pulse1,time] = Rshape(aL*0.5,0,1,1,fxpa13,time,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rshape(aL*1.0,0,1,1,fxpa12,time,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rshape(aL*1.0,0,2,1,fxpa23,time,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rshape(aL*1.0,0,1,1,fxpa12,time,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rshape(aL*0.5,0,1,1,fxpa13,time,shape); pulse=[pulse,pulse1];

%[pulse1,time] = Rshape(aL*0.5,0,1,1,fxpa12,time,shape); pulse=[pulse,pulse1];
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;;
displaypopulations(T,Y,[0 1 0 1; 1 0 0 1; 0 1 1 0; 1 0 1 0; 0 0 1 1; 1 1 0 0],hspace);
tracedpopulations(T,Y,hspace,1);
[PF,PH]=endpopulations(T,Y,hspace);
hold on;
%dlmwrite('kkdT2.dat',T, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdP2.dat',abs(Y).*abs(Y), 'delimiter', '\t', 'precision', 4);
%*****************************************************************************%
%closemessagewindow;

print -dpng -r300 W7_20050701ISQM
print -depsc -r300 W7_20050701ISQM
