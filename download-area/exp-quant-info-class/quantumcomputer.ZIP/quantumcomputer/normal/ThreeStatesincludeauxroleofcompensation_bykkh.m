% simulates the population evolution with experimental imperfections
% Date:   29-Nov-05
% Author: kihwan Kim <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(1,3,[1 1],0);

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=20;
parameters.omegacarrier=2*pi*15e3;
parameters.sbomegacarrier=2*pi*300e3;
%parameters.sbomegacarrier=2*pi/(0.15e-3*0.036);
%parameters.addressing=[0.00 0.00 0.01 i*0.04 1; 0.00 0.01 -i*0.04 1 0.03; 0.01 -0.03 1 0.04 0.01; i*0.04 1 -0.03 0.01 0.00; 1 i*0.04 0.01  0.00 0.00;];
%parameters.addressing=[1 1;1 1];
parameters.eigenvectors=[1 1; 1 -1;];
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi*[1 sqrt(3)];
%parameters.detuning=[0; 10*parameters.omegacarrier; 0];
%parameters.detuning=0*6.*parameters.omegacarrier;  
%parameters.detuning=[6*parameters.omegacarrier; 0;0;] 

parameters.decoherences.intensity_fluctuations=0
parameters.odesolve=1;
%parameters.eta=[0.015 -0.03 0.015];


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([0 0],[1])';




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;

fxpa1=fxpa;
fxpa2=fxpa;
fxpacomp=fxpa; % compensation pulse

fxpa1.detuning=[0; 10*parameters.omegacarrier; 0];
fxpa2.detuning=[0; 9*parameters.omegacarrier; 0];

fxpacomp.detuning=[0; 2*pi*200000; 0]; % detuning for compensation pulse
%fxpacomp.detuning=[0; -2*pi*5000000; 0];
fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning(2)/parameters.omegaz(2))*fxpa.sbcarrierrabi;
%fxpacomp.sbcarrierrabi=5*fxpa.sbcarrierrabi;
%fxpa2.detuning=0.*1.5e5;
%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)
%p = p + 1;[pulse(p),time] = Rcar(2,0,1,1,fxpa,time+1*delayunit);

p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,3,fxpa1,time);

timeR2=time;
timec=time;

%p = p + 1;[pulse(p),time] = Rcar(5*parameters.omegacarrier/parameters.eta(2)/parameters.sbomegacarrier,0,1,2,fxpa1,time+3*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(5,0,1,2,2,fxpa2,timeR2+3*delayunit);
p = p + 1;[pulse(p),time] = Rred(5,0,1,2,2,fxpacomp,timec+3*delayunit); 

p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,3,fxpa1,time+1*delayunit);

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(2,hspace);
displaypopulations(T,Y,[1; 0; 2 ],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%sum(PF(intstates))
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace);

%*****************************************************************************%
closemessagewindow;
