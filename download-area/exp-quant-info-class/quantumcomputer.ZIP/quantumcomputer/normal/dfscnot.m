% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

hspace=definehspace(4,2,3);

parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi/41e-6;
parameters.sbomegacarrier=2*pi*165e3;
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi;
parameters.points=50;
%parameters.detuning(1)=2*pi*1000
parameters.addressing=[1 1 0 0; 0 1 0 0; 0 0 1 1; 0 0 0 1;];
%parameters.odesolve=1;
%parameters.ignorelightshift=0;


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 0 1 0],parameters.hspace))=1;


initializepulseparameters


%****************** Definitions for the pulse definition  ***********************%
detun=2*pi*40000;
fxpa2=fxpa;
fxpa2.detuning=fxpa.detuning+(detun)*parameters.frequencyscale;


%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

timebk=time;

p = p + 1;[pulse(p),time] = Rblue(1*detun/(parameters.eta(1)*parameters.sbomegacarrier),1,3,1,1,fxpa2,time+(1)*delayunit);


%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0 1 0 1; 0 1 1 0 ; 1 0 0 1; 1 0 1 0;],hspace);
%setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;