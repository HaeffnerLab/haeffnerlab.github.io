% simulates the population evolution with experimental imperfections
% Date:   22-Nov-03
% Author: Hartmut H???fner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;
clear parameters;


hide=0;
spinecho1=0
spinecho3=0

if(hide)
   hspace=definehspace(3,3,2,0);
else
   hspace=definehspace(3,2,2,0);
end;

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=1;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*200e3;
%parameters.addressing=[1 0.02 0.02; 0.04 1 0.04; 0.02 0.02 1];
parameters.recoilangle=68;
parameters.points=1200;
parameters.omegaz=1200000*2*pi;


parameters.detuning(1)=1*0*pi*300;             % detuning
parameters.detuning(2)=0*5*parameters.detuning(1);			 % detuning of aux level

parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0.03;
%parameters.intensitymismatch=0.1;         %   5% infidelity

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 1 1],parameters.hspace))=1;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)


%algpart1=Ublue(0.5,-0.5+dphi(1),addre(3,:))*[1 zeros(1,hspace.dimensions-1)]';
%algpart2=Ucar(0.5,spinecho3+0.5+dphi(16),addre(3,:))*Ucar(spinecho1,1.5+dphi(14),addre(1,:))*Ucar(spinecho3,0.5+dphi(13),addre(3,:))*Ucar(0.5,0.5+dphi(13),addre(2,:))*Ucar(0.5,0.5+dphi(12),addre(1,:))*Ublue(1,0.5+dphi(11),addre(2,:))*Ucar(1,-0.5+dphi(10),addre(2,:))*Ucar(spinecho1,0.5+dphi(10),addre(1,:))*Ublue(1,0+dphi(9),addre(1,:))*Ublue(1/sqrt(2),0.5+dphi(8),addre(1,:))*Ublue(1,0+dphi(7),addre(1,:))*Ublue(1/sqrt(2),0.5+dphi(6),addre(1,:));

%Different state preparations.
%S  =algpart2                *algpart1;
%D  =algpart2*Ucar(1,0+dphi(2),addre(1,:))    *algpart1;
%SDX=algpart2*Ucar(0.5,0+dphi(2),addre(1,:))  *algpart1;
%SDY=algpart2*Ucar(0.5,0.5+dphi(2),addre(1,:))*algpart1;


p = p + 1;[pulse(p),time] = Rblue(0.5,1.5,3,1,fxpa,time+(1)*delayunit);  % Entanglement with the motion
p = p + 1;[pulse(p),time] = Rcar( 1,  1.5,2,1,fxpa,time+(1)*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,  0.5,2,1,fxpa,time+(1)*delayunit);
%time=time+20000;
if(hide)
   p = p + 1;[pulse(p),time] = Rcar(1,0,3,2,fxpa,time+(1)*delayunit);
end;

preppulses=p+1;
%p = p + 1;[pulse(p),time] = Rcar( 1  , 0  ,1,1,fxpa,time+(1)*delayunit);   % Preparation
%p = p + 1;[pulse(p),time] = Rcar( 0.5, 0  ,1,1,fxpa,time+(1)*delayunit);   % Preparation
%p = p + 1;[pulse(p),time] = Rcar( 0.5, 0.5,1,1,fxpa,time+(1)*delayunit);   % Preparation

p = p + 1;[pulse(p),time] = Rblue(1,   1.5,2,1,fxpa,time+(1)*delayunit);

%p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,1,1,fxpa,time+0*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(1,        0  ,1,1,fxpa,time+0*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,1,1,fxpa,time+0*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(1,        0  ,1,1,fxpa,time+0*delayunit);


if(spinecho1)
%	p = p + 1;[pulse(p),time] = Rcar( 1,   0.5,1,1,fxpa,time+(1)*delayunit); %spin echo
end;
if(spinecho3)
	if(hide)
%   		p = p + 1;[pulse(p),time] = Rcar(1,1,3,2,fxpa,time+(1)*delayunit);
%		p = p + 1;[pulse(p),time] = Rcar(1,0,3,1,fxpa,time+(1)*delayunit); %spin echo
%   		p = p + 1;[pulse(p),time] = Rcar(1,0,3,2,fxpa,time+(1)*delayunit);
	else
% 		p = p + 1;[pulse(p),time] = Rcar(   1, 0.5,3,1,fxpa,time+(1)*delayunit); %spin echo
   end;
end;

%p = p + 1;[pulse(p),time] = Rblue(1,   0.5,2,1,fxpa,time+(1)*delayunit);


if(spinecho1)
%	p = p + 1;[pulse(p),time] = Rcar( 0.5, 1.5,1,1,fxpa,time+(1)*delayunit);
else
%	p = p + 1;[pulse(p),time] = Rcar( 0.5, 0.5,1,1,fxpa,time+(1)*delayunit);
end;
%p = p + 1;[pulse(p),time] = Rcar( 0.5, 0.5,2,1,fxpa,time+(1)*delayunit);


if(hide)
%   p = p + 1;[pulse(p),time] = Rcar(1,0,2,2,fxpa,time+(1)*delayunit);
end;
time=time+25;
if(hide)
%   p = p + 1;[pulse(p),time] = Rcar(1,1,2,2,fxpa,time+(1)*delayunit);
%   p = p + 1;[pulse(p),time] = Rcar(1,0,1,2,fxpa,time+(1)*delayunit);
end;
time=time+25;
if(hide)
%   p = p + 1;[pulse(p),time] = Rcar(1,1,1,2,fxpa,time+(1)*delayunit);
%   p = p + 1;[pulse(p),time] = Rcar(1,1,3,2,fxpa,time+(1)*delayunit);
end;

if(hide)
%  	p = p + 1;[pulse(p),time] = Rcar(0.5,0.5,3,1,fxpa,time+(1)*delayunit);  % inverse^2 because of spin-echo and hide.
else
%	p = p + 1;[pulse(p),time] = Rcar(0.5,0.5+spinecho3,3,1,fxpa,time+(1)*delayunit);  % inverse because of spin-echo
end;
%X=Ucar(1,0+dphi(20),addre(3,:));
%Z=Ucar(1,0.5+dphi(22),addre(3,:))*Ucar(1,0+dphi(21),addre(3,:));

reconstructionpulses=p+1;
%p = p + 1;[pulse(p),time] = Rcar(1,0  ,3,1,fxpa,time+(1)*delayunit);   % 1st part of Z
%p = p + 1;[pulse(p),time] = Rcar(1,0.5,3,1,fxpa,time+(1)*delayunit);   % 2nd part of ZX

%p = p + 1;[pulse(p),time] = Rcar(1,0,3,1,fxpa,time+(1)*delayunit);   % X


inversepreppulses=p+1;
%p = p + 1;[pulse(p),time] = Rcar(1,  1,  3,1,fxpa,time+(1)*delayunit);   % Inverse preparation
%p = p + 1;[pulse(p),time] = Rcar(0.5,1,  3,1,fxpa,time+(1)*delayunit);   % Inverse preparation
%p = p + 1;[pulse(p),time] = Rcar(0.5,1.5,3,1,fxpa,time+(1)*delayunit);   % Inverse preparation


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
setstatevisibility(1,hspace);
displaypopulations(T,Y,[1 1 1; 1 0 1; 1 1 0;],hspace);
setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
phonontracedpopulations(T,Y,[0 0 0; 0 0 1; 0 1 0;  0 1 1; 1 0 0; 1 0 1; 1 1 0;  1 1 1;],hspace,1);

closemessagewindow;
%*****************************************************************************%
