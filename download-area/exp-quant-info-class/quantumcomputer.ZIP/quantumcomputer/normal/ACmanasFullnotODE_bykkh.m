% simulates the phase evolution with experimental imperfections
% Date:   06-Dec-05
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% Contents
% The pase gate in DFS by Manas
% SD,1,0 -> SD,1,0 -> -i SD,1,0  -> -i SD,1,0
% SS,1,0 -> SS,1,0 ->  i SS,1,0  ->  i SS,1,0
% DD,1,0 -> DD,0,1 ->    DD,0,1  ->    DD,1,0
% DS,1,0 -> DS,0,1 ->    DS,0,1  ->    DS,1,0
% 
% Because of the problem of simulation, the auxilary state S is coupled to
% D state not E state, which is quite different from usual notation. However,
% the basic physics and results are independent of them.
%
% In the simulation we check the above phase gate by the following way
% DE,1,0 -> DE,1,0 -> D(E-D),0,1 -> D(  E- D),1,0 ->  DE,1,0 ->  DE,1,0
% DD,1,0 -> DD,1,0 -> D(D+E),0,1 -> D(  D+ E),1,0 ->  DD,1,0 ->  DD,1,0
% EE,1,0 -> EE,0,1 -> E(E-D),1,0 -> E(-iE-iD),0,1 -> -ED,0,1 -> -ED,1,0
% ED,1,0 -> ED,0,1 -> E(D+E),1,0 -> E( iD-iE),0,1 ->  EE,0,1 ->  EE,1,0
% sequence
% Raman2(1,0) R1(1,1)(ManasPhasegate on #1 ion) R1(1,0) Raman2(1,0)

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,3,[2 2],0); %definehspace(electronic states, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=400;
parameters.omegacarrier=2*pi*1e3;
parameters.sbomegacarrier=2*pi*120e3; % 2*pi*120e3 in the paper
%parameters.sbomegacarrier=2*pi/(0.15e-3*0.036);
%parameters.addressing=[0.00 0.00 0.01 i*0.04 1; 0.00 0.01 -i*0.04 1 0.03; 0.01 -0.03 1 0.04 0.01; i*0.04 1 -0.03 0.01 0.00; 1 i*0.04 0.01  0.00 0.00;];
parameters.addressing=[0 1 ; 1 0];
parameters.eigenvectors=[1 1; -1 1;];
%parameters.eigenvectors=[1; 1];
parameters.recoilangle=68;
parameters.omegaz=1000000*2*pi*[1 sqrt(3)];
%parameters.omegaz=1200000*2*pi*[1 sqrt(3)];
parameters.detuning=[0; 0; 0];
%parameters.detuning=0;
%parameters.detuning=0*6.*parameters.omegacarrier;  
%parameters.detuning=[6*parameters.omegacarrier; 0;0;] 

parameters.decoherences.intensity_fluctuations=0
parameters.odesolve=0;
%parameters.eta=[0.0361 0.0361; -0.0274 0.0274]; % the values obtained at one ion condition


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([1 0],[0 0])'; % Inital States: states(phonon,electronicstates)




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;


%************** Pulse parameters for the Raman motional transfer**************%
aR=2*3.9; %length of pulse of transfering 10 to 01
bR=1; %transition: 1)S->D 2)E->D 3)S->E
cRc=1; %mode 1)common mode 2)streching mode
cRb=2;

%************** Pulse parameters for the AC stark shift gate**************%
aa=2*1.81; %length of pulse aa=4 in the paper 2*5.3564 at the calculation
bb=2; %transition: 1)S->D 2)E->D 3)S->E
cc=1; %mode 1)common mode 2)streching mode

%************************************************************************%
fxpaRc=fxpa;
fxpaRb=fxpa;
fxpaRccomp=fxpa; % compensation pulse for motional state transfer
fxpaRbcomp=fxpa; % compensation pulse for motional state transfer

fxpaRc.detuning=[4*parameters.sbomegacarrier*parameters.eta(cRc); 0; 0];
fxpaRb.detuning=[4*parameters.sbomegacarrier*parameters.eta(cRc); 0; 0];
fxpaRccomp.detuning=[2*pi*30e3; 0; 0];
fxpaRbcomp.detuning=[2*pi*30e3; 0; 0];
fxpaRccomp.sbcarrierrabi=fxpa.sbcarrierrabi;
fxpaRbcomp.sbcarrierrabi=fxpa.sbcarrierrabi;

fxpaRamsey=fxpa;
fxpaAC=fxpa;
fxpaACcomp=fxpa; % compensation pulse

fxpaAC.detuning=[0; 3*parameters.sbomegacarrier*parameters.eta(cc); 0];
fxpaACcomp.detuning=[0; -2*pi*42e3; 0];
fxpaACcomp.sbcarrierrabi=fxpa.sbcarrierrabi;
%fxpa2.detuning=2*pi*10e3; %60e3 in the paper
%fxpa1.detuning=[0; 0*10*parameters.sbomegacarrier*parameters.eta(cc); 0];
%fxpa2.detuning=[0; 0*10*parameters.sbomegacarrier*parameters.eta(cc); 0];

%fxpacomp.detuning=[0; 0*10*parameters.sbomegacarrier*parameters.eta(cc); 0]; % detuning for compensation pulse

%fxpacomp.sbcarrierrabi=fxpa.sbcarrierrabi;
%fxpacomp.sbcarrierrabi=5*fxpa.sbcarrierrabi;
%fxpa2.detuning=0.*1.5e5;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

timeRc=time;
timeRb=time;
timeRcc=time;
timeRcb=time;

p = p + 1;[pulse(p),time] = Rred(aR,0,2,cRc,bR,fxpaRc,timeRc); %Raman pulse from 1,0 to 0,0 for only D level
p = p + 1;[pulse(p),time] = Rred(aR,0,2,cRb,bR,fxpaRb,timeRb);  %Raman Pulse from 0,0 to 0,1 for only D level
%p = p + 1;[pulse(p),time] = Rblue(aR,0,2,cRc,bR,fxpaRccomp,timeRcc);  %compensation of RamanRc Pulse
%p = p + 1;[pulse(p),time] = Rblue(aR,0,2,cRb,bR,fxpaRbcomp,timeRcb);  %compensation of RamanRb Pulse

time0=time;
p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,bb,fxpaRamsey,time0+1*delayunit); % 1st Ramsey Pulse

timeAC=time;
timeACc=time;

p = p + 1;[pulse(p),time] = Rblue(aa,0,1,cc,bb,fxpaAC,timeAC+1*delayunit); % Ac Starkshift Laser
%p = p + 1;[pulse(p),time] = Rred(aa,0,1,cc,bb,fxpaACcomp,timeACc+1*delayunit); % Compensation Laser

time0=time;
p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,bb,fxpaRamsey,time0+2*delayunit); % 2nd Ramsey Pulse, The phase is determined by the compensation of the phase evolution of 01 states

timeRc=time;
timeRb=time;
timeRcc=time;
timeRcb=time;

p = p + 1;[pulse(p),time] = Rred(aR,0,2,cRc,bR,fxpaRc,timeRc+1*delayunit); %Raman pulse from 1,0 to 0,0 for only D level
p = p + 1;[pulse(p),time] = Rred(aR,0,2,cRb,bR,fxpaRb,timeRb+1*delayunit);  %Raman Pulse from 0,0 to 0,1 for only D level
%p = p + 1;[pulse(p),time] = Rblue(aR,0,2,cRc,bR,fxpaRccomp,timeRcc+1*delayunit);  %compensation of RamanRc Pulse
%p = p + 1;[pulse(p),time] = Rblue(aR,0,2,cRb,bR,fxpaRbcomp,timeRcb+1*delayunit);  %compensation of RamanRb Pulse


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(2,hspace);

%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));

%displaypopulations(T,Y,[1; 0;],hspace);

[PF,PH]=endpopulations(T,Y,hspace);

%dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdA.dat',angle(Y), 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdP.dat',abs(Y).*abs(Y), 'delimiter', '\t', 'precision', 4);

displaypopulations(T,Y,[0 0; 2 0; 0 2; 2 2],hspace); 
%displaypopulations(T,Y,[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1],hspace);
%intstates=[index([0;],[1 0 0 0; ]) index([0;],[0 1 0 0; ]) index([0;],[0 0 1 0; ]) index([0;],[ 0 0 0 1; ])]
%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ]) index([0 0;],[0 0; ]) index([0 1;],[2 0; ]) index([0 0;],[0 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));
%sum(PF(intstates))
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace);

%*****************************************************************************%
closemessagewindow;
