% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*160e3;
parameters.hspace.nuions=2;
parameters.hspace.maxphonons=3;
parameters.addressing=[1 0.05; 0.05 1];

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0 0],parameters.hspace))=1;



%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

fxpa2=fxpa;
fxpa2.detuning=2*pi*0*parameters.frequencyscale;



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

p = p + 1;[pulse(p),time] = Rblue(0.5,0,1,1,fxpa,time+14*delayunit); 
p = p + 1;[pulse(p),time] = Rred(1,1,2,1,fxpa2,time+(20)*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0 0; 1 0; 1 1; 1 1;],hspace);
endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
hold on;
%*****************************************************************************%
closemessagewindow;