% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,2);

parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi/41e-6;
parameters.sbomegacarrier=2*pi*220e3;
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi;
parameters.ignorelightshift=0;
%parameters.detuning(1)=2*pi*1000


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 1],parameters.hspace))=1;




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;

%*****************************************************************************%



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

%p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+(10)*delayunit); 
delayunit=0;
p = p + 1;[pulse(p),time] = Rblue(0.25,0,1,1,fxpa,time);
time=time+rand*delayunit; 
p = p + 1;[pulse(p),time] = Rblue(0.25,0,1,1,fxpa,time); 
time=time+rand*delayunit; 
p = p + 1;[pulse(p),time] = Rblue(0.25,0,1,1,fxpa,time); 
time=time+rand*delayunit; 
p = p + 1;[pulse(p),time] = Rblue(0.25,0,1,1,fxpa,time); 
time=time+rand*delayunit; 
 


%p = p + 1;[pulse(p),time] = Rcar(2,0,1,1,fxpa,time+(20)*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0 0; 1 0 ; 1 0; 1 1;],hspace);
%setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;