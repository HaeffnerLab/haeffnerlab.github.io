load scan5ions
for k=1:size(PF,1)
   pa(k)=parity(PF(k,:));
end;

figure(1);
clf;
plot([1:size(pa,2)]/(size(pa,2))*2*pi,pa,'k*-');

change_fig_for_trans(gcf);
ylabel('Parity')
xlabel('Phase (rad)')
axis([0 2*pi+0.07 -1 1]);
print -depsc2 plotscan5ion