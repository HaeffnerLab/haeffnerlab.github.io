% simulates the phase evolution with experimental imperfections
% Date:   06-Dec-05
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% Contents
% The parameters are based on the paper of Europhys. Lett. 65, 587 (2004)
% The effect of laser of both detuned blue sideband and compensation
% laer, produce the following truth table. 
% S,0 -> S,0
% D,0 -> D,0
% S,1 -> i S,1
% D,1 -> -i D,1
% This is checked by Ramsey experiment simulation that has the following
% sequence
% R2(0.5,1)Acstarkshiftgate R1(0.5,0)

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,[2],0);

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=400;
parameters.omegacarrier=2*pi*12e3;
parameters.sbomegacarrier=2*pi*120e3;
%parameters.sbomegacarrier=2*pi/(0.15e-3*0.036);
%parameters.addressing=[0.00 0.00 0.01 i*0.04 1; 0.00 0.01 -i*0.04 1 0.03; 0.01 -0.03 1 0.04 0.01; i*0.04 1 -0.03 0.01 0.00; 1 i*0.04 0.01  0.00 0.00;];
%parameters.addressing=[0 1 ;1 0 ];
%parameters.eigenvectors=[1 1; 1 -1;];
parameters.recoilangle=68;
%parameters.omegaz=1200000*2*pi*[1 sqrt(3)];
parameters.omegaz=1200000*2*pi;
%parameters.detuning=[0; 0; 0];
parameters.detuning=0;
%parameters.detuning=0*6.*parameters.omegacarrier;  
%parameters.detuning=[6*parameters.omegacarrier; 0;0;] 

parameters.decoherences.intensity_fluctuations=0
parameters.odesolve=1;
%parameters.eta=[0.015 -0.03 0.015];


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([0],[1])'; % Inital States: states(phonon,electronicstates)




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;

aa=4; %length of pulse
bb=1; %transition: 1)S->D 2)E->D 3)S->E
cc=1; %mode 1)common mode 2)streching mode

fxpa1=fxpa;
fxpa2=fxpa;
fxpacomp=fxpa; % compensation pulse

fxpa2.detuning=2*pi*10e3;
%fxpa1.detuning=[0; 0*10*parameters.sbomegacarrier*parameters.eta(cc); 0];
%fxpa2.detuning=[0; 0*10*parameters.sbomegacarrier*parameters.eta(cc); 0];

%fxpacomp.detuning=[0; 0*10*parameters.sbomegacarrier*parameters.eta(cc); 0]; % detuning for compensation pulse
fxpacomp.detuning=-2*pi*100e3;
%fxpacomp.sbcarrierrabi=fxpa.sbcarrierrabi;
fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning(cc)/parameters.omegaz(cc))*fxpa.sbcarrierrabi;
%fxpacomp.sbcarrierrabi=5*fxpa.sbcarrierrabi;
%fxpa2.detuning=0.*1.5e5;
%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)
%p = p + 1;[pulse(p),time] = Rcar(2,0,1,1,fxpa,time+1*delayunit);

time0=time;
p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time); % 1st Ramsey Pulse
%p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,3,fxpa,time0);

time2=time;
time4b=time;
time4b2=time;
timec=time;
timec2=time;



%p = p + 1;[pulse(p),time] = Rcar(aa*parameters.omegacarrier/parameters.eta(cc)/parameters.sbomegacarrier,0,1,bb,fxpa1,time+3*delayunit); 
%p = p + 1;[pulse(p),time] = Rcar(aa*parameters.omegacarrier/parameters.eta(cc)/parameters.sbomegacarrier,0,2,bb,fxpa1,time2+3*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(aa,0,1,cc,bb,fxpa2,time4b+3*delayunit); % Ac Starkshift Laser
%p = p + 1;[pulse(p),time] = Rblue(aa,0,2,cc,bb,fxpa2,time4b2+3*delayunit);


p = p + 1;[pulse(p),time] = Rred(aa,0,1,cc,bb,fxpacomp,timec+3*delayunit); % Compensation Laser
%p = p + 1;[pulse(p),time] = Rred(aa,0,2,cc,bb,fxpacomp,timec2+3*delayunit); 

time0=time;
p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+1*delayunit); % 2nd Ramsey Pulse
%p = p + 1;[pulse(p),time] = Rcar(0.5,1,2,3,fxpa,time0+1*delayunit);

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(2,hspace);

%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));

displaypopulations(T,Y,[1; 0;],hspace);

[PF,PH]=endpopulations(T,Y,hspace);

dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);
dlmwrite('kkdA.dat',angle(Y), 'delimiter', '\t', 'precision', 4);
%displaypopulations(T,Y,[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1],hspace);
%intstates=[index([0;],[1 0 0 0; ]) index([0;],[0 1 0 0; ]) index([0;],[0 0 1 0; ]) index([0;],[ 0 0 0 1; ])]
%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ]) index([0 0;],[0 0; ]) index([0 1;],[2 0; ]) index([0 0;],[0 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));
%sum(PF(intstates))
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace);

%*****************************************************************************%
closemessagewindow;
