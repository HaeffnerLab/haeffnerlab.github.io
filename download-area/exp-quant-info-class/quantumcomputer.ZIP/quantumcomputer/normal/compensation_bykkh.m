% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,1,0); %definehspace(ions, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=1000;
parameters.omegacarrier=2*pi*100e3;
parameters.sbomegacarrier=2*pi*200e3; 
%parameters.addressing=[0.05 1;1 0.05];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1340000;

parameters.detuning=0;
%parameters.decoherences.detuning_fluctuations=2*pi*300;
%parameters.decoherences.intensity_fluctuations=0.05;
%parameters.intensitymismatch=0;

parameters.odesolve=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([0],[1 1])'; % Inital States: states(phonon,electronicstates)
  % Inital States: states(phonon,electronicstates)

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;

%fxpacomp=fxpa; % compensation pulse
%fxpacomp.detuning=-2*pi*1e6;
%fxpacomp.sbcarrierrabi=(1-0.425*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;

fxpacomp=fxpa; % compensation pulse
fxpacomp.detuning=-2*pi*40e6;
fxpacomp.sbcarrierrabi=sqrt(1-fxpacomp.detuning(1)/parameters.omegaz)*fxpa.sbcarrierrabi;



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


%p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time);
%p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time);
[pulse1,time] = Rbluecomp(1,0,1,1,fxpa,fxpacomp,time); pulse=pulse1;
%[pulse1,time] = Rbluecomp(0.5,0,1,1,fxpa13,fxpa13comp,time); pulse=[pulse,pulse1];

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;
displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;

%dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdP.dat',abs(Y).*abs(Y), 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
