% simulates the population evolution with experimental imperfections
% Date:   29-Nov-05
% Author: kihwan Kim <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
%hspace=definehspace(2,3,[2 2],0); % ACmanas Full gate
%hspace=definehspace(2,3,[1 1],0); % Three states gate
%hspace=definehspace(1,2,[2 2],0); % ACmanas gate
%hspace=definehspace(1,3,[2 2],0); % ACmanas2 gate
%hspace=definehspace(1,2,[2],0); % ACstarkshift gate
%hspace=definehspace(2,2,[2],0); % MS gate
%hspace=definehspace(4,2,[2],0); % MS 4 ion gate
%hspace=definehspace(4,2,1,0); % MS 4 ion gate
hspace=definehspace(2,2,[2],0); % CNOT gate
%hspace=definehspace(2,3,[2],0); % CNOT hide gate


T=dlmread('P:\Math\matlab\quantumcomputer\normal\kkdT.dat');
Y=dlmread('P:\Math\matlab\quantumcomputer\normal\kkdY.dat');

setstatevisibility(2,hspace);

%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ])];
%intstates=[index([0 0;],[1 1; ]) index([1 0;],[1 1; ]) index([0 0;],[2 1; ]) index([1 0;],[2 1; ]) index([0 0;],[1 2; ]) index([1 0;],[1 2; ]) index([0 0;],[2 2; ]) index([1 0;],[2 2; ])];

%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));

%displaypopulations(T,Y,[0 0; 2 0; 0 2; 2 2],hspace); % ACmanas Full gate
%displaypopulations(T,Y,[1 1; 2 1; 1 2; 2 2],hspace);
%displaypopulations(T,Y,[1 1; 2 1; 1 2; 2 2; 0 0; 0 2; 2 0; 0 1; 1 0],hspace);
%displaypopulations(T,Y,[1; 2; 0;],hspace);
%displaypopulations(T,Y,[1; 0;],hspace); % RamanMotion
%displaypopulations(T,Y,[1; 2;],hspace);
%displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1],hspace); % MS gate
%displaypopulations(T,Y,[ 0 1 0 1; 0 1 1 0; 1 0 0 1; 1 0 1 0],hspace); % MS 4 ion gate
%displaypopulations(T,Y,[ 0 0 0 0; 1 1 1 1],hspace); % MS 4 ion gate for DDDD
%displaypopulations(T,Y,[ 1 1 0 0; 1 1 1 0; 1 1 0 1; 1 1 1 1],hspace); % MS 4 ion gate for DDDD
displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1;],hspace); % CNOT gate
%displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1; 0 2; 2 0 ],hspace); % CNOT hide gate
%displaypopulations(T,Y,[0 1 0 1; 1 0 0 1; 0 1 1 0; 1 0 1 0; 0 0 1 1; 1 1 0 0],hspace); %Phase gate in DFS state

tracedpopulations(T,Y,hspace,1);

%displaypopulations(T,Y,[1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1],hspace);
%intstates=[index([0;],[1 0 0 0; ]) index([0;],[0 1 0 0; ]) index([0;],[0 0 1 0; ]) index([0;],[ 0 0 0 1; ])]
%intstates=[index([0 0;],[1 1; ]) index([0 1;],[1 1; ]) index([0 0;],[2 1; ]) index([0 1;],[2 1; ]) index([0 0;],[1 2; ]) index([0 1;],[1 2; ]) index([0 0;],[2 2; ]) index([0 1;],[2 2; ]) index([0 0;],[0 0; ]) index([0 1;],[2 0; ]) index([0 0;],[0 2; ])];
%hspace.visible=zeros(1,hspace.dimensions);
%hspace.visible(intstates)=ones(1,length(intstates));
%sum(PF(intstates))
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace);

%*****************************************************************************%
%closemessagewindow;
