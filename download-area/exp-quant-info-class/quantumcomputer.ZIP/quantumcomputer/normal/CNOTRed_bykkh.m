% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% Auxiliary state: E
% Ground State: S
% Excited State: D
%
% The only D,1 state is coupled to E,0 state by blue sideband transtion
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,3,[2],0); %definehspace(electronic states, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=1;
parameters.points=400;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*170e3; 
%parameters.addressing=[0.05 1;1 0.05];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1200000;

parameters.detuning=[2*pi*500 ; 2*pi*2500 ; 0];
%parameters.detuning=2*pi*500
%parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0.03;
parameters.intensitymismatch=0;

parameters.odesolve=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;  % Inital States: states(phonon,electronicstates)
%parameters.y0(index(1,[0],parameters.hspace))=1;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;

fxpacomp=fxpa; % compensation pulse
fxpacomp.detuning=[-2*pi*1e6; -2*pi*1e6; 0];


%fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;
fxpacomp.sbcarrierrabi=(1-0.45*fxpacomp.detuning(1)/parameters.omegaz)*fxpa.sbcarrierrabi;


%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

SWAP=0;
Ramsey=1;
phasegate=1;

doEchoO=0; % Spin echo pulse to the computer base state
doSwapEcho=0;

doEchoA=0; % Spin echo pulse to the auxiliary state
doEchoB=1;
compensation=0;

%ang=acos(-real(exp(pi/2*i*sqrt(2))))/pi;

%SWAP I
if SWAP
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time);
    if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp); end % compensation laser

    if doSwapEcho
        p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
        time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+delayunit);
    end

    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp+delayunit); end % compensation laser
end

%Ramsey I
if Ramsey p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+(10)*delayunit); end

%Phase gate
if phasegate
    
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(2/4,0,2,2,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1/4,0,2,2,fxpacomp,timecomp+delayunit); end % compensation laser

    %echo1
    if doEchoO
        p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
        time=time+4/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
    end

    if doEchoA
        p = p + 1;[pulse(p),time] = Rcar(1,0.5,2,2,fxpa,time+delayunit);
        time=time+4/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,1.5,2,2,fxpa,time+delayunit);
    end
    
    if doEchoB
        p = p + 1;[pulse(p),time] = Rcar(1,0,2,2,fxpa,time+delayunit);
        p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
        time=time+4/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
        p = p + 1;[pulse(p),time] = Rcar(1,1,2,2,fxpa,time+delayunit);
    end

    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(4/4,0,2,2,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(2/4,0,2,2,fxpacomp,timecomp+delayunit); end % compensation laser

    %echo2
    if doEchoO
        p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
        time=time+4/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
    end

    if doEchoA
        p = p + 1;[pulse(p),time] = Rcar(1,0.5,2,2,fxpa,time+delayunit);
        time=time+4/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,1.5,2,2,fxpa,time+delayunit);
    end

    if doEchoB
        p = p + 1;[pulse(p),time] = Rcar(1,0,2,2,fxpa,time+delayunit);
        p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
        time=time+4/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
        p = p + 1;[pulse(p),time] = Rcar(1,1,2,2,fxpa,time+delayunit);
    end
    
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(2/4,0,2,2,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(2/4,0,2,2,fxpacomp,timecomp+delayunit); end % compensation laser

    %echo3
 %   if doEchoO
 %       p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
 %       time=time+2/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
 %       p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
 %   end

 %   if doEchoA
 %       p = p + 1;[pulse(p),time] = Rcar(1,0.5,2,2,fxpa,time+delayunit);
 %       time=time+2/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
 %       p = p + 1;[pulse(p),time] = Rcar(1,1.5,2,2,fxpa,time+delayunit);
 %   end

 %   timecomp=time;
 %   p = p + 1;[pulse(p),time] = Rblue(2/4,0,2,2,fxpa,time+delayunit);
 %   if compensation p = p + 1;[pulse(p),time] = Rred(2/4,0,2,2,fxpacomp,timecomp+delayunit); end % compensation laser

    %echo4
%    if doEchoO
%        p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+delayunit);
%        time=time+2/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
%        p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa,time+delayunit);
%    end

%    if doEchoA
%        p = p + 1;[pulse(p),time] = Rcar(1,0.5,2,2,fxpa,time+delayunit);
%        time=time+2/4*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
%        p = p + 1;[pulse(p),time] = Rcar(1,1.5,2,2,fxpa,time+delayunit);
%    end
    
%    timecomp=time;
%    p = p + 1;[pulse(p),time] = Rblue(1/4,0,2,2,fxpa,time+delayunit);
%    if compensation p = p + 1;[pulse(p),time] = Rred(1/4,0,2,2,fxpacomp,timecomp+delayunit); end % compensation laser

end
%timeR=2*pi/(parameters.eta(1)*parameters.sbomegacarrier);
%phasecom=parameters.sbomegacarrier*parameters.sbomegacarrier/4/(parameters.omegaz)*timeR/pi;

%Ramsey II 
if Ramsey p = p + 1;[pulse(p),time] = Rcar(0.5,1,2,1,fxpa,time+(10)*delayunit); end

%SWAP II
if SWAP
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp+delayunit); end % compensation laser

    if doSwapEcho
        p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
        time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier)*1e6;
        p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+delayunit);
    end

    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1/2,0,1,1,fxpacomp,timecomp+delayunit); end % compensation laser
end

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;
displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1; 0 2; 2 0],hspace);
%displaypopulations(T,Y,[0;1;2],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;

%dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
