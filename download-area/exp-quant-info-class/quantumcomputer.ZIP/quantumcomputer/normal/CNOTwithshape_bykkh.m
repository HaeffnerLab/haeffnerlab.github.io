% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,[2],0); %definehspace(ions, levels, motional states)
%hspace=definehspace(2,3,[2],0); % for Hiding

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=1000;
%parameters.eigenvectors=[1 1];
parameters.omegacarrier=2*pi*100e3;
parameters.sbomegacarrier=2*pi*150e3; 
parameters.addressing=[0.05 1;1 0.05];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1.2e6;

%parameters.detuning=2*pi*300;
%parameters.detuning=[2*pi*300; 2*pi*1500; 0] % for Hiding
%parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0;
%parameters.intensitymismatch=1;

parameters.odesolve=1;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 1],parameters.hspace))=1;  % Inital States: states(phonon,electronicstates)
%parameters.y0(index(0,[1 0],parameters.hspace))=0;
%parameters.y0=state(1,[0 0])';
%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;

fxpacomp=fxpa; % compensation pulse
fxpacomp.detuning=-2*pi*10e6;

%fxpacomp.detuning=[-2*pi*10e6;0;0]; % for Hiding
%fxpacomp.detuning=-2*parameters.omegaz-2*pi*0.1e6;
%fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;
%fxpacomp.sbcarrierrabi=sqrt(1-(fxpacomp.detuning+2*parameters.omegaz)/parameters.omegaz)*fxpa.sbcarrierrabi;
fxpacomp.sbcarrierrabi=sqrt(1-fxpacomp.detuning(1)/parameters.omegaz)*fxpa.sbcarrierrabi;

%********************** Pulse Shaping Parameters *********************

shape.steps=20;
shape.time=3;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)
%  Rshape(theta,phi,ion,transition,fxpa,stattime,shape)

Ramsey=1;
Phasegate=1;
doSWAPEcho=0;
doEcho=0;
Hiding=0;

%[pulse1,time] = Rcar(0.5,0,1,1,fxpa,time+delayunit); pulse=pulse1;
%[pulse1,time] = Rshapecomp(0.05,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rshapecomp2(0.05,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rshapecomp(2,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rshapecomp(1/2,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
%[pulse1,time] = Rcar(0.5,1,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
%SWAP I
    [pulse1,time] = Rshapecomp(1/2,0,2,1,fxpa,fxpacomp,time+delayunit,shape); pulse=pulse1; 
    if doSWAPEcho
        [pulse1,time] = Rcar(1,0,2,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
        time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
        [pulse1,time] = Rcar(1,1,2,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
    end
    [pulse1,time] = Rshapecomp(1/2,0,2,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1]; 
   
    %Hiding
    if Hiding
        [pulse1,time] = Rcar(1,0,2,1,fxpa,time+delayunit); pulse=[pulse,pulse1]; % for the hiding control ion D->S
        [pulse1,time] = Rcar(1,0,2,3,fxpa,time+delayunit); pulse=[pulse,pulse1]; % for the hiding control S->E
    end

    %Ramsey I
    if Ramsey [pulse1,time] = Rcar(0.5,0,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1]; end

%Phase gate
if Phasegate
    % 1st composite pulse
    [pulse1,time] = Rshapecomp(1/2/sqrt(2),0.5,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
    if doEcho
        [pulse1,time] = Rcar(1,0,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
        time=time+1/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
        [pulse1,time] = Rcar(1,1,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
    end
    [pulse1,time] = Rshapecomp(1/2/sqrt(2),0.5,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
    
   
    % 2nd composite pulse
    [pulse1,time] = Rshapecomp(1/2,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
    if doEcho
        [pulse1,time] = Rcar(1,0,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
        time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
        [pulse1,time] = Rcar(1,1,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
    end
    [pulse1,time] = Rshapecomp(1/2,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
    
    % 3rd composite pulse
    [pulse1,time] = Rshapecomp(1/2/sqrt(2),0.5,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
    if doEcho
        [pulse1,time] = Rcar(1,0,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
        time=time+1/sqrt(2)*pi/(parameters.eta(1)*parameters.sbomegacarrier);
        [pulse1,time] = Rcar(1,1,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
    end
    [pulse1,time] = Rshapecomp(1/2/sqrt(2),0.5,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1]; 

    % 4th composite pulse
    [pulse1,time] = Rshapecomp(1/2,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
    if doEcho
        [pulse1,time] = Rcar(1,0,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
        time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
        [pulse1,time] = Rcar(1,1,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
    end
    [pulse1,time] = Rshapecomp(1/2,0,1,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
end

%Ramsey II
if Ramsey [pulse1,time] = Rcar(0.5,1,1,1,fxpa,time+delayunit); pulse=[pulse,pulse1]; end

%Hiding
    if Hiding
        [pulse1,time] = Rcar(1,0,2,3,fxpa,time+delayunit); pulse=[pulse,pulse1]; % for the hiding control ion E->S
        [pulse1,time] = Rcar(1,0,2,1,fxpa,time+delayunit); pulse=[pulse,pulse1]; % for the hiding control S->D
    end

%SWAP I
   [pulse1,time] = Rshapecomp(1/2,0,2,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
       if doSWAPEcho
        [pulse1,time] = Rcar(1,0,2,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
        time=time+1*pi/(parameters.eta(1)*parameters.sbomegacarrier);
        [pulse1,time] = Rcar(1,1,2,1,fxpa,time+delayunit); pulse=[pulse,pulse1];
       end
   [pulse1,time] = Rshapecomp(1/2,0,2,1,fxpa,fxpacomp,time+delayunit,shape); pulse=[pulse,pulse1];
   


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
%closemessagewindow;
T=T*fs;
setstatevisibility(2,hspace);
%displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1;],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
%hold on;

dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
