% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut Häffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,[1],0);
parameters=standardparameters(hspace);


T2piblue=250e-6;



%****************** Changes to the standardparameters  ***********************%
parameters.nolightshift=1;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*(1/T2piblue/0.02);%2*pi*300e3;
%parameters.addressing=[1 0; 0 1]%[1 0.05; 0.05 1];
parameters.recoilangle=68;
parameters.points=400;

parameters.detuning=2*pi*(1.2e6);
%parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0.03;
parameters.intensitymismatch=0;
parameters.odesolve=1;


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
%parameters.y0(index(0,[1 1],parameters.hspace))=1/sqrt(2);
parameters.y0(index(0,[1],parameters.hspace))=1%/sqrt(2);
%parameters.y0(index(1,[0 0],parameters.hspace))=0.02;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)


fxpa2=fxpa
fxpa2.detuning=2*pi*(1.2e6+20e3)/1e6

ang=acos(-real(exp(pi/2*i*sqrt(2))))/pi;


p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time+14*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,1,1,1,fxpa2,time+5*delayunit);

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;;
displaypopulations(T,Y,[0; 1],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
hold on;
%*****************************************************************************%
