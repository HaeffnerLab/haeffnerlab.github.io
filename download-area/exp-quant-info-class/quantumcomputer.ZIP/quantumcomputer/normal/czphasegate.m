% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*380e3;
parameters.hspace.nuions=2;
parameters.hspace.maxphonons=3;
parameters.addressing=[1 0.0; 0.0 1];
parameters.recoilangle=68;
parameters.omegaz=2100000*2*pi;
parameters.nolightshift=1;
parameters.detuning=2*pi*0e3;
parameters.intensitymismatch=0;
parameters.points=100;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)

%p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+(10)*delayunit); 
%p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time+14*delayunit); 

%p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+(20)*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,2,1,fxpa,time+1*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,2,1,fxpa,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa,time+0*delayunit); 
%p = p + 1;[pulse(p),time] = Rcar(0.5,1,2,1,fxpa,time+(20)*delayunit); 

%p = p + 1;[pulse(p),time] = Rblue(1,1,1,1,fxpa,time+14*delayunit); 
%p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+(20)*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0 0; 1 0; 0 1; 1 1;],hspace);
setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;