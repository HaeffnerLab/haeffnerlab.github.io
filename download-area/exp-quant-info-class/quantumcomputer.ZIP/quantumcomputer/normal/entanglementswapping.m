% simulates the population evolution with experimental imperfections
% Date:  2006-02-07
% initially created by: Hartmut Häffner <hartmut.haeffner@uibk.ac.at 03-Sep-02
% edited by: Thomas Monz <thomas.monz@uibk.ac.at>

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

% definehspace({nuions},{levels},{maxphotons},{densitymatrixformalism})
hspace=definehspace(4,2,[2],0);

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
% ignore induced lightshift
parameters.ignorelightshift=1;
% rabi-frequency of the carrier
parameters.omegacarrier=2*pi*23e3;
%
parameters.sbomegacarrier=2*pi*300e3;
% first element: first ion hit with x, second with y, and so on ...
% "standard": [1 0.05; 0.05 1];
%parameters.addressing=[1 0.05; 0.05 1];
% angle between 729 and ion-string
% "standard": 68
parameters.recoilangle=68;
% amount of timesteps; if only interested in outcome -> 2
parameters.points=200;

% detuning from resonance
% "standard": 0-300 *2*pi
%parameters.detuning=2*pi*100;
% fast frequency fluctuations
% "standard": ask mike -> 2*pi*150
%parameters.decoherences.frefluct=2*pi*150;
% deterministic frequ. errors
% idea: [mean half deviation, amount of jumps]
% "standard": 1000, should be realistic
%parameters.decoherences.det_frefluct=[0*2*pi*1000,1]
% relative intensity fluctuations
% "standard": 0.03
%parameters.decoherences.intensity_fluctuations=0.03;
% intensity error in relative units, which will affect the rabi frequency
%parameters.intensitymismatch=0.1;
%
% ---- no idea of really implemented/used
%parameters.deltaphase=exp(i*pi/4);
%parameters.phaseerror=exp(i*pi/4);


parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
% vector, representing initial state with motional groundstate (see the
% first 0)
parameters.y0(index(0,[1 1 1 1],parameters.hspace))=1;
% vector, representing initial state with motional first excited state
% (see the first 1)
%parameters.y0(index(1,[1 1 1 1],parameters.hspace))=0.02;

% for that many ions stick to vector, and not matrix-formalism. roughly
% one hour to calculate a single simulation with matrix-formalism
%
% in order to estimate things like non-perfect motional groundstate make
% 2 simulations: 1 with, say, 0.95 groundstate, and one with 0.05
% exitedstate, then add up the populations(!!) (not the vector)

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

% these are artefacts of the old script. don't know what they are used
% for. not included in the new pulses right now.
phi=0.5;
phi2=0.5;
phi3=0.5;


% entangle ions 3,4 into psi-
p = p + 1;[pulse(p),time] = Rblue(0.5,0.5,3,1,fxpa,time+14*delayunit);
p = p + 1;[pulse(p),time] = Rcar(   1,1.5,4,1,fxpa,time+(10)*delayunit);
p = p + 1;[pulse(p),time] = Rblue(  1,0.5,4,1,fxpa,time+14*delayunit);

% entangle ions 1,2 into psi-
p = p + 1;[pulse(p),time] = Rblue(0.5,0.5,2,1,fxpa,time+14*delayunit);
p = p + 1;[pulse(p),time] = Rcar(   1,1.5,1,1,fxpa,time+(10)*delayunit);
p = p + 1;[pulse(p),time] = Rblue(  1,0.5,1,1,fxpa,time+14*delayunit);

% make bell measurement on ions 2,3

%%% old pulses stuff by ?
% p = p + 1;[pulse(p),time] = Rblue(  1,phi2,4,1,fxpa,time+14*delayunit);

% p = p + 1;[pulse(p),time] = Rcar(0.5,phi3,1,1,fxpa,time+(10)*delayunit);
% p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5+phi,1,1,fxpa,time+0*delayunit);
% p = p + 1;[pulse(p),time] = Rblue(1,0+phi,1,1,fxpa,time+0*delayunit);
% p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5+phi,1,1,fxpa,time+0*delayunit);
% p = p + 1;[pulse(p),time] = Rblue(1,0+phi,1,1,fxpa,time+0*delayunit);
% p = p + 1;[pulse(p),time] = Rcar(0.5,phi3,1,1,fxpa,time+(10)*delayunit);

% p = p + 1;[pulse(p),time] = Rblue(  1,phi2+1,4,1,fxpa,time+14*delayunit);


% p = p + 1;[pulse(p),time] = Rcar(0.5,0,4,1,fxpa,time+(10)*delayunit);
%%% end old stuff


% CNOT on ions #2 and #3
p = p + 1;[pulse(p),time] = Rblue(  1,0,2,1,fxpa,time+14*delayunit);

p = p + 1;[pulse(p),time] = Rcar(0.5,-0.5,3,1,fxpa,time+(10)*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,0.5,3,1,fxpa,time+0*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,3,1,fxpa,time+0*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,0.5,3,1,fxpa,time+0*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,3,1,fxpa,time+0*delayunit);
p = p + 1;[pulse(p),time] = Rcar(0.5,0.5,3,1,fxpa,time+(10)*delayunit);

p = p + 1;[pulse(p),time] = Rblue(  1,1,2,1,fxpa,time+14*delayunit);

% perform hadamart on ion #2
p = p + 1;[pulse(p),time] = Rcar(0.5,-0.5,2,1,fxpa,time+(10)*delayunit);

% that's almost it. we have got the entangled ions. we included the pulses
% for a CNOT with a hadamart to make a bell state measurement on ions #2 and
% #3. The following will do the time evolution of these pulses

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
%closemessagewindow;
T=T*fs;;
%displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1;],hspace);
%[PF,PH]=endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
hold on;
%*****************************************************************************%

% seems to be the final state we are in after the timeevolution
res=Y(size(Y,1),:);

% define projection-operators on the ions #2 and #3
%
% idea: store the positions where the corresponding elements are
ind=[1:hspace.dimensions];
pro00=projion(ind,[-1],[-1 0 0 -1]);
pro01=projion(ind,[-1],[-1 0 1 -1]);
pro10=projion(ind,[-1],[-1 1 0 -1]);
pro11=projion(ind,[-1],[-1 1 1 -1]);

% the following lines have been initial testing, but should be more
% easier to read in order to understand what's going on
%
% % get memoryspace for projected states
% res00=zeros(1,hspace.dimensions);
% res01=res00;
% res10=res00;
% res11=res00;

% % the first line is going to represent the state the state after the
% % first (00) projection, followed by the corresponding pulses to correct
% % into the wanted final state

% % store projected states
% %
% % idea: fill the empty matrix with the elements of the corresponding
% % elements of the final state, representing the projection
% % res00(pro00)=res(pro00); and so on

% %include normalisation after projection
% res00(pro00)=res(pro00)/sqrt(abs(res(pro00)*res(pro00)'));
% res01(pro01)=res(pro01)/sqrt(abs(res(pro01)*res(pro01)'));
% res10(pro10)=res(pro10)/sqrt(abs(res(pro10)*res(pro10)'));
% res11(pro11)=res(pro11)/sqrt(abs(res(pro11)*res(pro11)'));

% % do final pulses on the residual states depending on ion wether ion #2 was
% % in state #1 (resulting in a Z rotation on #4) and/or weather ion #3 was in
% % state 1 (resulting in a X rotation on #1)

% % 00 - 01 - 10 - 11
% % pulse for 00 measurement: nothing
% % pulse for 01 measurement: Ucar(0.5,1,4)*Ucar(1,-0.5,4)*Ucar(0.5,0,4)
% % pulse for 10 measurement: Ucar(1,1,1)
% % pulse for 11 measurement: Ucar(1,1,1)*Ucar(0.5,1,4)*Ucar(1,-0.5,4)*Ucar(0.5,0,4)
% res00e=res00';
% res01e=Ucar(0.5,1,4)*Ucar(1,-0.5,4)*Ucar(0.5,0,4)*res01';
% res10e=Ucar(1,1,1)*res10';
% res11e=Ucar(1,1,1)*Ucar(0.5,1,4)*Ucar(1,-0.5,4)*Ucar(0.5,0,4)*res11';

setstatevisibility(0);
% dispmat(res00e)
% dispmat(res01e)
% dispmat(res10e)
% dispmat(res11e)

% get memoryspace for the projected, residual states
res_states=zeros(4,hspace.dimensions);

% prepare a matrix including the corresponding projectors
%
% first line represents the 00 projection
% second line represents the 01 projection, and so on
proj_matrix=zeros(4,length(pro00));
proj_matrix(1,:)=pro00;
proj_matrix(2,:)=pro01;
proj_matrix(3,:)=pro10;
proj_matrix(4,:)=pro11;

% store projected states in matrix
% include normalisation after projection
for i=1:4
  res_states(i,proj_matrix(i,:))=res(proj_matrix(i,:))/ ...
      sqrt(abs(res(proj_matrix(i,:))*res(proj_matrix(i,:))'));
  sprintf('State after projection:')
  dispmat(res_states(i,:)')
end


%dispmat(res')

% test

for i=1:4
  if i==1
    res00_test=res_states(i,:)';
    % nothing needs to be done
  elseif i==2
    clear p;
    clear T;
    clear Y;
    clear pulse;
    parameters.y0=res_states(i,:);
    initializepulseparameters
    % perform the Z rotation
    p = p + 1;[pulse(p),time] = Rcar(0.5,0,4,1,fxpa,time+10*delayunit);
    p = p + 1;[pulse(p),time] = Rcar(1,-0.5,4,1,fxpa,time+10*delayunit);
    p = p + 1;[pulse(p),time] = Rcar(0.5,1,4,1,fxpa,time+10*delayunit);
    %****************** And ... here we go again ...  ***********************%
    [T,Y]=simulateevolution(pulse,parameters);
%    closemessagewindow;
    T=T*fs;;
    res01_test=Y(size(Y,1),:)';
  elseif i==3
    clear p;
    clear T;
    clear Y;
    clear pulse;
    parameters.y0=res_states(i,:);
    initializepulseparameters
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+10*delayunit);
    %****************** And ... here we go again ...  ***********************%
    [T,Y]=simulateevolution(pulse,parameters);
%    closemessagewindow;
    T=T*fs;;
    res10_test=Y(size(Y,1),:)';
  elseif i==4
    clear p;
    clear T;
    clear Y;
    clear pulse;
    parameters.y0=res_states(i,:);
    initializepulseparameters
    % perform X and Z rotation
    p = p + 1;[pulse(p),time] = Rcar(0.5,0,4,1,fxpa,time+10*delayunit);
    p = p + 1;[pulse(p),time] = Rcar(1,-0.5,4,1,fxpa,time+10*delayunit);
    p = p + 1;[pulse(p),time] = Rcar(0.5,1,4,1,fxpa,time+10*delayunit);
    p = p + 1;[pulse(p),time] = Rcar(1,1,1,1,fxpa,time+10*delayunit);
    %****************** And ... here we go again ...  ***********************%
    [T,Y]=simulateevolution(pulse,parameters);
%    closemessagewindow;
    T=T*fs;;
    res11_test=Y(size(Y,1),:)';
  end
end

% define states for fidelity
% include trace of motion

ideal_res00_state=1/(sqrt(2))*(state(0,[1 0 0 0],hspace) - state(0,[0 0 0 ...
                    1],hspace)) + 1/(sqrt(2))*(state(1,[1 0 0 0],hspace) - state(1,[0 0 0 1],hspace));
fidelity00=abs(res00_test'*ideal_res00_state)^2;
sprintf('Fidelity after a 00 measurement: %0.4g',fidelity00)

ideal_res01_state=1/(sqrt(2))*(state(0,[1 0 1 0],hspace) - state(0,[0 0 1 ...
                    1],hspace)) + 1/(sqrt(2))*(state(1,[1 0 1 0],hspace) - state(1,[0 0 1 1],hspace));
fidelity01=abs(res01_test'*ideal_res01_state)^2;
sprintf('Fidelity after a 01 measurement: %0.4g',fidelity01)

ideal_res10_state=1/(sqrt(2))*(state(0,[1 1 0 0],hspace) - state(0,[0 1 0 ...
                    1],hspace)) + 1/(sqrt(2))*(state(1,[1 1 0 0],hspace) - state(1,[0 1 0 1],hspace));
fidelity10=abs(res10_test'*ideal_res10_state)^2;
sprintf('Fidelity after a 10 measurement: %0.4g',fidelity10)

ideal_res11_state=1/(sqrt(2))*(state(0,[1 1 1 0],hspace) - state(0,[0 1 1 ...
                    1],hspace)) + 1/(sqrt(2))*(state(1,[1 1 1 0],hspace) - state(1,[0 1 1 1],hspace));
fidelity11=abs(res11_test'*ideal_res11_state)^2;
sprintf('Fidelity after a 11 measurement: %0.4g',fidelity11)
