% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

hspace=definehspace(3,2,[3 6]);

parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=400;
parameters.omegacarrier=1.5*2*pi/29.4e-6;
parameters.sbomegacarrier=2*pi/(0.2e-3*0.03);
%parameters.addressing=[1 0.05 0.05 ; 0.05 1 0.05; 0.05 0.05 1];
parameters.recoilangle=68;
parameters.omegaz=sqrt(29/5)*2*pi*[1200000 sqrt(10/8)*1200000 ];
parameters.detuning=2*pi*0*0.220e3; % 220 Hz for 80% contrast after 450 \mus
parameters.eta=[0.015 -0.03 0.015;
                         0.03 -0.03 0.03];
parameters.ignorelightshift=0;



%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index([0 3],[0 0 0],parameters.hspace))=1;




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters


%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


%p = p + 1;[pulse(p),time] = Rcar(1,0,3,2,fxpa,time+1*delayunit); 


%Rcar(1,0,3)  
%Rcar(1,0,2)  
%Rblue(2*acos(1/sqrt(3))/pi,0,1)
%Rblue(0.5,0,3)
%Rblue(1,0,2)


p = p + 1;[pulse(p),time] = Rcar(1,0,3,1,fxpa,time*delayunit); 
p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+15*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(2*acos(1/sqrt(3))/pi,0,1,1,fxpa,time+15*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(0.5,0,3,1,fxpa,time+15*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa,time+15*delayunit); 

%p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+15*delayunit); 
%p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+450*delayunit); 


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(1,hspace);
displaypopulations(T,Y,[0 1 1; 1 0 1; 1 1 0;],hspace);
setstatevisibility(5,hspace);
endpopulations(T,Y,hspace);
phonontracedpopulations(T,Y,[0 1 1; 1 0 1; 1 1 0;],hspace);

%*****************************************************************************%
closemessagewindow;
