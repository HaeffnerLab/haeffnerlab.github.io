% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,[2],0); %definehspace(electronic states, levels, motional states)

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=400;
%parameters.eigenvectors=[1 1];
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*100e3; 
%parameters.addressing=[0.05 1;1 0.05];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1e6;

%parameters.detuning=2*pi*300;
%parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0;
%parameters.intensitymismatch=1;

parameters.odesolve=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
%parameters.y0(index(0,[1 0],parameters.hspace))=1;  % Inital States: states(phonon,electronicstates)
%parameters.y0(index(1,[0 0],parameters.hspace))=0.02;
parameters.y0=state(1,[0 0])';
%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1;

fxpacomp=fxpa; % compensation pulse

fxpacomp.detuning=-2*pi*8.8e6;
%fxpacomp.sbcarrierrabi=(1-0.5*fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;
fxpacomp.sbcarrierrabi=sqrt(1-fxpacomp.detuning/parameters.omegaz)*fxpa.sbcarrierrabi;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


SWAP=0;
Ramsey=1;
phasegate=1;
compensation=0;
dly=1;

dlytm=0.8*2*pi/parameters.omegaz;
iph=0.5;

%ang=acos(-real(exp(pi/2*i*sqrt(2))))/pi;
%SWAP I
if SWAP
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time);
    if compensation p = p + 1;[pulse(p),time] = Rred(2,0,1,1,fxpacomp,timecomp); end % compensation laser
end

%Ramsey I
if Ramsey p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa,time+(10)*delayunit); end

%Phase gate
if phasegate
    %first composite pulse
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),iph,2,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1/sqrt(2),iph,2,1,fxpacomp,timecomp+delayunit); end % compensation laser

    %second composite pulse
    if dly time=time+dlytm; end
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1,iph-0.5,2,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1,iph-0.5,2,1,fxpacomp,timecomp+delayunit); end % compensation laser

    %third composite pulse
    if dly time=time+dlytm; end
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),iph,2,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1/sqrt(2),iph,2,1,fxpacomp,timecomp+delayunit); end %compensation laser

    %forth composite pulse
    if dly time=time+dlytm; end
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1,iph-0.5,2,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1,iph-0.5,2,1,fxpacomp,timecomp+delayunit); end %compensation laser
end

    timeR=(2+sqrt(2))*pi/(parameters.eta(1)*parameters.sbomegacarrier);
    phasecom=parameters.sbomegacarrier*parameters.sbomegacarrier/2/(parameters.omegaz)*timeR/pi;

%Ramsey II
if Ramsey p = p + 1;[pulse(p),time] = Rcar(0.5,1+phasecom,2,1,fxpa,time+(10)*delayunit); end

%SWAP II
if SWAP
    timecomp=time;
    p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time+delayunit);
    if compensation p = p + 1;[pulse(p),time] = Rred(1,0,1,1,fxpacomp,timecomp+1*delayunit); end %compensation laser
end

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;
setstatevisibility(2,hspace);
displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1;],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;

%dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
%dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
