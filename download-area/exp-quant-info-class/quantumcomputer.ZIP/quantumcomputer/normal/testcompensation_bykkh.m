% simulates the phase evolution with experimental imperfections by ODE
% Date:   17-Jan-06
% Author: kihwan Kim <kihwan.Kim@uibk.ac.at>
%
% % type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,[2],0); %definehspace(ions, levels, motional states)
%hspace=definehspace(2,3,[2],0); % for Hiding

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=1000;
%parameters.eigenvectors=[1 1];
parameters.omegacarrier=2*pi*100e3;
parameters.sbomegacarrier=2*pi*200e3; 
%parameters.addressing=[0 1;1 0];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1.2e6;

%parameters.detuning=2*pi*300;
%parameters.detuning=[2*pi*300; 2*pi*1500; 0] % for Hiding
%parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0;
%parameters.intensitymismatch=1;

parameters.odesolve=1;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1],parameters.hspace))=1;  % Inital States: states(phonon,electronicstates)

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=0;

fxpa12=fxpa;
fxpa12comp=fxpa;
%fxpa12.addressingerror=[1 1 ;1 1];
%fxpa12comp.addressingerror=[1 1 ;1 1];

ro=10;
aL=2*ro; %length of pulse of MS
fxpa12.detuning=ro*parameters.sbomegacarrier*parameters.eta;


fxpa12comp.detuning=-2*pi*10e6;
%fxpa12comp.sbcarrierrabi=sqrt((parameters.omegaz-fxpa12comp.detuning(1))/(parameters.omegaz))*fxpa.sbcarrierrabi;
%fxpa12comp.sbcarrierrabi=sqrt((parameters.omegaz-fxpa12comp.detuning(1))/(parameters.omegaz+fxpa12.detuning(1)))*fxpa.sbcarrierrabi;
fxpa12comp.sbcarrierrabi=sqrt((1/(parameters.omegaz+fxpa12.detuning(1))+parameters.eta(1)^2/2/fxpa12.detuning(1))/(1/(parameters.omegaz-fxpa12comp.detuning(1))+parameters.eta(1)^2/2/fxpa12comp.detuning(1)))*fxpa.sbcarrierrabi;

fxpacomp=fxpa; % compensation pulse
fxpacomp.detuning=-2*pi*10e6;
fxpacomp.sbcarrierrabi=sqrt(1-fxpacomp.detuning(1)/parameters.omegaz)*fxpa.sbcarrierrabi;


%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)
%  Rshape(theta,phi,ion,transition,fxpa,stattime,shape)

p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time);

timecomp=time;
p = p + 1;[pulse(p),time] = Rblue(aL*1,0,1,1,1,fxpa12,time+delayunit); 
p = p + 1;[pulse(p),time] = Rred(aL*1,0,1,1,1,fxpa12comp,timecomp+delayunit);

p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+delayunit);
%mode=1;

%theta=0.5;
%ftime = time+theta*fxpa.piover2time(mode,ion)
%step_time=3.2e-6;
%numberofstep=ftime/step_time;
%theta1=step_time/fxpa.piover2time(mode); 
%for(p=0:2:2*numberofstep)    
%    timc=time;
%    p
%    p = p + 1;[pulse(p),time] = Rblue(theta1,0,1,1,fxpa,time);
%    p = p + 1;[pulse(p),time] = Rred(theta1,0,1,1,fxpacomp,timc);
%end
%time
%pf=p
%theta=0.5;
%ftime =time+theta*fxpa.piover2time(mode,ion)
%step_time=3.2e-6;
%numberofstep=ftime/step_time
%theta1=step_time/fxpa.piover2time(mode); 
%for(p=pf:2:pf+2*numberofstep)    
%    timc=time;
%    p
%    p = p + 1;[pulse(p),time] = Rblue(theta1,0,1,1,fxpa,time);
%    p = p + 1;[pulse(p),time] = Rred(theta1,0,1,1,fxpacomp,timc);
%end
%time
%p
%time=0.5*fxpa.piover2time(1,1)
%[pulse1,time] = Rbluecomp(0.5,0,1,1,fxpa,fxpacomp,time); pulse=pulse1;
%[pulse1,time] = Rbluecomp(0.5,0,1,1,fxpa,fxpacomp,time+delayunit); pulse=[pulse,pulse1];
%[pulse1,time] = Rbluecomp(0.5,0,1,1,fxpa,fxpacomp,time+delayunit); pulse=[pulse,pulse1];
%[pulse1,time] = Rbluecomp(0.5,0,1,1,fxpa,fxpacomp,time+delayunit); pulse=[pulse,pulse1];

%********************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
%closemessagewindow;
T=T*fs;
setstatevisibility(2,hspace);
%displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1;],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%tracedpopulations(T,Y,hspace,1);
%hold on;

dlmwrite('kkdT.dat',T, 'delimiter', '\t', 'precision', 4);
dlmwrite('kkdY.dat',Y, 'delimiter', '\t', 'precision', 4);

%*****************************************************************************%
%closemessagewindow;
