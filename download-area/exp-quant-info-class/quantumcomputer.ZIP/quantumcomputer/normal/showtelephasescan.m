% showtelephasescan

figure(1)
clf;

plot(phasex,sum(sum(fid,3),2)/4);


for(k=1:4)
	figure(k+1)
	clf;

	plot(phasex,squeeze(sum(fid(:,:,k),2)));
end;