% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut Häffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;


%****************** Changes to the standardparameters  ***********************%
hspace=definehspace(3,3,2,0);
parameters=standardparameters(hspace);


% parameters.nolightshift=1;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*200e3;
parameters.addressing=[0.02 0.02 1 ; 0.04 1 0.04; 1 0.02 0.02];
%parameters.addressing=eye(3);
parameters.recoilangle=68;
parameters.points=100;
parameters.omegaz=1200000*2*pi;


parameters.detuning(1)=1*2*pi*200;             % detuning
parameters.detuning(2)=5*parameters.detuning(1);			 % detuning of aux level

parameters.decoherences.frefluct=2*pi*100;
%parameters.decoherences.intensity_fluctuations=0.03;
%parameters.intensitymismatch=0.1;         %   5% infidelity

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([0],[1 1 1])';




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters




%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)



p = p + 1;[pulse(p),time] = Rblue(asin(1/sqrt(3))/pi*2,0,2,1,fxpa,time*delayunit);

p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+1*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,1,1,fxpa,time+1*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time);
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,1,1,fxpa,time+0*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time+0*delayunit);
p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+1*delayunit);

p = p + 1;[pulse(p),time] = Rcar(1,0,3,1,fxpa,time+1*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,1,3,1,fxpa,time+1*delayunit);

p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa,time+1*delayunit);


p = p + 1;[pulse(p),time] = Rcar(1,0,3,2,fxpa,time+1*delayunit);

p = p + 1;[pulse(p),time] = Rblue(0.5,0,3,2,fxpa,time+1*delayunit);
p = p + 1;[pulse(p),time] = Rblue(  1,0,2,2,fxpa,time+1*delayunit);
p = p + 1;[pulse(p),time] = Rcar(1,0,3,2,fxpa,time+1*delayunit);


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

displaypopulations(T,Y,[0 0 0; 1 0 0; 0 1 0; 1 1 1;],hspace);
setstatevisibility(0,[2 2 2],hspace);
endpopulations(T,Y,hspace);
setstatevisibility(0,[2 2 2],hspace);
phonontracedpopulations(T,Y,[0 0 0; 1 0 0; 0 1 0; 1 1 1;],hspace);

%*****************************************************************************%
closemessagewindow;
