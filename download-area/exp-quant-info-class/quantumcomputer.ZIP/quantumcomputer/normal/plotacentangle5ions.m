load acentangle5ions
fig=figure(3)
clf;

p=subplot(2,1,1)
hold on;
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',13);
set(ax,'Box','on')

st1=index([0 0 0],[0 0 0 0 0],hspace);
p1=plot(T,abs(Y(:,st1)).^2,'k-');
st2=index([1 0 0],[0 0 0 0 0],hspace)
p2=plot(T,abs(Y(:,st2)).^2,'k--');
yl=ylabel('Population');
set(yl,'FontSize',14);
set(p1,'LineWidth',1.5)
set(p1,'MarkerSize',14)
set(p2,'LineWidth',1.5)
set(p2,'MarkerSize',14)

le=legend(statename(st1),statename(st2));
set(le,'FontSize',14);


ax=axis([0 max(T) 0 1]);


p=subplot(2,1,2)
hold on;
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',13);
set(ax,'Box','on')

st1=index([0 0 0],[1 1 1 1 1],hspace);
p1=plot(T,abs(Y(:,st1)).^2,'k-')
st2=index([1 0 0],[1 1 1 1 1],hspace);
p2=plot(T,abs(Y(:,st2)).^2,'k--')
set(p1,'LineWidth',1.5)
set(p1,'MarkerSize',14)
set(p2,'LineWidth',1.5)
set(p2,'MarkerSize',14)

le=legend(statename(st1),statename(st2));
set(le,'FontSize',14);


ax=axis([0 max(T) 0 1]);


xl=xlabel('Time (\mu s)');
set(xl,'FontSize',16);
yl=ylabel('Population');
set(yl,'FontSize',14);

print -depsc2 acentangle5ions