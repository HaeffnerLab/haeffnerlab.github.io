clear S;
clear D;
clear SDX;
clear SDY;
clear fidelity;

nosim=1;
eval('telesimdet')
parameters.points=3;
nosim=0;

endtime(reconstructionpulses)=pulse(reconstructionpulses).endtime;
endtime(reconstructionpulses+1)=pulse(reconstructionpulses+1).endtime;
endtime(reconstructionpulses+2)=pulse(reconstructionpulses+2).endtime;

endtime(preppulses)=pulse(preppulses).endtime;
endtime(preppulses+1)=pulse(preppulses+1).endtime;
endtime(preppulses+2)=pulse(preppulses+2).endtime;
endtime(inversepreppulses)=pulse(inversepreppulses).endtime;
endtime(inversepreppulses+1)=pulse(inversepreppulses+1).endtime;
endtime(inversepreppulses+2)=pulse(inversepreppulses+2).endtime;

for(k=reconstructionpulses-1:inversepreppulses+2)
	phase(k)=pulse(k).phase;
end;

%pmax=40;
%for(m=1:pmax)
%	for(k=reconstructionpulses-1:inversepreppulses+2)
%		pulse(k).phase=mod(phase(k)+(m-1)*2/(pmax-1),2);
%		phasex(m)=m;
%	end;
%m
for(m=1:1)
for(bellcase=1:4)

   s=sprintf('Case: %d',bellcase);
   message(1,s)

  	pulse(reconstructionpulses)=setfield(pulse(reconstructionpulses),'endtime',pulse(reconstructionpulses).starttime);
	pulse(reconstructionpulses+1)=setfield(pulse(reconstructionpulses+1),'endtime',pulse(reconstructionpulses+1).starttime);
   	pulse(reconstructionpulses+2)=setfield(pulse(reconstructionpulses+2),'endtime',pulse(reconstructionpulses+2).starttime);

   if(bellcase==1)   %SS, reconstruction ID
      elstate=[1 1 1];
   elseif(bellcase==2)   %DS, reconstruction X
      pulse(reconstructionpulses)=setfield(pulse(reconstructionpulses),'endtime',endtime(reconstructionpulses));
      pulse(reconstructionpulses+1)=setfield(pulse(reconstructionpulses+1),'endtime',endtime(reconstructionpulses+1));
      elstate=[1 1 0];
   elseif(bellcase==3)   %SD, reconstruction Y
      pulse(reconstructionpulses+2)=setfield(pulse(reconstructionpulses+2),'endtime',endtime(reconstructionpulses+2));
      elstate=[1 0 1];
   elseif(bellcase==4)   %DD, reconstruction XY
      pulse(reconstructionpulses)=setfield(pulse(reconstructionpulses),'endtime',endtime(reconstructionpulses));
      pulse(reconstructionpulses+1)=setfield(pulse(reconstructionpulses+1),'endtime',endtime(reconstructionpulses+1));
      pulse(reconstructionpulses+2)=setfield(pulse(reconstructionpulses+2),'endtime',endtime(reconstructionpulses+2));
      elstate=[1 0 0];
   end;


	pulse(preppulses)=setfield(pulse(preppulses),'endtime',pulse(preppulses).starttime);
	pulse(preppulses+1)=setfield(pulse(preppulses+1),'endtime',pulse(preppulses+1).starttime);
	pulse(preppulses+2)=setfield(pulse(preppulses+2),'endtime',pulse(preppulses+2).starttime);
	pulse(inversepreppulses)=setfield(pulse(inversepreppulses),'endtime',pulse(inversepreppulses).starttime);
	pulse(inversepreppulses+1)=setfield(pulse(inversepreppulses+1),'endtime',pulse(inversepreppulses+1).starttime);
	pulse(inversepreppulses+2)=setfield(pulse(inversepreppulses+2),'endtime',pulse(inversepreppulses+2).starttime);


	[T,Y]=simulateevolution(pulse,parameters);
	S(bellcase,1:size(Y,2))=Y(size(Y,1),:);
	fidelity(bellcase,1)=abs(S(bellcase,index(0,elstate)))^2;

	pulse(preppulses)=setfield(pulse(preppulses),'endtime',endtime(preppulses));
	pulse(inversepreppulses)=setfield(pulse(inversepreppulses),'endtime',endtime(inversepreppulses));
	[T,Y]=simulateevolution(pulse,parameters);
	D(bellcase,1:size(Y,2))=Y(size(Y,1),:);
	fidelity(bellcase,2)=abs(D(bellcase,index(0,elstate)))^2;

	pulse(preppulses)=setfield(pulse(preppulses),'endtime',pulse(preppulses).starttime);
	pulse(preppulses+1)=setfield(pulse(preppulses+1),'endtime',endtime(preppulses+1));
	pulse(inversepreppulses)=setfield(pulse(inversepreppulses),'endtime',pulse(inversepreppulses).starttime);
	pulse(inversepreppulses+1)=setfield(pulse(inversepreppulses+1),'endtime',endtime(inversepreppulses+1));
	[T,Y]=simulateevolution(pulse,parameters);
	SDX(bellcase,1:size(Y,2))=Y(size(Y,1),:);
	fidelity(bellcase,3)=abs(SDX(bellcase,index(0,elstate)))^2;

	pulse(preppulses+1)=setfield(pulse(preppulses+1),'endtime',pulse(preppulses+1).starttime);
	pulse(preppulses+2)=setfield(pulse(preppulses+2),'endtime',endtime(preppulses+2));
	pulse(inversepreppulses+1)=setfield(pulse(inversepreppulses+1),'endtime',pulse(inversepreppulses+1).starttime);
	pulse(inversepreppulses+2)=setfield(pulse(inversepreppulses+2),'endtime',endtime(inversepreppulses+2));
	[T,Y]=simulateevolution(pulse,parameters);
	SDY(bellcase,1:size(Y,2))=Y(size(Y,1),:);
	fidelity(bellcase,4)=abs(SDY(bellcase,index(0,elstate)))^2;
end;

fidelity
sum(sum(fidelity))/4
fid(m,:,:)=fidelity;

end;
closemessagewindow

showtelephasescan
