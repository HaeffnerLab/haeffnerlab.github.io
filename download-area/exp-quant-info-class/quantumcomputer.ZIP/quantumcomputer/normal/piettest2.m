% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,3,1);
parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*160e3;
parameters.addressing=[1 0.0; 0.0 1];
parameters.decoherences = struct('frefluct',0*2*pi*100,'det_frefluct',[0*2*pi*1000,1],'intensity_fluctuations',0);    % structure for the decoherences
%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 1],parameters.hspace))=1;



%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

fxpa2=fxpa;
fxpa2.detuning=2*pi*0*parameters.frequencyscale;



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

p = p + 1;[pulse(p),time] = Rcar(1,3/2,2,1,fxpa,time+14*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/2,0,1,1,fxpa,time+(20)*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa,time+(20)*delayunit);
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
setstatevisibility(1,[2 2],hspace)
displaypopulations(T,Y,[0 0; 0 1; 1 0; 1 1],hspace);
[PF PH]=endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
% get state vector

if hspace.densitymatrixformalism,
    psi=(-diag(reshape(state(0,[1 0],hspace),16,16))+diag(reshape(state(0,[0 1],hspace),16,16)))/sqrt(2);
    rho=reshape(Y(end,:),16,16);
    fidelity=psi'*rho*psi
else
    psi=(state(0,[1 0],hspace)+state(0,[0 1],hspace))/sqrt(2);
    fidelity=abs(Y(end,:)*psi)^2
end;
hold on;
%*****************************************************************************%
closemessagewindow;
