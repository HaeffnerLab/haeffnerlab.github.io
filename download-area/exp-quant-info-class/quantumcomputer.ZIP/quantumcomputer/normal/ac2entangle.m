% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;


%hspace=definehspace(5,2,[2 1 1],0);
hspace=definehspace(2,2,1,0);
setstatevisibility(0);
parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegaz=2*pi*1200000*[1];
parameters.eigenvectors=[1 1];
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*230e3;
parameters.recoilangle=68;
parameters.points=100;
parameters.addressing=[1 0;0 1];
parameters.decoherences.frefluct=1*2*pi*0;
parameters.detuning=0*+2*pi*1222;
parameters.ignorelightshift=1;
parameters.intensitymismatch=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%

parameters.y0(index([1 1],[0 1],parameters.hspace))=1;


%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%
detun=2*pi*60000;
fxpa2=fxpa;
fxpa2.detuning=fxpa.detuning+(detun)*parameters.frequencyscale;
fxpa2.addressingerror=ones(parameters.hspace.nuions);

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

%p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+14*delayunit); 
%p = p + 1;[pulse(p),time] = Rred(1,0,1,1,fxpa,time+14*delayunit); 
%p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa,time+14*delayunit); 

%ls=0.12*(1-parameters.ignorelightshift);

p = p + 1;[pulse(p),time] = Rcar(0.5,1.5,1,1,fxpa,time+1*delayunit);
p = p + 1;[pulse(p),time] = Rblue(2*detun/(parameters.eta(1)*parameters.sbomegacarrier),0.5,1,1,1,fxpa2,time+(1)*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(1,0.5,1,1,fxpa,time+1*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(0.5*2*detun/(parameters.eta(1)*parameters.sbomegacarrier),0.5,1,1,1,fxpa2,time+(1)*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(0.5,-0.5,1,1,fxpa,time+1*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(0.5,0.5,2,1,fxpa,time+1*delayunit);



%p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+1*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(2*detun/(parameters.eta(1)*parameters.sbomegacarrier),0.5,1,1,1,fxpa2,time+(1)*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa,time+1*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(0.5,ls+0.5,1,1,fxpa,time+420*delayunit);
%p = p + 1;[pulse(p),time] = Rcar(0.5,0.5,1,1,fxpa,time+100*delayunit); 
%p = p + 1;[pulse(p),time] = Rcar(0.5,0.5,2,1,fxpa,time+1*delayunit); 

%p = p + 1;[pulse(p),time] = Rcar(0.5,0.3,1,1,fxpa,time+14*delayunit); 


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
%setstatevisibility(1,ones(1,hspace.nuions),1);
%setstatevisibility(0)
displaypopulations(T,Y,[0 0;0 1;1 0;  1 1 ;],hspace);
[PF,PH]=endpopulations(T,Y',hspace);
%tracedpopulations(T,Y,hspace,1);
hold on;
%*****************************************************************************%
closemessagewindow;
save acentangle
