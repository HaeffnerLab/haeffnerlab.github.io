% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

hspace=definehspace(3,3,[1 1]);
parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=1;
parameters.points=1;
parameters.omegacarrier=1.5*2*pi/29.4e-6;
parameters.sbomegacarrier=2*pi/(0.2e-3*0.0176);
parameters.addressing=[1 0.05 0.05 ; 0.05 1 0.05; 0.05 0.05 1];
parameters.recoilangle=68;
parameters.omegaz=1200000*2*pi*[1 sqrt(3)];
parameters.eigenvectors=[1 1 1; -1 0.0001 1;];
parameters.detuning=2*pi*0e3;
parameters.hspace.densitymatrixformalism=0;


%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0 0],parameters.hspace))=1;




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
delayunit=delayunit*1.05;



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


p = p + 1;[pulse(p),time] = Rblue(0.5,0,1,1,1,fxpa,time*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1  ,0,1,2,2,fxpa,time*delayunit); 
p = p + 1;[pulse(p),time] = Rcar( 1  ,0,1,  2,fxpa,time+1*delayunit); 

p = p + 1;[pulse(p),time] = Rcar( 1,0,2,  1,fxpa,time+1*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,1,fxpa,time*delayunit);

p = p + 1;[pulse(p),time] = Rcar( 1,0,3,  1,fxpa,time+1*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,3,2,1,fxpa,time*delayunit); 


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

displaypopulations(T,Y,[0 0 0; 1 0 0; 0 1 0; 1 1 1;],hspace);
setstatevisibility([1 1],[2 2 2],hspace);
endpopulations(T,Y,hspace);

%*****************************************************************************%
closemessagewindow;
