% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
%
clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,[2 2],0);

parameters=standardparameters(hspace);

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.points=400;
parameters.eigenvectors=[1 ; 1 ; 1];
parameters.omegacarrier=0.1*2*pi/29.4e-6;
%parameters.omegacarrier=1*2*pi/12e-6;
parameters.sbomegacarrier=2*pi/(0.15e-3*0.036);
%parameters.addressing=[0.00 0.00 0.01 i*0.04 1; 0.00 0.01 -i*0.04 1 0.03; 0.01 -0.03 1 0.04 0.01; i*0.04 1 -0.03 0.01 0.00; 1 i*0.04 0.01  0.00 0.00;];
%parameters.addressing=[0.00 0.00 0.01 1*0.04 1; 0.00 0.01 1*0.04 1 0.03; 0.01 -0.03 1 0.04 0.01; 1*0.04 1 -0.03 0.01 0.00; 1 1*0.04 0.01  0.00 0.00;];
parameters.recoilangle=68;
parameters.omegaz=2*pi*1000000*[1 sqrt(3)];
%parameters.omegaz=1000000*2*pi;
%parameters.detuning=-4e5; % 
%parameters.detuning=-0.*10.*1.5*2*pi/29.4e-6;
%parameters.eta=[0.015 -0.03 0.015];
parameters.decoherences.intensity_fluctuations=0
parameters.odesolve=1;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0=state([1 0],1)';




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa.includelsdetuning=1
fxpa1=fxpa;
fxpa2=fxpa;
fxpa1.detuning=1.5014e5;
fxpa2.detuning=1.9568e5;
%fxpa2.detuning=0.*1.5e5;
%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)
timeR2=time;

p = p + 1;[pulse(p),time] = Rred(1,0,1,1,1,fxpa1,time); %Raman1 pulse
p = p + 1;[pulse(p),time] = Rred(1,0,1,2,1,fxpa2,timeR2);  %Raman2 Pulse
%p = p + 1;[pulse(p),time] = Rblue(1,0,1,2,1,fxpa2,timeR2*delayunit);  %Raman2 Pulse

%p = p + 1;[pulse(p),time] = Rcar(   0.5,0,1,1,fxpa,time*delayunit);
%time=time+200;
%p = p + 1;[pulse(p),time] = Rcar(   0.5,0,1,1,fxpa,time*delayunit);

%time1=time;
%p = p + 1;[pulse(p),time] = Rblue(0.5,0,1,1,fxpa1,time*delayunit);
%p = p + 1;[pulse(p),time] = Rblue(   0.5,0,1,1,fxpa1,time1*delayunit);


%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;

setstatevisibility(1,hspace);
displaypopulations(T,Y,[1; 0 ],hspace);
[PF,PH]=endpopulations(T,Y,hspace);
%phonontracedpopulations(T,Y,[1 1 1; 0 0 1; 0 0 0;],hspace);

%*****************************************************************************%
closemessagewindow;
