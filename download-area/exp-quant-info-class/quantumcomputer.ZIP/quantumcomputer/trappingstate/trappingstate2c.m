% 3.2.00
% Erzeugung von "trapping states"
% Annahmen: Konstante Pulse im einzelnen Durchgang, jedoch fluktuiert  
%           die Rabifrequenz um den optimalen Wert. Mittelung ueber eine Reihe
%            solcher Fluktuationen 
% Mit (optionalem) Binomialrauschen [RAUSCH=1 setzen]

nmax = 300;               %  maximale Schwingungsquantenzahl
Np   = 250;               %  Anzahl : Pulse
nt   = 80;               %  angestrebte Schwingungsquantenzahl
sigma= 0.05;            % Fluktuationen in Rabifreq. (diese gleichverteilt um 
                        % optimalen Wert
M    = 100               % Anzahl der Realisierungen
RAUSCH=1;

tpuls= 2*pi/sqrt(nt+1);  %  Pulsdauer
n    = 0:1:nmax;         %  verwendete |n>-Zustaende

P=0*n;
for m=1:M
  fakt=1+(rand(1)-.5)*2*sigma;
  om   = sqrt(1:1:nmax+1); % Rabifrequenz: blaues Seitenband fuer |S,n>
  om   = om*fakt;  % Rabifrequenz etwas falsch eingestellt 
  Fakt(m)=fakt;
  % Entwicklung der Population unter Pulsanregung :

  % thermisch:
    s=1;
    nbar=10;
  % Reiner Zustand n=0:
     s=0;
  if(s==1)
    p_s=(nbar/(nbar+1)).^n;
    p_s=p_s/sum(p_s);
  else 
    p_s  = 0*n;              %  Besetzung im |S,n>-Zustand: alle 0, bis auf n=0
    p_s(1)= 1;               %  nur n=0 besetzt
end

  for j=1:1:Np
  %  j 
  %  bar(n,p_s) 
  %  pause
    p_s_bleibt = p_s.*(cos(om/2*tpuls)).^2;    % Kohaerente Anregung 
    p_s_geht   = p_s.*(sin(om/2*tpuls)).^2;
    p_s = p_s_bleibt + [0 p_s_geht(1:nmax)];   % Umpump-Prozess ("854")
  end

  %bar(n,p_s)
  %pause
  P=P+p_s;
end
'gemittelt '
%subplot(4,1,1)
x=0.8:.01:1.2;
h=hist(Fakt,x);
%bar(x,h);
subplot(3,1,1)
bar(n,P/sum(P),'r')
axis([0 nmax/3 0 max(P/sum(P))])

Nmax=20;
tmax=(Nmax*.3)*2*pi/sqrt(nt+1);
j=0;
for t=0:(tmax/200):tmax
  j=j+1;
  p=P.*(cos(sqrt(1:1:nmax+1)/2*t)).^2;
  pm=sum(p)/M;
  x=rand(M,1);
  PopR(j)=sum(x<pm)/M;
  Pop(j)=pm;
  T(j)=t;
end
subplot(3,1,2)
if(RAUSCH==1)
  Pop=PopR;
end
plot(T,Pop)
 
% Zustandsrekonstruktion :
  
  Pop=Pop-mean(Pop);                  % um Null verschieben 
  PPoPP=[ Pop(length(Pop):-1:2) Pop]; % und in der Zeit spiegeln
  TT   =[ - T(length(T  ):-1:2)  T ];

  ff  = fftpow(TT,PPoPP);             % Fouriertransformation
  nvib= (2*pi*ff(1,1:length(ff(2,:))/2)).^2-1; 
  r_n = ff(2,1:length(ff(2,:))/2);

  subplot(3,1,3)
  Nvib = 0:1:max(nvib);               % Binning
  R_n  = interp1(nvib,r_n,Nvib);
  R_n  = R_n/sum(R_n);
  bar(Nvib,R_n,'r');
  axis([0 nmax/3 0 max(R_n)])





