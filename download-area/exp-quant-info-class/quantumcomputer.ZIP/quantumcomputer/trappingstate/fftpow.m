% 4.2.00
% Berechnet das Leistungsspektrum der Funktion x(t)
% liefert eine Matrix zurueck: 
%        1. Spalte (Frequenzen)
%        2. Spalte (Leistungspektrum)

function fy=fftpow(t,x)

  N=length(t);
  dT=max(t)-min(t);
  y=abs(fft(x)).^2;
  f=(t-min(t))*N/dT^2;
 
  fy=[f;y];
