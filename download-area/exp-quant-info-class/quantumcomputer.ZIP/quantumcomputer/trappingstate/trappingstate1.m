% 3.2.00
% Erzeugung von "trapping states"
% Annahmen: Perfekte Pulse, keinerlei fluktuierende Prozesse
%           allerdings kann die Rabifrequent vom optimalen Wert abweichen 
%            -> Zeile 16   

nmax = 80;               %  maximale Schwingungsquantenzahl
Np   = 100;               %  Anzahl : Pulse
nt   = 3.5;               %  angestrebte Schwingungsquantenzahl
tpuls= 2*pi/sqrt(nt+1);  %  Pulsdauer
n    = 0:1:nmax;         %  verwendete |n>-Zustaende

% thermisch:
  s=1;
  nbar=5;
% grundzustand:
%  s=0
if(s==1)
  p_s=(nbar/(nbar+1)).^n;
  p_s=p_s/sum(p_s);
else 
  p_s  = 0*n;              %  Besetzung im |S,n>-Zustand: alle 0, bis auf n=0
  p_s(1)= 1;               %  nur n=0 besetzt
end

om   = sqrt(1:1:nmax+1); % Rabifrequenz: blaues Seitenband fuer |S,n>
%om   = om*sqrt(sqrt((nt+1)/nt));  % Rabifrequenz maximal falsch eingestellt 

% Entwicklung der Population unter Pulsanregung :

for j=1:1:Np
  j 
  bar(n,p_s) 
  pause(.1)
  p_s_bleibt = p_s.*(cos(om/2*tpuls)).^2;    % Kohaerente Anregung 
  p_s_geht   = p_s.*(sin(om/2*tpuls)).^2;
  p_s = p_s_bleibt + [0 p_s_geht(1:nmax)];   % Umpump-Prozess ("854")
end
