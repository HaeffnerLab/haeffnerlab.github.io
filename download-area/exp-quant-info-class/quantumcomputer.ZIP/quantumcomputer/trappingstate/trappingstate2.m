% 3.2.00
% Erzeugung von "trapping states"
% Annahmen: Konstante Pulse im einzelnen Durchgang, jedoch fluktuiert  
%           die Rabifrequenz um den optimalen Wert. Mittelung ueber eine Reihe
%            solcher Fluktuationen 


nmax = 100;               %  maximale Schwingungsquantenzahl
Np   = 100;               %  Anzahl : Pulse
nt   = 3.5;               %  angestrebte Schwingungsquantenzahl
sigma= 0.025;            % Fluktuationen in Rabifreq. (diese gleichverteilt um 
                        % optimalen Wert
M    = 50               % Anzahl der Realisierungen

tpuls= 2*pi/sqrt(nt+1);  %  Pulsdauer
n    = 0:1:nmax;         %  verwendete |n>-Zustaende

P=0*n;
for m=1:M
  fakt=1+(rand(1)-.5)*2*sigma;
  om   = sqrt(1:1:nmax+1); % Rabifrequenz: blaues Seitenband fuer |S,n>
  om   = om*fakt;  % Rabifrequenz etwas falsch eingestellt 
  Fakt(m)=fakt;
  % Entwicklung der Population unter Pulsanregung :
  p_s  = 0*n;              %  Besetzung im |S,n>-Zustand: alle 0, bis auf n=0
  p_s(1)= 1;               %  nur n=0 besetzt

  for j=1:1:Np
  %  j 
  %  bar(n,p_s) 
  %  pause
    p_s_bleibt = p_s.*(cos(om/2*tpuls)).^2;    % Kohaerente Anregung 
    p_s_geht   = p_s.*(sin(om/2*tpuls)).^2;
    p_s = p_s_bleibt + [0 p_s_geht(1:nmax)];   % Umpump-Prozess ("854")
  end

  %bar(n,p_s)
  %pause
  P=P+p_s;
end
'gemittelt '
subplot(3,1,1)
x=0.8:.01:1.2;
h=hist(Fakt,x);
bar(x,h);
subplot(3,1,2)
bar(n,P,'r')

Nmax=10;
tmax=Nmax*2*pi/sqrt(nt+1);
j=0;
for t=0:(tmax/200):tmax
  j=j+1;
  p=P.*(cos(sqrt(1:1:nmax+1)/2*t)).^2;
  Pop(j)=sum(p);
  T(j)=t;
end
subplot(3,1,3)
plot(T,Pop)

