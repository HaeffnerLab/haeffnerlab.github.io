% 3.2.00
% Erzeugung von "trapping states"
% Annahmen: Perfekte Pulse, keinerlei fluktuierende Prozesse
%           allerdings kann die Rabifrequent vom optimalen Wert abweichen 
%            -> Zeile 16   

clear all;
clf;
nmax = 100;               %  maximale Schwingungsquantenzahl
Np   = 5;               %  Anzahl : Pulse
nt   = 2.5;               %  angestrebte Schwingungsquantenzahl
tpuls= 2*pi/sqrt(nt+1);  %  Pulsdauer
n    = 0:1:nmax;         %  verwendete |n>-Zustaende

% thermisch:
  s=1;
  nbar=10;
% Reiner Zustand n=0:
%  s=0

if(s==1)
  p_s=(nbar/(nbar+1)).^n;
  p_s=p_s/sum(p_s);
else 
  p_s  = 0*n;              %  Besetzung im |S,n>-Zustand: alle 0, bis auf n=0
  p_s(1)= 1;               %  nur n=0 besetzt
end

om   = sqrt(1:1:nmax+1); % Rabifrequenz: blaues Seitenband fuer |S,n>
%om   = om*sqrt(sqrt((nt+1)/nt));  % Rabifrequenz maximal falsch eingestellt 

% Entwicklung der Population unter Pulsanregung :

for j=1:1:Np
  j 
  p_s_bleibt = p_s.*(cos(om/2*tpuls)).^2;    % Kohaerente Anregung 
  p_s_geht   = p_s.*(sin(om/2*tpuls)).^2;
  p_s = p_s_bleibt + [0 p_s_geht(1:nmax)];   % Umpump-Prozess ("854")
  
% Verteilung des Schwingungsquanten :

  subplot(3,1,1)                     
  bar(n,p_s) 
  axis([0 nmax/3 0 max(p_s)])

% Zeitentwicklung dieses Zustands

  Nmax=10;
  tmax=0.3*Nmax * 2*pi/sqrt(nt+1);
  k=0;
  for t=0:(tmax/250):tmax
    k=k+1;
    p=p_s.*(cos(sqrt(1:1:nmax+1)/2*t)).^2;
    Pop(k)=sum(p);
    T(k)=t;
  end
  subplot(3,1,2)
  plot(T,Pop)

% Zustandsrekonstruktion :
  
  Pop=Pop-mean(Pop);                  % um Null verschieben 
  PPoPP=[ Pop(length(Pop):-1:2) Pop]; % und in der Zeit spiegeln
  TT   =[ - T(length(T  ):-1:2)  T ];

  ff  = fftpow(TT,PPoPP);             % Fouriertransformation
  nvib= (2*pi*ff(1,1:length(ff(2,:))/2)).^2-1; 
  r_n = ff(2,1:length(ff(2,:))/2);

  subplot(3,1,3)
  Nvib = 0:1:max(nvib);               % Binning
  R_n  = interp1(nvib,r_n,Nvib);
  R_n  = R_n/sum(R_n);
  bar(Nvib,R_n,'r');
  axis([0 nmax/3 0 max(R_n)])
  pause(.5)
end
