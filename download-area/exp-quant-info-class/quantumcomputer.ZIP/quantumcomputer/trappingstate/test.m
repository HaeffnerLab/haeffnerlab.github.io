% 3.2.00
% Erzeugung von "trapping states"
% Annahmen: Konstante Pulse im einzelnen Durchgang, jedoch fluktuiert  
%           die Rabifrequenz um den optimalen Wert. Mittelung ueber eine Reihe
%            solcher Fluktuationen 

load ../../../daten/00/000406/qf2205t;
load ../../../daten/00/000406/qf2201t;
load ../../../daten/00/000406/qf2157t;
load ../../../daten/00/000406/qf2144t;
load ../../../daten/00/000406/qf2141t;
load ../../../daten/00/000406/qf2137t;
Tdat=qf2137t(:,1)*1e6;
Dat=1-[qf2205t(:,3) qf2201t(:,3) qf2157t(:,3) qf2144t(:,3) qf2141t(:,3) qf2137t(:,3)];

Pulse=[0 1 3 10 30 80];
for ni=1:6

nmax = 100;               %  maximale Schwingungsquantenzahl
Np   = Pulse(ni);               %  Anzahl : Pulse
nt   = 8;               %  angestrebte Schwingungsquantenzahl
sigma= 0.07;            % Fluktuationen in Rabifreq. (diese gleichverteilt um 
                        % optimalen Wert (sigma_Rabi=sigma/sqrt(3))
M    = 100;               % Anzahl der Realisierungen

tpuls= 2*pi/sqrt(nt+1);  %  Pulsdauer
n    = 0:1:nmax;         %  verwendete |n>-Zustaende

P=0*n;
for m=1:M
  fakt=1+(rand(1)-.5)*2*sigma;
  om   = sqrt(1:1:nmax+1); % Rabifrequenz: blaues Seitenband fuer |S,n>
  om   = om*fakt;  % Rabifrequenz etwas falsch eingestellt 
  Fakt(m)=fakt;
  % Entwicklung der Population unter Pulsanregung :

  % thermisch:
   % s=1;
    nbar=50;
  % Reiner Zustand n=0:
    s=0;
  if(s==1)
    p_s=(nbar/(nbar+1)).^n;
    p_s=p_s/sum(p_s);
  else 
    p_s  = 0*n;              %  Besetzung im |S,n>-Zustand: alle 0, bis auf n=0
    p_s(1)= 1;               %  nur n=0 besetzt
end

  for j=1:1:Np
  %  j 
  %  bar(n,p_s) 
  %  pause
    p_s_bleibt = p_s.*(cos(om/2*tpuls)).^2;    % Kohaerente Anregung 
    p_s_geht   = p_s.*(sin(om/2*tpuls)).^2;
    p_s = p_s_bleibt + [0 p_s_geht(1:nmax)];   % Umpump-Prozess ("854")
  end

  %bar(n,p_s)
  %pause
  P=P+p_s;
end
Nmax=7;
tmax=(Nmax)*2*pi/sqrt(nt+1);
j=0;
for t=0:(tmax/200):tmax
  j=j+1;
  p=P.*(cos(sqrt(1:1:nmax+1)/2*t)).^2;
  Pop(j)=sum(p)/M;
  T(j)=t;
end
subplot(6,1,ni)
plot(T*100/11,1-Pop)
hold on
plot(Tdat-.14,Dat(:,ni),'r')
axis([0 100 0 1])
end
