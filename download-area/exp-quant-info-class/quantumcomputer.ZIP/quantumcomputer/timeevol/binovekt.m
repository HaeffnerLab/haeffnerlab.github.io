% Berechnung von Binomialkoeffizienten
% Das Argument k darf ein Vektor sein

function b=binovekt(n,k)

b = gamma(n+1)./ (gamma(k+1).*gamma(n-k+1));