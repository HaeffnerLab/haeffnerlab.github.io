% berechnet die Kopplungsstaerken auf dem blauen seitenband fuer verschiedene Werte von
% eta und n;
% eta : Effektiver Lamb-Dicke-Parameter
% n : Phononzahl
% benutzt dabei tabellierte Kopplungsstaerken :
% omegablau(:,m)  : Kopplungsstaerken fuer eta=0.01*m

%clear
nmax=100;          % Verteilung wird bei nmax abgeschnitten
omnull=2*pi*545e3/sqrt(40);
nbar=15;

load omegablau;
m=5;          % zB:  m=7  -> eta=.07;
om = omegablau(:,m);


%plot(0:1:nmax,om.^2,'.-');
%title('Kopplung^2')
%xlabel('n')
%pause;

n   = 0:1:nmax;                        % thermischer Zustand bis n=nmax;
pn  = (nbar/(nbar+1)).^n/(nbar+1);
%plot(n,pn,'.-')
%title('Thermische Verteilung')
%pause;

dt = .2e-6;      % Zeitintervall        % Zeitentwicklung
c=dt*omnull; 

for tm  = 1:1:400;   % Zeitschritte
   pt = ((cos(c*om*tm)).^2)'*pn';
   p(tm)=pt;         % Besetzungswahrscheinlichkeit 
   t(tm)=tm;         % Zeit
end

plot(t*dt*1e6,p)
%title('Besetungswahrscheinlichkeit')
xlabel('Zeit')
