% 23.4.00 : Verwendet "singular value decomposition", um aus Rabiflopdaten auf
%           dem blauen Seitenband die thermische Verteilung zu bestimmen
%
%  Verschiedene Modelle : 1. Rabiflops auf Resonanz
%                         2. Rabiflops verstimmt
%                         3. Rabiflops mit Kontrastverlust
%                         4. Rabiflops verstimmt+Kontrastverlust

% Einlesen der Daten

load ../../../daten/00/000523/qf0122t;
load ../../../daten/00/000523/qf0124t;
load ../../../daten/00/000523/qf0129t;
load ../../../daten/00/000523/qf0132t;
load ../../../daten/00/000523/qf0134t;
load ../../../daten/00/000523/qf0137t;
load ../../../daten/00/000523/qf0142t;
load ../../../daten/00/000523/qf0145t;
load ../../../daten/00/000523/qf0147t;
load ../../../daten/00/000523/qf0208t;


%--------------------------
qf=qf0208t;

 t   = qf(:,1)-.15e-6;
 data= (1-qf(:,3))/.99;

% Einschraenkung des Datensatzes
 %tmin = min(t);
 tmin=0;
 tmax = max(t);
 Data = data(t<=tmax & t>=tmin);
 T    =    t(t<=tmax & t>=tmin);

%Anzahl freier Parameter : nmax+1
 nmax=10;
 N=0:1:nmax;

%omnull=2*pi*11700;       % Rabifrequenz |S,0> <-> |D,1>  / Hz
%delt  =2*pi*3000;        % Verstimmung                   / Hz

omnull=2*pi*13100;       % Rabifrequenz |S,0> <-> |D,1>  / Hz
delt  =2*pi*0;

% Generiert die Matrix:
 [N_m,T_m] = meshgrid(N,T);

% Der einfachste Fall: keine Verstimmung, kein Kontrastverlust
   A=sin(T_m.*sqrt((N_m+1))*omnull/2).^2;

% Rabiflops bei Verstimmung
 %  F=(N_m+1)*omnull^2./((N_m+1)*omnull^2+delt^2);
 %  A=F.*sin(T_m.*sqrt((N_m+1)*omnull^2+delt^2)/2).^2;

% Rabiflops bei Kontrastverlust :
 %  etan=0.03;
 %  OMT=T_m.*sqrt(N_m+1)*omnull;
 %  A=.5*(1-(cos(OMT)+etan*OMT.*sin(OMT))./(1+(etan*OMT).^2));

% Rabiflops bei Kontrastverlust + Verstimmung :
   etan=0.03;
 %  OMT=T_m.*sqrt((N_m+1)*omnull^2+delt^2);
 %  F=(N_m+1)*omnull^2./((N_m+1)*omnull^2+delt^2);
 %  A=.5*F.*(1-(cos(OMT)+etan*OMT.*sin(OMT))./(1+(etan*OMT).^2));

% SVD-Zerlegung :
 [U,W,V]=svd(A);
 w=diag(W);
 IW=zeros(size(W'));
 for j=1:length(w);
   IW(j,j)=1/w(j);
 end

% Berechnet die Verteilung
 p=V*IW*U'*Data;

% Rekonstruktion der Daten + Darstellung
 Datafit=A*p;
 subplot(2,1,1)
 plot(T*1e6,Data,'or','MarkerSize',2,'Linewidth',2);
 hold on
 plot(T*1e6,Datafit);
 subplot(2,1,2)
 bar(p);
 hold off;

 N*p/sum(p)

 print -deps atestsvd.eps
