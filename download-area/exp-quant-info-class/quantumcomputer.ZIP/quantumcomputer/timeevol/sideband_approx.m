% berechnet die Kopplungsstaerken auf dem Seitenband fuer verschiedene 
% Werte von eta und n;
% approximiert die Kopplungsstaerken auf dem blauen Seitenband durch sqrt(n+1)
% eta : Effektiver Lamb-Dicke-Parameter
% n : Phononzahl

clear
nmax=20;          % Verteilung wird bei nmax abgeschnitten
omnull=2*pi*200e3;
nbar= .1;
eta=.06;

etaquad=eta^2;

for k=0:1:nmax;
   n(k+1)=k;
   om(k+1)=sqrt(k+1)*eta;
end

om=exp(-etaquad)*om;

% plot(n-1,om.^2);
% title('Kopplung^2')
% xlabel('n')

% pause;

n   = 0:1:nmax;                        % thermischer Zustand bis n=nmax;
pn  = (nbar/(nbar+1)).^n/(nbar+1);
% plot(n-1,pn)
% title('Thermische Verteilung')

% pause;

dt = 2e-6;      % Zeitintervall        % Zeitentwicklung
c=dt*omnull; 

for tm  = 1:1:150;   % Zeitschritte
   pt = ((cos(c*om*tm)).^2)*pn';
   p(tm)=pt;         % Besetzungswahrscheinlichkeit 
   t(tm)=tm;         % Zeit
end

plot(t*dt*1e6,p)
title('Besetungswahrscheinlichkeit')
xlabel('Zeit')

