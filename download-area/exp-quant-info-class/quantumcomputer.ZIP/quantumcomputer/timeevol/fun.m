function res=fun(t,y)

A=[0 1;
   -1 0];

res=A*y;