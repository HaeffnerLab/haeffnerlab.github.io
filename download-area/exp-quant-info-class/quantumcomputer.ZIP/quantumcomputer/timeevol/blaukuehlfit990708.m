 % 17.4.99 Christian Roos
% Programm zum Anfitten der Daten vom 8.7.99 
% Als Unterprogramm wird das file blaukuehlfit_fehler.m verwendet
% Angefittet wird :
%  


%clear;clf;
global T Data 


load ../../daten/99/990708/qf2207t;
load ../../daten/99/990708/qf2202t;
 qf=[qf2202t;qf2207t];
 qf=sortrows(qf,1);
 t   = qf(:,1);
 ps  = qf(:,3);
 
 T   = t(t<600e-6);
 Data= ps(t<600e-6);

 plot(T,Data); 

 omegaetaz = (2*pi) * 12e3;
 etar  = 0.057;
 nr    = 10; 
 nz =.1;

 etan = etar^2*(nr+1);
 startpar=[omegaetaz etan nz];
 fitpar=fmins('blaukuehlfit_fehler',startpar);
  
 ['omega = ' num2str(fitpar(1)/(2*pi))]
 ['etan  = ' num2str(fitpar(2))]
 ['nz    = ' num2str(fitpar(3))]
 
p=fitpar;
x=2*p(1)*T;
y=x*p(2);
f0 = (1 + (cos(x) + y .*sin(x)) ./ (1 + y.^2))/2;
x=2*p(1)*T*sqrt(2);
y=x*p(2);
f1 = (1 + (cos(x) + y .*sin(x)) ./ (1 + y.^2))/2;
fitwerte = (1-p(3)) * f0 + p(3) * f1;

plot(T,fitwerte,T,Data,'.')
 




