% berechnet Rabioszillationen fuer verschiedene 
% Werte von n;
% approximiert die Kopplungsstaerken auf dem blauen Seitenband durch sqrt(n+1)
% 
% n : Phononzahl

clear
omnull=2*pi*200e3; % Rabifrequenz ohne allen Scheiss

nbarax=[2,0]             % mittlere Phononenzahl in den axialen Moden 
nmaxax=max(nbarax+1)*7;          % Verteilung wird bei nmax abgeschnitten

nbarra=[3,3]             % mittlere Phononenzahl in den radialen Moden 
nmaxra=max(nbarra+1)*7;          % Verteilung wird bei nmax abgeschnitten

etaax = lambdicke(729*10^-9,940000,68)
etara = lambdicke(729*10^-9,5000000,22)

[nax,nra]=meshgrid(0:nmaxax,0:nmaxra);

omcarax=1-etaax^2*nax;      % Rabifrequenzen auf 'em Traeger
omcarra=1-etara^2*nra;

omblueax=sqrt(nax+1)*etaax;
omredax=sqrt(nax)*etaax;
for k=1:length(nbarax)
   pnax(k,:,:) = (nbarax(k)/(nbarax(k)+1)).^nax/(nbarax(k)+1);
end;

ombluera=sqrt(nra+1)*etara;
omredra=sqrt(nra)*etara;
for k=1:length(nbarra)
   pnra(k,:,:)  = (nbarra(k)/(nbarra(k)+1)).^nra/(nbarra(k)+1);
end;

om = omblueax.*omcarax.*omcarra.*omcarra;   % Rabifrequenz fuer alle Moeglichkeiten ausrechnen

for k = 1:1000
   t(k) = (k-1)/(5);
   bes(k) = sum(sum(pnax(1).*pnax(2).*sin(om*t(k)*pi).^2));
end;
figure(1);
clf;
plot(t,bes)
axis([0,max(t),0,min(1,max(bes)])
ylabel('Besetzungswahrscheinlichkeit')
xlabel('Zeit [T_{Rabi}]')

