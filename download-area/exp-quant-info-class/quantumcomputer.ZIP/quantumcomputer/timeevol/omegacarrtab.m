ne% 6.6.99
% berechnet die Kopplungsstaerken auf dem Traeger fuer 
% verschiedene Werte von eta und n;
% om    : exakter Wert
% omappr: Naeherungsloesung
% eta   : Effektiver Lamb-Dicke-Parameter
% n     : Phononzahl

% Kopplungen in omegacarrtabelle abgespeichert

nmax=100;          % Verteilung wird bei nmax abgeschnitten


for j=1:1:20

  eta=j/100;
  etaquad=eta^2;

  for k=0:1:nmax;
     n(k+1)=k;
     om(k+1)=laguerre(k,0,etaquad);
     omappr(k+1)=1-k*etaquad;
  end
  plot(n,om,n,omappr);
  title(['Kopplung fuer eta =',num2str(eta)])
  xlabel('n')
  pause
  
  omega(:,j)=om';
end




