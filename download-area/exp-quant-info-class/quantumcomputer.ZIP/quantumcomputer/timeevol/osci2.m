% berechnet Rabioszillationen fuer verschiedene 
% Werte von n;
% approximiert die Kopplungsstaerken auf dem blauen Seitenband durch sqrt(n+1)
% 
% n : Phononzahl

clear

nbar = [
   1,
   0.05,
   3,
   3]             % mittlere Phononenzahl in den Moden

zeitdauer = 15;   % Zeitdauer in Oszillationen
zeitaufloesung = 30; % Aufloesung dedr Oszillationen

nmax=round((nbar+0.99999)*5);          % Verteilung wird bei nmax abgeschnitten

eta = [lambdicke(729*10^-9,940000,68),
       lambdicke(729*10^-9,940000,68),
       lambdicke(729*10^-9,5000000,22),
       lambdicke(729*10^-9,5000000,22)];
    
    
[a,b,c,d]=ndgrid(0:nmax(1),0:nmax(2),0:nmax(3),0:nmax(4));

n(1,:,:,:,:)=a(:,:,:,:);
n(2,:,:,:,:)=b(:,:,:,:);
n(3,:,:,:,:)=c(:,:,:,:);
n(4,:,:,:,:)=d(:,:,:,:);

fprintf('Mode:');
for k=1:4    % moden durchzaehlen
   fprintf(' %g,',k);
   omcar(k,:,:,:,:)=1-eta(k).^2*n(k,:,:,:,:);
   omblue(k,:,:,:,:)=sqrt(n(k,:,:,:,:)+1).*eta(k);
   omred(k,:,:,:,:)=sqrt(n(k,:,:,:,:)).*eta(k);
   pn(k,:,:,:,:)  = (nbar(k)/(nbar(k)+1)).^n(k,:,:,:,:)/(nbar(k)+1);
end;

om = squeeze(omcar(1,:,:,:,:).* ...   % HIER die Anregungsart eingeben  (omcar, omblue oder omred)!
					omblue(2,:,:,:,:).* ...
 					omcar(3,:,:,:,:).* ...
                omcar(4,:,:,:,:));    % Rabifrequenz fuer alle Moeglichkeiten ausrechnen
                
p=squeeze(pn(1,:,:,:,:).*pn(2,:,:,:,:).*pn(3,:,:,:,:).*pn(4,:,:,:,:));
fprintf('\n');


fr=reshape(om,prod(nmax+1),1);
pr=reshape(p,prod(nmax+1),1);

am=zeros(1000,1);
for k=1:prod(nmax+1)
   n=round(fr(k)*1000);
   am(n)=am(n)+pr(k);
end;

figure(1);
clf;
plot(0.001:0.001:1,am)
%axis([0,max(t),0,1])
ylabel('Besetzungswahrscheinlichkeit')
xlabel('Frequenz [\nu_{Rabi}]')
s=sprintf('%g | ',nbar);
text(0.2,max(am)*0.9,s)

[m,mainfrequ]=max(am);
mainfrequ=mainfrequ/1000

fprintf('\nZeitschritt');
sc=zeitaufloesung*mainfrequ;
for k = 1:zeitdauer*zeitaufloesung
   fprintf(' %g,',k);
   t(k) = (k-1)/sc;
   bes(k) = sum(sum(sum(sum(p.*sin(om*t(k)*pi).^2))));
end;
fprintf('\n');
figure(2);
clf;
plot(t,bes)
axis([0,max(t),0,1])
ylabel('Besetzungswahrscheinlichkeit')
xlabel('Zeit [T_{Rabi}]')
s=sprintf('%g | ',nbar);
text(max(t)*0.5,0.9,s)

fprintf('Maximale Umbesetzung: %g\n',max(bes(1:zeitaufloesung)));

ft=abs(fft(bes));
ft=ft(2:length(ft)).^2;
ft=max(am)/max(ft)*ft;
figure(1)
hold on;
f=(1:length(ft))/length(ft)*sc;
plot(f,ft,'r')
axis([0,1.2*mainfrequ,0,max(ft)*1.1])
