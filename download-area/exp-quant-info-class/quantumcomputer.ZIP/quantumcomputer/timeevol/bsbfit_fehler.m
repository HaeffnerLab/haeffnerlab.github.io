% Unterprogramm fuer die Funktion  'bsbfit.m'

function f=bsbfit_fehler(p)
global Data T

fitwerte = bsbfit_fun(p);
f = sum((fitwerte-Data).^2);
