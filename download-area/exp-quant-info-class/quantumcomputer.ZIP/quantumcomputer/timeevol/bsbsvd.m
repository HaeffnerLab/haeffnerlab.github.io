% 23.4.00 : Verwendet "singular value decomposition", um aus Rabiflopdaten auf 
%           dem blauen Seitenband die thermische Verteilung zu bestimmen
%
%  Verschiedene Modelle : 1. Rabiflops auf Resonanz
%                         2. Rabiflops verstimmt
%                         3. Rabiflops mit Kontrastverlust
%                         4. Rabiflops verstimmt+Kontrastverlust

% Einlesen der Daten

% load ../../../daten/00/000419/qf2317t;
% load ../../../daten/00/000419/qf2323t;
% load ../../../daten/00/000419/qf2328t;
% qf=[qf2317t;qf2323t;qf2328t];

 load ../../../daten/00/000419/qf0535t;
 load ../../../daten/00/000419/qf0537t;
 load ../../../daten/00/000419/qf0539t;
 qf=[qf0535t;qf0537t;qf0539t];

 t   = qf(:,1)-.15e-6;
 data= (1-qf(:,3))/.99;

% Einschraenkung des Datensatzes
 %tmin = min(t);
 tmin=0;
 tmax = max(t);
 Data = data(t<=tmax & t>=tmin);
 T    =    t(t<=tmax & t>=tmin);

%Anzahl freier Parameter : nmax+1
 nmax=10;
 N=0:1:nmax;

%omnull=2*pi*11700;       % Rabifrequenz |S,0> <-> |D,1>  / Hz
%delt  =2*pi*3000;        % Verstimmung                   / Hz

omnull=2*pi*14065;       % Rabifrequenz |S,0> <-> |D,1>  / Hz
delt  =2*pi*4000;

% Generiert die Matrix:
 [N_m,T_m] = meshgrid(N,T);
% Der einfachste Fall: keine Verstimmung, kein Kontrastverlust
 %  A=sin(T_m.*sqrt((N_m+1))*omnull/2).^2;
  
% Rabiflops bei Verstimmung
 %  F=(N_m+1)*omnull^2./((N_m+1)*omnull^2+delt^2);
 %  A=F.*sin(T_m.*sqrt((N_m+1)*omnull^2+delt^2)/2).^2;

% Rabiflops bei Kontrastverlust :
 %  etan=0.03;
 %  OMT=T_m.*sqrt(N_m+1)*omnull;
 %  A=.5*(1-(cos(OMT)+etan*OMT.*sin(OMT))./(1+(etan*OMT).^2));

% Rabiflops bei Kontrastverlust + Verstimmung :
   etan=0.03;
   OMT=T_m.*sqrt((N_m+1)*omnull^2+delt^2);
   F=(N_m+1)*omnull^2./((N_m+1)*omnull^2+delt^2);
   A=.5*F.*(1-(cos(OMT)+etan*OMT.*sin(OMT))./(1+(etan*OMT).^2));

% SVD-Zerlegung :
 [U,W,V]=svd(A);
 w=diag(W);
 IW=zeros(size(W'));
 for j=1:length(w);
   IW(j,j)=1/w(j);
 end

% Berechnet die Verteilung
 p=V*IW*U'*Data;

% Rekonstruktion der Daten + Darstellung
 Datafit=A*p;
 f1=figure(1);
 plot(T*1e6,Data,'or','MarkerSize',2,'Linewidth',2);
 hold on
 plot(T*1e6,Datafit);
 hold off
 f2=figure(2);
 bar(p);

 N*p/sum(p)






