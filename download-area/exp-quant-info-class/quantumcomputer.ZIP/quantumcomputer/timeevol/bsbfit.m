% 21.4.00 
% Fittet thermische Verteilung an Datensatz:
% Fitparameter : mittlere Schwingungsquantenzahl,Rabifrequenz,Verstimmung

clear;clf;
global T Data 

n=0;
om=2*pi*13.4e3;
delt=2*pi*0e3;

load ../../../daten/00/000523/qf0231t;
load ../../../daten/00/000523/qf0233t;
load ../../../daten/00/000523/qf0235t;
load ../../../daten/00/000523/qf0241t;
load ../../../daten/00/000523/qf0243t;
load ../../../daten/00/000523/qf0246t;

load ../../../daten/00/000523/qf0229t;
load ../../../daten/00/000523/qf0227t;


%load ../../../daten/00/000419/qf0535t;
%load ../../../daten/00/000419/qf0537t;
%load ../../../daten/00/000419/qf0539t;

%qf=[qf0535t;qf0537t;qf0539t];
qf=[qf0241t;qf0243t;qf0246t];
%qf=qf0235t;

t   = qf(:,1)-.15e-6;
data= (1-qf(:,3))/.99;    % Division durch .99, um nicht-perfektes Pumpen zu
                          % beruecksichtigen.

 tmin = min(t);
 tmax = max(t)/3;
 
 Data = data(t<=tmax & t>=tmin)';
 T    =    t(t<=tmax & t>=tmin)';

 startpar=[n,om,delt];
 fp=fmins('bsbfit_fehler',startpar);
 ['<n> = ' num2str(fp(1))]
 ['om  = ' num2str(fp(2)/(2*pi))]
 ['delt= ' num2str(fp(3)/(2*pi))]

if(1)
  T=t;
  Data=data;    
end

 Fit = bsbfit_fun(fp);
 plot(T*1e6,Data,'or','MarkerSize',2.5,'LineWidth',2.5)
 hold on;
 plot(T*1e6,Fit,'r')
 hold off;
