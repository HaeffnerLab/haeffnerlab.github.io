% 15.11.98 
% berechnet die Anregungswahrscheinlichkeit auf dem Traeger als 
% Funktion der Zeit fuer einen thermischen Zustand.
% Es wird mit linearisierten omega(n,n) gerechnet und die Funktion p~(t)
% verwendet
% vgl. 15.11.98 

function y=carrierapprox2(p)
global Data T

a=2*p(1)*T;
b=a*p(3)^2;
x=p(2)/(p(2)+1);
al=1/(p(2)+1);
l=log(p(2)/(p(2)+1));

Datafit=p(4)*.5*(1+al*(-l*cos(a)+b.*sin(a))./(l^2+b.^2)) + 1-p(4); 

plot(T,Data,'*',T,Datafit);

