% 23.4.00 
% Fouriertransformation der Rabiflopdaten vom 19.4
% Spiegeln des Datensatzes, so dass der symmetrisch um Null liegt
% und Abziehen des Mittelwertes

clear;clf;
global T Data 

load ../../../daten/00/000419/qf2317t;
load ../../../daten/00/000419/qf2323t;
load ../../../daten/00/000419/qf2328t;
qf=[qf2317t;qf2323t;qf2328t];


t   = qf(:,1)-.15e-6;
data= (1-qf(:,3))/.99;    % Division durch .99, um nicht-perfektes Pumpen zu
                          % beruecksichtigen.

Data = [data(length(data):-1:1);data(2:1:length(data))];
Data = Data-mean(Data);
T    = [-t(length(data):-1:1)  ;t(2:1:length(data))];

fy=fftpow(T',Data');
 
plot(fy(1,:),fy(2,:))

