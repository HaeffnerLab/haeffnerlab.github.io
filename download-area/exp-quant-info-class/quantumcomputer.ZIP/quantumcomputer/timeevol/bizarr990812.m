% 14.8.99
% Bildet die Kurvenform der seltsamen Daten vom 12.8.99 nach unter 
% Annahme einer Gausschen Verteilung mit schwerpunkt ~210.
% berechnet die Kopplungsstaerken auf dem Traeger und 1. + 2. Seitenband fuer 
% verschiedene Werte von eta und n;
% eta   : Lamb-Dicke-Parameter
% n     : Phononzahl

% Rekursion -> Galindo/Pascual : QM 1 (Anhang ..) 

clf;
nmax=800;          % Verteilung wird bei nmax abgeschnitten

omnull=2*pi*495e3;
nbar=210;
eta=0.05;
x=eta^2;

%%%%%%%%%%%% Kopplungen %%%%%%%%%%%%%
% Fuer den Traeger :

l0(1:1:nmax+1)=0;
l0(1)=1;
l0(2)=1-x;

for m=1:1:nmax-1
  l0(m+2) = ((2*m+1-x)*l0(m+1)-m*l0(m))/(m+1);
end
omcarr=l0;
%figure(1)
%plot(abs(omcarr))
%hold on

% Fuer das Seitenband :

l1(1:1:nmax+1)=0;
l1(1)=1;
l1(2)=2-x;

for m=1:1:nmax-1
  l1(m+2) = (2-x/(m+1)) * l1(m+1) - l1(m);
end
omblau = l1 * eta ./sqrt(1:1:nmax+1);
%plot(abs(omblau))
%axis([0 length(omblau) 0 1])

% Fuer das 2.Seitenband :

l2(1:1:nmax+1)=0;
l2(1)=1;
l2(2)=3-x;

for m=1:1:nmax-1
  l2(m+2) = ((2*m+3-x)*l2(m+1)-(m+2)*l2(m))/(m+1);
end
nn=0:1:nmax;
omblau2 = l2 * eta^2 ./sqrt((nn+1).*(nn+2));
%plot(abs(omblau2))
%hold off

%%%%%%%%%%%%% Verteilung %%%%%%%%%%%%%%
N=nmax;
n=0:1:N;
%if (N<170)
%  pn = exp(-nbar)*nbar.^n./gamma(n+1);
%else
  pn = exp(-(n-nbar).^2/(2*nbar*40));
  pn=pn/sum(pn);
%end
%plot(n,pn,'.-')
%axis([0 length(omblau) 0 max(pn)])

%%%%%%%%%%%%% Zeitentwicklung %%%%%%%%%%%%%%

%figure(2)
% Seitenband
subplot(3,1,2);
dt = 0.0625e-6;      % Zeitintervall        % Zeitentwicklung
c=dt; 
om=omnull*omblau(1:1:N+1);
phi=-.25;

for tm  = 1:1:400;   % Zeitschritte
   pt = ((cos(c*om*tm+phi)).^2)*pn';
   p1(tm)=pt;         % Besetzungswahrscheinlichkeit 
   t1(tm)=tm*dt*1e6;         % Zeit
end


% 2.Seitenband
subplot(3,1,3)
om=omnull*omblau2(1:1:N+1);
for tm  = 1:1:400;   % Zeitschritte
   pt = ((cos(c*om*tm+phi)).^2)*pn';
   p2(tm)=pt;         % Besetzungswahrscheinlichkeit 
   t2(tm)=tm*dt*1e6;         % Zeit
end


% Traeger
subplot(3,1,1)
om=omnull*omcarr(1:1:N+1);
for tm  = 1:1:400;   % Zeitschritte
   pt = ((cos(c*om*tm+phi)).^2)*pn';
   p0(tm)=pt;         % Besetzungswahrscheinlichkeit 
   t0(tm)=tm*dt*1e6;         % Zeit
end


load ../../daten/99/990812/qf1540t
load ../../daten/99/990812/qf1614t
load ../../daten/99/990812/qf1742t
subplot(3,1,2)
plot(t1,p1,qf1540t(:,1)*1e6,qf1540t(:,3),'r')
axis([0 25 0 1])

subplot(3,2,1)
plot(t0,p0,qf1614t(:,1)*1e6,qf1614t(:,3),'r')
axis([0 5 0 1])

subplot(3,2,5)
plot(t2,p2,qf1742t(:,1)*1e6,qf1742t(:,3),'r')
axis([0 5 0 1])

subplot(3,2,2)
hold on
plot(abs(omcarr))
plot(abs(omblau))
plot(abs(omblau2))
axis([0 length(omblau) 0 1])
hold off

subplot(3,2,6)
plot(n,pn)
axis([0 length(omblau) 0 max(pn)])



