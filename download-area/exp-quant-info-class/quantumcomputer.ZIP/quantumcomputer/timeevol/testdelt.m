% 20.4.00 Zeitentwicklung auf dem blauen Seitenband
%  
% benoetigt die Funktion laguerre.m
%  
% eta  : Effektiver Lamb-Dicke-Parameter
% n    : Phononzahl
% DELT : Verstimmung

clear;

%load ../../../daten/00/000413/qf2238_2241
%load ../../../daten/00/000413/qf2318_2321

%load ../../../daten/00/000419/qf2317t
%load ../../../daten/00/000419/qf2323t
%load ../../../daten/00/000419/qf2328t
%qf=[qf2317t;qf2323t;qf2328t];

%load ../../../daten/00/000419/qf2050t
%qf=qf2050t;

load ../../../daten/00/000419/qf2053t
load ../../../daten/00/000419/qf2055t
load ../../../daten/00/000419/qf2057t
qf=[qf2053t;qf2055t;qf2057t];

%load ../../../daten/00/000419/qf2102t
%load ../../../daten/00/000419/qf2104t
%qf=[qf2102t;qf2104t];

%load ../../../daten/00/000419/qf2111t
%qf=qf2111t;

%load ../../../daten/00/000419/qf2125t
%qf=qf2125t;

%load ../../../daten/00/000419/qf2132t
%qf=qf2132t;

%load ../../../daten/00/000419/qf2141t
%qf=qf2141t;

%load ../../../daten/00/000419/qf2146t
%load ../../../daten/00/000419/qf2149t
%load ../../../daten/00/000419/qf2202t
%qf=[qf2202t;qf2146t];
%qf=qf2202t;

%load ../../../daten/00/000419/qf0535t
%load ../../../daten/00/000419/qf0537t
%load ../../../daten/00/000419/qf0539t
%qf=[qf0535t;qf0537t;qf0539t];

load ../../../daten/00/000419/qf0543t
qf=qf0543t;


nmax=100;          % Verteilung wird bei nmax abgeschnitten
omnull=2*pi*130e3;
nbar= 4;
eta=.051;
DELT=2*pi*2.5e3;

etaquad=eta^2;

for k=0:1:nmax;
   n(k+1)=k;
   om(k+1)=laguerre(k,1,etaquad)/sqrt(k+1)*eta;

 % om(k+1)=laguerre(k,2,etaquad)/sqrt(max(1,(k+1)*k))*etaquad;
end

om=exp(-etaquad)*om;

n   = 0:1:nmax;                        % thermischer Zustand bis n=nmax;
pn  = (nbar/(nbar+1)).^n/(nbar+1);
%plot(n,pn,'.-')
%title('Thermische Verteilung')

%pause;

dt = 1e-6;      % Zeitintervall        % Zeitentwicklung
c=omnull; 

for tm  = 1:1:300;   % Zeitschritte 
   T=dt*tm; 
%%%
f  =(omnull*om).^2./((omnull*om).^2+DELT^2);
xom=sqrt((omnull*om).^2+DELT.^2); 
ptd= (f.*((sin(xom*T)).^2))*pn';
   pt = ((sin(c*om*T)).^2)*pn';
   p(tm)=ptd;         % Besetzungswahrscheinlichkeit 
   t(tm)=tm;         % Zeit
end

%plot(t*dt*1e6,p)
%title('Besetungswahrscheinlichkeit')
xlabel('Zeit')

hold on
%plot(qf(:,1)*1e6-.15,1-qf(:,3),'or','MarkerSize',2.5,'LineWidth',2.5)
plot(qf(:,1)*1e6-.15,1-qf(:,3),'r')
axis([0,300,0,1])


