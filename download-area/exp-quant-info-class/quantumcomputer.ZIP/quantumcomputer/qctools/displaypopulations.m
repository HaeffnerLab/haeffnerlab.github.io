function [YR,PF]=displaypopulation(T,Y,elstates,hspace)
%DISPLAYPOPULATION   populations 
%   [YR,PF] = DISPLAYPOPULATION(T,Y,elstates,hspace) 

%if(hspace.densitymatrixformalism)
%   if(ndims(elstates)<3)    % the user wants only diagonal elements of the densitymatrix
%      elstates(1,:,:)=elstates;
%      elstates(2,:,:)=elstates;
%   end;
%end;
if(length(T)>1)
   	if(hspace.densitymatrixformalism)
      	YR=abs(Y);
	   	PF=YR(size(YR,1),:);
      else
      	YR=abs(Y).^2;
	   	PF=YR(size(YR,1),:);
   	end;   
      difelstates=size(elstates,1);
    	f=figure(1);
      clf
      for j0=1:difelstates
      	ax=subplot(difelstates,1,j0);
   		set(ax,'FontSize',13);
         if(j0~=difelstates)
            set(ax,'xtick',0);
         end;
         hold on;
         k=1;
         i0=1;
         temp=0;
         while(1)
            [ph,temp]=quantumnumbers(k,hspace);
            if(size(squeeze(elstates(1,:,:)),1)==1)
               ph=ph(1,:);
            end;
            if(sum(sum(temp))~=0)
               break; 
            end;
            if(hspace.visible(index(ph,squeeze(elstates(1,:,:)),hspace)))
   	         if(size(elstates,3)~=1 && hspace.densitymatrixformalism )
  	   	         %squeeze(elstates(j0,:,:))
     	   	      state(i0)=index(ph,squeeze(elstates(j0,:,:)),hspace);
               else               
                  index(ph,elstates(j0,:),hspace);
     					state(i0)=index(ph,elstates(j0,:),hspace);
               end;
           		s=sprintf('%s: %1.3f',statename(state(i0),hspace),PF(state(i0)));
            	leg(i0,1:length(s))=s;
               i0=i0+1;
            end;
            k=k+1;  
        	end;
      	plot(kron(ones(length(state),1),T)',YR(:,state));
         h=legend(leg);
         if(strcmp('5.1.0.421',version)==0)
            set(h,'FontSize',10);
         end;
      	ylabel('Population','FontSize',16-difelstates,'FontName','Timesnewroman')
   		axis([min(T), max(T), 0, 1]);
   	end;
	%	ax=subplot(3,1,3);
   %	set(ax,'FontSize',13);
%   	set(ax,'xtick',0);
   %	hold on;   
   %   states=[index(0,[2,1],hspace),...
    %       	  index(1,[2,1],hspace)];
	%	plot(T,YR(:,states(1)),'b');
	%	plot(T,YR(:,states(2)),'r--');
	%	h1=sprintf('%s: %1.3f',statename(states(1),hspace),PF(states(1)));
	%	h2=sprintf('%s: %1.3f',statename(states(2),hspace),PF(states(2)));
	%	h=legend(h1,h2,0);
   %	ylabel('Population','FontSize',14,'FontName','Timesnewroman')
   %	axis([min(T), max(T), 0, 1])
   	
   
   	xlabel('Time (\mus)','FontSize',18,'FontName','Timesnewroman');
      uiresume(f);
end;      
      
