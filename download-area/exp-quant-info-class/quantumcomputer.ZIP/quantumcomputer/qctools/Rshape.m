% -*- mode: MATLAB -*-
% Time-stamp: "2006-01-10 14:40:50 c704271"

%  file      : Rshape.m
%  email     : philipp DOT emacs DOT schindler AT uibk DOT ac DOT at
%            : remove the "One And Only Editor"
%  copyright : (c) 2005 Philipp Schindler
%  rcs       : $Id$


function [pulses,endtime] = Rshape(theta,phi,ion,transition,fp,time,shape)

%if(nargin<7)
%   time=fp;
%   fp=transition;
%   transition=mode;
%   mode=1;
%end;

%pulse = struct('targetion',zeros(fp.hspace.levels,fp.hspace.nuions),'omc',0,'detuning',0,'phase',1,'starttime',0,'endtime',0); 
%pulse.starttime = time;
%endtime = time+theta*fp.piover2time(mode,ion);
%pulse.endtime = endtime;
%pulse.omc = fp.sbcarrierrabi;
%pulse.detuning = fp.detuning(transition)-(fp.omz(mode)+fp.includelsdetuning*fp.lightshift(mode));
%pulse.phase = (phi-0.5);   % to match Ike's and everybody elses convention
%pulse.targetion = zeros(fp.hspace.levels,fp.hspace.nuions);
%pulse.targetion(transition,:) = fp.addressingerror(ion,:);

  fp0=fp;
  omega=fp.sbcarrierrabi;
  step_time=shape.time/shape.steps;
  time1=2*theta/omega;
  up_time=time1-shape.time;
  mode=1;
 % theta1=shape.time/fp.piover2time(mode,ion);
  theta01=0.45;
  endtime=time;
 % theta0=theta-theta01;
  fp.piover2time(1);
  theta02=(shape.time*1e-6)/fp.piover2time(mode);
  theta0=theta-theta02;
  theta0*fp.piover2time(mode);
  fp.piover2time;
  frequencyscale=1;

  for (i0=1:shape.steps)
    x=i0/(shape.steps+1);
    black=1.0/2.0*(0.84-cos(x*pi)+0.16*cos(2*x*pi));
    fp.sbcarrierrabi=omega*black;
    fp.lightshift=-fp0.sbcarrierrabi^2./fp.omz * frequencyscale^2/2;
    fp.piover2time=fp.piover2time/black;
    theta1=step_time/fp.piover2time(mode)/1e6;
    time=endtime;
    [pulse,endtime]=Rblue(theta1,phi,ion,transition,fp,time+0.01e-6);
    pulses(i0)=pulse;
  end;
  fp=fp0;
  fp.sbcarrierrabi=omega;
  time=endtime;
  [pulse1,endtime]=Rblue(theta0,phi,ion,transition,fp,time+0.01e-6);
  pulses=[pulses,pulse1];

  for (i0=1:shape.steps)
    x=i0/(shape.steps+1);
    black=1-1.0/2.0*(0.84-cos(x*pi)+0.16*cos(2*x*pi));
    fp.sbcarrierrabi=omega*black;
    fp.sbcarrierrabi=omega*black;
    fp.lightshift=-fp0.sbcarrierrabi^2./fp.omz * frequencyscale^2/2;
    fp.piover2time=fp.piover2time/black;
    theta1=step_time/fp.piover2time(mode)/1e6;
    time=endtime;
    [pulse,endtime]=Rblue(theta1,phi,ion,transition,fp,time+0.01e-6);
    pulses1(i0)=pulse;
  end;
  pulses=[pulses,pulses1];



