%SIMULATETEMPLATE   template for simulations.
%   simulates the population evolution with experimental imperfections
%   Date:   03-Sep-02
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

%   type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*160e3;
%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

%****************** Pulse definition  ***********************%
%  Rcarrier(theta,phi,ion,transition,fp,time)
%     Rblue(theta,phi,ion,transition,fp,time)

p = p + 1;[pulse(p),time] = Rcarrier(0.5,0,1,1,fxpa,time+14*delayunit); 
p = p + 1;[pulse(p),time] = Rcarrier(0.5,1,1,1,fxpa,time+(200)*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0; 1],hspace);
endpopulations(T,Y,hspace)
tracedpopulations(T,Y,hspace,1);
hold on;
%*****************************************************************************%