function [PF,PH]=endpopulations(T,Y,hspace)
%ENDPOPULATIONS   print populations
%   [PF,PH] = ENDPOPULATIONS(T,Y,hspace)
   if(exist('hspace')==0)
   	global hspace;
   end;

   if(hspace.densitymatrixformalism)
   	PH=Y(size(Y,1),:)./abs(Y(size(Y,1),:));
      YR=abs(Y);
   	PF=YR(size(YR,1),:);
   else
	YR=abs(Y).^2;
   	PF=YR(size(YR,1),:);
   	PH=Y(size(Y,1),:)./abs(Y(size(Y,1),:));
  	end;

   %%%%%%%% Darstellung : So ...

   if(sum(hspace.visible==0))
	hspace.visible=ones(1,hspace.dimensions);
   end;

   temp=proj(diag(1:hspace.dimensions));
   states=temp*ones(length(temp),1);
   t=sprintf('Final populations after %3.0f microseconds:\n',max(T));
   s(1,1:length(t))=t;
   for j=1:length(states)
      t=sprintf('%s: %1.4f, %2.3f + %1.3fi',statename(states(j),hspace),PF(states(j)),real(PH(states(j))),imag(PH(states(j))));
      s(j+1,1:length(t))=t;
   end;
   s


