function Y=realizelaserinteractiondensmat(T,X,flag,pulsemap,ham,Lrelax,timescale,tfinal)

p=1;
temp=0;
while(pulsemap(round(T*timescale+1),p)~=-1)
	HT=squeeze(ham(pulsemap(round(T*timescale+1),p),:,:));
   de=diag(HT);
   b=exp(-T*de);
   HT=HT-diag(de);
   Hint=-1*(b*b').*triu(HT,1);
   Hint=Hint-(Hint');
   temp=temp+Hint;
   p=p+1;
end;

Y=(temp-Lrelax)*X;

message(4,sprintf('ode45: %2.0f %%',100*T/tfinal));
