% -*- mode: MATLAB -*-
% Time-stamp: "2006-02-24 14:40:50 c704270"

%  file      : Rbluecomp.m
%  email     : kihwan DOT kim AT uibk DOT ac DOT at
%  This sequence is for Rblue sideband pulse with compensation laser. In
%  this sequence, the ODE solve is not necessary.

function [pulses,endtime] = Rbluecomp(theta,phi,ion,transition,fp,fpcomp,time)

  mode=1;
  starttime=time;
  endtime = time+theta*fp.piover2time(mode,ion);
  step_time=0.97e-6;
  numberofstep=(endtime-starttime)/step_time;
  theta1=step_time/fp.piover2time(mode);  
   
  for (p=0:2:numberofstep*2)
    timc=time;
    p=p+1;[pulses(p),time]=Rblue(theta1,phi,ion,mode,transition,fp,time);
    p=p+1;[pulses(p),time]=Rred(theta1,phi,ion,mode,transition,fpcomp,timc);
  end;