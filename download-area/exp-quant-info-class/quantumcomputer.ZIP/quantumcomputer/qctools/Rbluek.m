function [pulsek,endtime]=Rblue(theta,phi,ion,mode,transition,fp,time);

;%fp = struct('carrierrabi',omcre,'omz',omz,'lightshift',dlshift,'detuning',det,'addressingerror',addreerr,'piover2time',pi2,'includelsdetuning',0,'hspace',hspace);

if(nargin<7)
   time=fp;
   fp=transition;
   transition=mode;
   mode=1;
end;
   
pulsek = struct('targetion',zeros(fp.hspace.levels,fp.hspace.nuions),'omc',0,'detuning',0,'phase',1,'starttime',0,'endtime',0); 

pulsek.starttime = time;
endtime = time+theta*fp.piover2time(mode,ion);
pulsek.endtime = endtime;
pulsek.omc = fp.sbcarrierrabi;
pulsek.detuning = fp.detuning(transition)+((fp.omz(mode))+fp.includelsdetuning*fp.lightshift(mode));
pulsek.phase = (phi-0.5);   % to match Ike's and everybody elses convention
pulsek.targetion = zeros(fp.hspace.levels,fp.hspace.nuions);
pulsek.targetion(transition,:) = fp.addressingerror(ion,:);
