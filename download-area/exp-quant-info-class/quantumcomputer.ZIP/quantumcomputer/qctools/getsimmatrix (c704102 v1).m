function U=getsimmatrix(file)

% GETSIMMATRIX  the matrix of a simulation.
%   GETSIMMATRIX(file)
%   file is the simulation script.

%   File:   getsimmatrix.m
%   Date:   11-Mar-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>



feval(file)
parameters.points=1;
for(k=1:hspace.dimensions)
   if(hspace.visible(k)~=0)
      parameters.y0=zeros(1,hspace.dimensions);
      parameters.y0(k)=1;
      [T,Y]=simulateevolution(pulse,parameters);
      U(:,k)=Y(:,size(Y,2));
   end;
end;
closemessagewindow;