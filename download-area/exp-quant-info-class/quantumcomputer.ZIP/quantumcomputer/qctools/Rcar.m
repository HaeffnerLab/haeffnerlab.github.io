function [pulse,endtime]=Rcar(theta,phi,ion,transition,fp,time)

pulse = struct('targetion',zeros(fp.hspace.levels,fp.hspace.nuions),'omc',0,'detuning',0,'phase',1,'starttime',0,'endtime',0); 

pulse.starttime = time; 
endtime = time+theta*pi/fp.carrierrabi;
pulse.endtime = endtime;
pulse.omc = fp.carrierrabi;
pulse.detuning = fp.detuning(transition);
pulse.phase = phi;
pulse.targetion = zeros(fp.hspace.levels,fp.hspace.nuions);
pulse.targetion(transition,:) = fp.addressingerror(ion,:);
