function df = detfrequenzfluct(ampp,tfinal,steps);

step = tfinal/steps;
t=[0:step:tfinal+2*step];

df = [t',(t'-mean(t))/(2*mean(t))]';		% a linear ramp

df = [t',sin(pi*t'/tfinal*2)]';        % two oscillations

df(2,:) = df(2,:)-mean(df(2,:));
df(2,:) = df(2,:)/(max(df(2,:))-min(df(2,:)))*ampp;

