function Y=realizepulses(pulse,parameters,deterr);

%REALIZEPULSES   heart of the computation process.
%
%   Y = realizepulses(pulse,parameters) computes the population evolution depending 
%   on parameters.odesolve either according to exp(-iHt) or via an ode45 solver .
%   Hartmut H�ffner, Innsbruck 2001

densmat=parameters.hspace.densitymatrixformalism;

if(densmat)
   Lrelax = parameters.frequencyscale*calcLrelax(parameters.decoherences,parameters.hspace);
end;

pulses=length(pulse);
T=parameters.T;
dec=detfrequenzfluct(parameters.decoherences.det_frefluct(1),T(length(T)),parameters.decoherences.det_frefluct(2));
realpcounter=1;
for p=1:pulses
   time = pulse(p).starttime;
	realpulse(realpcounter)=pulse(p);
   while 1
      realpulse(realpcounter).detuning = realpulse(realpcounter).detuning + dec(2,finddetfrequ(time,dec)) + deterr;
      endintervall = dec(1,finddetfrequ(time,dec)+1);
      if endintervall>pulse(p).endtime   % no change in frequency till end of the pulse
      	realpcounter=realpcounter+1;
         break;
      end;
      realpulse(realpcounter).endtime = endintervall;
      realpcounter=realpcounter+1;
      time=endintervall;
   	realpulse(realpcounter)=pulse(p);
      realpulse(realpcounter).starttime = endintervall;    
   end;
end;
realpulses = length(realpulse);

if(parameters.odesolve==1)
   timescale=1e8*parameters.frequencyscale;
   if(min(T)<0)
      fprintf('Smallest allowed time is zero!!!\n');
   end;
   message(4,'Wait ...')
   pulsemap=-ones((round(max(T)*timescale*1.01)),realpulses+1);
   for p=1:realpulses
      k=1;
      while(pulsemap(round(realpulse(p).starttime*timescale+1),k)~=-1)
         k=k+1;
      end;
      if(max(pulsemap(round(realpulse(p).starttime*timescale+1):round(realpulse(p).endtime*timescale+1),k))~=-1)
         fprintf('Cannot implement these pulses!!!\n');
      end;
      pulsemap(round(realpulse(p).starttime*timescale+1):round(realpulse(p).endtime*timescale+1),k)=p;
      if(densmat)
         [temp,lnu]=Hamiltonian(realpulse(p).omc*(1+parameters.intensitymismatch/2),realpulse(p).targetion,realpulse(p).phase,realpulse(p).detuning,parameters.omegaz,parameters.eta,parameters.hspace);
         lio(p,:,:) = Liouville(temp,lnu);
   	else 
      	[ham(p,:,:),lnu]=Hamiltonian(realpulse(p).omc*(1+parameters.intensitymismatch/2),realpulse(p).targetion,realpulse(p).phase,realpulse(p).detuning,parameters.omegaz,parameters.eta,parameters.hspace);
        %a=squeeze(ham(p,:,:))
        %sign(squeeze(ham(p,:,:)))
      end;   
   end;
   options = odeset('AbsTol',1/timescale,'RelTol',1/timescale,'MaxStep',1/timescale,'InitialStep',1/timescale);  
   message(4,'ode15s solves ...')
   if(densmat)
   	[parameters.T,Y] = ode15s('realizelaserinteractiondensmat',T,parameters.y0,options,pulsemap,lio,Lrelax,timescale,max(T)); 
   else
   	[parameters.T,Y] = ode15s('realizelaserinteraction',T,parameters.y0,options,pulsemap,ham,timescale,max(T)); 
   end;   
                         %[T,Y]=ode45('l22ionfuncnot',tspan,y0,options,om1,om2,omc,d,omz,eta,piover4time,address);  
 else
   [HT,lnu] = Hamiltonian(0,zeros(3,parameters.hspace.nuions),1,0,parameters.omegaz,parameters.eta,parameters.hspace);   
	if(densmat)
      [HT,lnu] = Liouville(HT,lnu);
      %Lrelax=0
      HT = (HT + Lrelax);
      jot=-1; 
   else
      jot=i;     % in case of the Schr�dinger equation we are looking for exp(i*H*t)
   end; 
   nointeraction = diag(HT);  
   
	m = 1;
   doublerotatingframe=(-nointeraction);    
   % this is tricky! Yes, indeed! 
   %   It is there to get the phases for the multi-phonon states to the conventions of the comunity.
   %   Problem: Causes densitymatrix formalism to work wrong. 
   %   If .
   %   
	ytemp = parameters.y0;
	lasttime = 0;

	for p=1:realpulses
   	while(1)
      	time = min(T(m),realpulse(p).starttime);
         ytemp=ytemp*diag(exp(jot*(time-lasttime)*nointeraction));
         Y(m,1:size(ytemp,2),1:size(ytemp,1)) = ytemp;
      	lasttime = time;
   		if(T(m)>=realpulse(p).starttime) 
         	break
      	else 
      		message(4,sprintf('%2.0f %% of points',100*m/length(T)));
         	m=m+1;
      	end;
   	end;
  		[HT,lnBT]=Hamiltonian(realpulse(p).omc*(1+parameters.intensitymismatch/2),realpulse(p).targetion,realpulse(p).phase,realpulse(p).detuning,parameters.omegaz,parameters.eta,parameters.hspace);
        if(densmat)  
      	[HT,lnBT] = Liouville(HT,lnBT);
         HT = (HT + Lrelax);
      end;
      [U,H]=eig(HT);
      Uinv=inv(U);
      hv=diag(H);
      
%      Uinv=eye(size(U));
%      U=Uinv;
%      hv=HT;
      
   	message(3,sprintf('Real pulse %d',p));
      ytemp=ytemp*diag(exp(i*realpulse(p).starttime*lnBT'))*U;  
   	while(1)
      	time = min(realpulse(p).endtime,T(m));
      	time = max(time,0);
         
%         ytemp = ytemp*expm(jot*(time-lasttime)*hv);
         
         ytemp = ytemp*diag(exp(jot*(time-lasttime)*hv));
   		lasttime = time;
      	Y(m,1:size(ytemp,2),1:size(ytemp,1)) = ytemp*Uinv*diag(exp(-i*(time)*lnBT'+i*imag(jot*time*doublerotatingframe)));
      	if(T(m)>=realpulse(p).endtime) 
         	break
      	else
         	if(mod(m,10)==0)
      			message(4,sprintf('%2.0f %% of points',100*m/length(T)));
            end;   
         	m=m+1;
      	end;
   	end;
   	ytemp=ytemp*Uinv*diag(exp(-i*(time)*lnBT'));
	end;

	while(m<=length(T))   % time evolution till the end ...
 	%  lasttime
  	%  T(m)
        Y(m,1:size(ytemp,2),1:size(ytemp,1)) = ytemp*diag(exp(jot*(T(m)-lasttime)*nointeraction+i*imag(jot*T(m)*doublerotatingframe)));
        message(4,sprintf('%2.0f %% of points',100*m/length(T)));
       	m=m+1;
	end;
	message(4,' ');
	message(3,' ');
end;