function setdecsubspace(p)

%SETDECSUBSPACE
% Makes the decoherence free subspace visible only.
global hspace
for(k=1:hspace.dimensions)
    [ph,el]=quantumnumbers(k);
    if(sum(ph)==0 & sum(el)==hspace.nuions/2 & (p | (el(1)~=el(2))))
        hspace.visible(k)= 1;
    else
        hspace.visible(k)=0;
    end;
end;