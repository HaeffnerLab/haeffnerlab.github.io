function [Hint,lnU]=Hamiltonian(omrabi,targetion,phase,detuning,trapfrequ,eta,hspace);
%HAMILTONIAN   Hamiltonian for an ion trap quantumcomputer
%   [Hint,lnU] = HAMILTONIAN(omrabi,targetion,phase,d,trapfrequ,eta,hspace);
%   Calculates the Hamiltonian for ions strings addressed by laserbeams.
%   Only a single laser frequency is allowed.
%   lnU is the -i times the ln of the basis trafo (as a vector, which contains the diagonal elements), which connects the Hamilton from no laser detuning to the one with detuning
%
%   omrabi: Rabi frequency
%   targetion: array of ions addressed (1 corresponds to the Rabi frequency omrabi)
%     [  ion1: D->S    ion2: D->S;
%        ion1: D->E    ion2: D->E;
%        ion1: S->E    ion2: S->E;	]
%   phase: Phase of pulse (i = pi/2)
%   detuning: Laser detuning
%   trapfrequ: trap frequency
%   eta: Lamb-Dicke parameter
%   hspace: Hilbert space
%
% Hartmut H�fner, Innsbruck 2001 <Hartmut.Haeffner@uibk.ac.at>

phase=exp(i*pi*phase);

if(hspace.densitymatrixformalism)
	hspace.densitymatrixformalism=0;   % we want the quantumnumbers for a Hamiltonian when we call quantumnumbers!
   	dimensions=sqrt(hspace.dimensions);
else
   dimensions=hspace.dimensions;
end;
for k=2:dimensions  							  % k labels the inital state
   [p1,s1]=quantumnumbers(k,hspace);
   for m=1:k   														  % m labels the final state
      element=0;
      [p2,s2]=quantumnumbers(m,hspace);
      ds=(s1-s2);
      ma=find(ds);
      if(length(ma)==1)        % electronic states different for exactly one ion
         [transtype,ion]=max(abs(ds));
         if s1(ion)+s2(ion)==3   % transition from S ->E!!!
             transtype=3;
         end;
         if(sum(abs(p1-p2)')==0)           % is a carrier transition
            element=prod((1-p1*eta(ion)^2))*targetion(transtype,ion);
         elseif(sum(abs(p1-p2)')==1)    % red or blue sideband
            mode=abs(p1-p2)*[1:length(p1)]';
            othermodes=find(abs(p1-p2));
   	    element=i*sqrt(max(p1(mode),p2(mode)))*eta(mode,ion)*prod((1-p1*eta(othermodes,ion)^2))*sign(ds(ion))*targetion(transtype,ion);
         end;
      end;
      Hint(k,m)=element*phase*omrabi/2;
   end;
end;
Hint=Hint+Hint';
for k=1:dimensions  							  % diagonal elements
   [p1,s1]=quantumnumbers(k,hspace);
   Hint(k,k)=p1*trapfrequ'+detuning*sum(min(s1,1));
   lnU(k)=+(detuning)*sum(min(s1,1));
end;
