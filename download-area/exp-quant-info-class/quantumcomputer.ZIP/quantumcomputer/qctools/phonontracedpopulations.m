function [EY,str]=phonontracedpopulations(T,Y,elstates,hspace,displ)
%PHONONTRACEDPOPULATIONS   traces over the phonon degree of freedom
%   [EY,statenames] = PHONONTRACEDPOPULATIONS(T,Y,elstates,hspace,{display})
%
%   Set display to 1 to plot it.

if(~exist('displ'))
   displ=0;
end;

if(length(T)>0)
   	if(hspace.densitymatrixformalism)
      	YR=abs(Y);
      else
      	YR=abs(Y).^2;
   	end;
%   	PF=YR(size(YR,1),:);
%   	PH=angle(Y(size(Y,1),:));

		for j=1:size(elstates,1)
         k=index(zeros(1,length(hspace.maxphonons)),elstates(j,:),hspace);
         if(hspace.densitymatrixformalism)
            for l=0:sum(hspace.maxphonons)
               qn(l+1)=index([l,l],elstates(j,:),hspace);
            end;
            EY(j,:)=sum(YR(:,qn),2)';
         else
	 	if(length(T)==1)
			EY(j,:)=sum(YR(k:k+sum(hspace.maxphonons)),2)';
		else
			EY(j,:)=sum(YR(:,k:k+sum(hspace.maxphonons)),2)';
	 	end;
	 end;
         s=statename(k,hspace);
         if(hspace.densitymatrixformalism)
            str(j,:)=['|',s(3:3+hspace.nuions-1),'><',s(6+hspace.nuions:6+2*hspace.nuions)];
      	else
            str(j,:)=['|',s(3:length(s))];
         end;
      end;      
      EY=EY';
      TI=repmat(T,size(elstates,1),1)';
      if displ
	      f=figure(3);
   	   h2='';
      	h3='';
   		clf
      	hold on;     
      	p=plot(TI,EY);
      	legend(str);
   		ylabel('D-state population','FontSize',14,'FontName','Timesnewroman')
      	axis([min(T), max(T), 0, 1])
     		xlabel('Time (\mus)','FontSize',18,'FontName','Timesnewroman');
         uiresume(f);
      end;
end;
