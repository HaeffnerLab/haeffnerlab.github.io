% -*- mode: MATLAB -*-
% Time-stamp: "2006-02-24 14:40:50 c704270"

%  file      : Rbluecomp.m
%  email     : kihwan DOT kim AT uibk DOT ac DOT at
%  This sequence is for Rblue sideband pulse with compensation laser. In
%  this sequence, the ODE solve is not necessary.

function [pulses,endtime] = Rbluecomp(theta,phi,ion,transition,fp,fpcomp,time)

  fp0=fp;
  fpcomp0=fpcomp;
  omega=fp.sbcarrierrabi;
  omegacomp=fpcomp.sbcarrierrabi;
  mode=1;
  finaltime = time+theta*fp.piover2time(mode,ion);
  step_time=2e-6;
  numberofstep=finaltime/step_time;
%  time1=2*theta/omega;

%  pulse.starttime = time;
  endtime=time;

%  pulse.endtime = endtime;
%  fp.piover2time(1);
%  theta02=(shape.time*1e-6)/fp.piover2time(mode);
%  theta0=theta-theta02;
  frequencyscale=1;

  for (i0=1:2:numberofstep*2)
%    x=(i0+1)/2/(shape.steps+1);
%    black=1.0/2.0*(0.84-cos(x*pi)+0.16*cos(2*x*pi));
%    fp.sbcarrierrabi=omega*black;
%    fpcomp.sbcarrierrabi=omegacomp*black;
    fp.lightshift=-fp0.sbcarrierrabi^2./fp.omz * frequencyscale^2/2;
    fpcomp.lightshift=fpcomp0.sbcarrierrabi^2./(fpcomp.omz) * frequencyscale^2/2;
%    fp.piover2time=fp.piover2time/black;
%    fpcomp.piover2time=fpcomp.piover2time/black;
    theta1=step_time/fp.piover2time(mode);
    time=endtime;
%    timecomp=endtime;
    [pulses(i0),endtime]=Rblue(theta1,phi,ion,transition,fp,time);
    [pulses(i0+1),endtime]=Rred(theta1,phi,ion,transition,fpcomp,time);
  end;
 
  % i0=i0+2;  
 % fp=fp0;
 % fpcomp=fpcomp0;
 % fp.sbcarrierrabi=omega;
 % fpcomp.sbcarrierrabi=omegacomp;
 % time=endtime;
 % timecomp=endtime;
 % [pulses(i0),endtime]=Rblue(theta0,phi,ion,transition,fp,time+0.01e-6);
 % [pulses(i0+1),endtime]=Rred(theta0,phi,ion,transition,fpcomp,timecomp+0.01e-6);

%  for (i0=1:2:shape.steps*2-1)
%    x=(i0+1)/2/(shape.steps+1);
%    black=1-1.0/2.0*(0.84-cos(x*pi)+0.16*cos(2*x*pi));
%    fp.sbcarrierrabi=omega*black;
%    fpcomp.sbcarrierrabi=omegacomp*black;
%    fp.lightshift=-fp0.sbcarrierrabi^2./fp.omz * frequencyscale^2/2;
%    fpcomp.lightshift=fpcomp0.sbcarrierrabi^2./(fpcomp.omz) * frequencyscale^2/2;
%    fp.piover2time=fp.piover2time/black;
%    fpcomp.piover2time=fpcomp.piover2time/black;
%    theta1=step_time/fp.piover2time(mode)/1e6;
%    time=endtime;
%    timecomp=endtime;
%    [pulses1(i0),endtime]=Rblue(theta1,phi,ion,transition,fp,time+0.01e-6);
%    [pulses1(i0+1),endtime]=Rred(theta1,phi,ion,transition,fpcomp,timecomp+0.01e-6);
%  end;
% pulses=[pulses,pulses1];



