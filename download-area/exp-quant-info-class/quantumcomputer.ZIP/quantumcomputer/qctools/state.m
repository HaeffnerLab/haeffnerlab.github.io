function vec = state(phonons,elstate,hspace);
% STATE returns the state-vector
%   [statevec] = STATE(phonons,elstate,hspace);
%


if(exist('hspace')==0)
   global hspace;
end;


vec=[zeros(1,hspace.dimensions)]';
vec(index(phonons,elstate,hspace))=1;