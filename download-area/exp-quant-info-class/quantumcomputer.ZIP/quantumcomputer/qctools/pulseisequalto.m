function s=pulseisequalto(pulse,p);
s=0;
if p>1 
   for k=1:p-1
		if(pulse(k).omc == pulse(p).omc & pulse(k).detuning == pulse(p).detuning & pulse(k).phase == pulse(p).phase & pulse(k).targetion == pulse(p).targetion)
         s=k;
         break;
      end;
   end;
end;