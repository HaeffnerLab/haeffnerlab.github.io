

% STARTOPTI  the matrix of a simulation.

%   File:   genoptx.m
%   Date:   07-Jul-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>
global noofpulses;
global resolution;

noofpulses=1;
resolution=2*2.1;

global messagehandle;
messagehandle=-1;


omz=2*pi*1714000;
phaselist=0.9*sin(0.5*[1:noofpulses-1]*resolution*10^-6*omz);
omclist=sqrt(1+0.9*cos(0.5*[1:noofpulses-1]*resolution*10^-6*omz));
omcbas=1.01;

list=[ 1 1  1  1 ];   
clear variableOps;
for(k=1:length(list))
   variableOps(k,:)=[4 0 2];
end;
variableOps(1,:)=[4 0 5];
initPop=[list;  ...
   (1.5-rand(1,length(list))); (1.025-0.09*rand(1,length(list)));   (1.025-0.095*rand(1,length(list))); (1.025-0.09*rand(1,length(list)));   (1.025-0.095*rand(1,length(list))); (1.025-0.09*rand(1,length(list)));   (1.025-0.095*rand(1,length(list))); (1.025-0.09*rand(1,length(list)));   (1.5-rand(1,length(list))); (1.025-0.09*rand(1,length(list)));   (1.025-0.095*rand(1,length(list))); (1.025-0.09*rand(1,length(list)));   (1.025-0.095*rand(1,length(list))); (1.025-0.09*rand(1,length(list)));   (1.025-0.095*rand(1,length(list))); (1.025-0.09*rand(1,length(list)));  ];
size(initPop)
%[x,endPop,bPop,traceInfo]=ga(variableOps,'optisim4',0,startPop,[1e-6 1],'maxGenTerm',10000);
[x,endPop,bPop,traceInfo]=multiga(variableOps,'optisim5',0,initPop,[1e-6 0],'maxGenTerm',10000,...
   'normGeomSelect',[0.08]);


save genopt5