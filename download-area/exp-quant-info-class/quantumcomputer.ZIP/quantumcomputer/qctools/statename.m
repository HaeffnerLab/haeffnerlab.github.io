function s=statename(ind,hspace);
%STATENAME   state name
%   s = statename(ind,hspace);
%   returns the name of the state coresponding to the index ind in s
%   hspace defines the hilbert-space
%   states is a vector [... ion_2 ion_1 ] where the numbers in ion_x stand for:  0 (D)	1 (S) 	2 (D2)


if(exist('hspace')==0)
   global hspace;
end;
ind=ind-1;

if(hspace.densitymatrixformalism==0)
   indtemp=ind;
   for(k=1:length(hspace.maxphonons))
      phonon(k)=mod(indtemp,hspace.maxphonons(k)+1);
      indtemp=fix(indtemp/(hspace.maxphonons(k)+1));
   end;
   if(hspace.maxphonons>0)
      s=sprintf(',%d',phonon);
   else
      s='';
   end;
   t='';
	for k=1:hspace.nuions
  	 	temp=mod(fix(fix(ind/prod(hspace.maxphonons+1))/((hspace.levels)^(hspace.nuions-k))),hspace.levels);
	if(temp==0)
			t=sprintf('%s%s',t,'D');
   	elseif(temp==1)
			t=sprintf('%s%s',t,'S');
   	elseif(temp==2)
			t=sprintf('%s%s',t,'E');
   	else
			t=sprintf('%s%s',t,' unknown ');
   	end
	end;
	s=sprintf('|%s%s>',t,s);
else
   dime = prod(hspace.maxphonons+1)*hspace.levels^hspace.nuions;
   	ind1 = fix(ind / dime);
	ind2 = mod(ind,dime);

   indtemp=ind1;
   for(k=1:length(hspace.maxphonons))
      phonon(k)=mod(indtemp,hspace.maxphonons(k)+1);
      indtemp=fix(indtemp/(hspace.maxphonons(k)+1));
   end;

   if(hspace.maxphonons>0)
      s=sprintf(',%d',phonon);
   else
      s='';
   end;
   t='';
   for k=1:hspace.nuions
   	temp=mod(fix(fix(ind1/prod(hspace.maxphonons+1))/((hspace.levels)^(hspace.nuions-k))),hspace.levels);
   	if(temp==0)
			t=sprintf('%s%s',t,'D');
   	elseif(temp==1)
			t=sprintf('%s%s',t,'S');
   	elseif(temp==2)
			t=sprintf('%s%s',t,'E');
   	else
			t=sprintf('%s%s',t,'unknown');
   	end
	end;

   indtemp=ind2;
   for(k=1:length(hspace.maxphonons))
      phonon(k)=mod(indtemp,hspace.maxphonons(k)+1);
      indtemp=fix(indtemp/(hspace.maxphonons(k)+1));
   end;
   if(hspace.maxphonons>0)
      u=sprintf(',%d',phonon);
   else
      u='';
   end;
   v='';
	for k=1:hspace.nuions
   	temp=mod(fix(fix(ind2/prod(hspace.maxphonons+1))/((hspace.levels)^(hspace.nuions-k))),hspace.levels);
   	if(temp==0)
			v=sprintf('%s%s',v,'D');
   	elseif(temp==1)
			v=sprintf('%s%s',v,'S');
   	elseif(temp==2)
			v=sprintf('%s%s',v,'E');
   	else
			v=sprintf('%s%s',v,'unknown');
   	end
	end;
	s=sprintf('|%s%s><%s%s|',t,s,v,u);
end;
