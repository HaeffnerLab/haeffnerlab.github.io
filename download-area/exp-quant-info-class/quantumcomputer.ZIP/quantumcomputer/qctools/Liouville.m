function [L,BT]=Liouville(H,HBT)
%LIOUVILLE   Liouville operator
%   [L,BT] = LIOUVILLE(H,{HBT})
%
%    Liouville - Operator	L  for x-niveau-dynamics
%    von J�rgen Eschner am 15.2.02 'geklaut'
%
%    H is the Hamiltonian
%    HBT is the corresponding basis trafo as a vector
%
%    The Liouville operator L and the basis trafo for the density matrix BT (as a vector since it is diagonal) are returned.


% Konstruktion des Liouville-Ops. aus dem Hamilton-Op.
  z=length(H);                    % Zahl der Niveaus
  E=eye(z);               % Einheitsmatrix
  ii=(1:z)'*ones(1,z);   
  i1=reshape(ii',1,z^2);  % i1 = (1 1 2 2)
  i2=reshape(ii,1,z^2);   % i2 = (1 2 1 2)
  clear ii

  Hc=H'.';               % adjungiert und transponiert = cc

  L=-i*(H(i1,i1).*E(i2,i2)-Hc(i2,i2).*E(i1,i1));
   
  if(exist('HBT'))
     BT = -(HBT(i2)-HBT(i1));   % not %HBT(i1).*HBT(i2)'.' because this is ln(UU')
  else
     BT=-1;
  end;
