%SIMULATE   simulation.
%   SIMULATE simulates the population evolution with experimental imperfections
%   requires the scripts in qctools
%   type <edit simulate> to specify the parameters directly in the script
%
%   Date:   01-Dec-02
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at
%
% 

clear T;
clear Y;
clear pulse;

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=0;
parameters.hspace.nuions=2;
parameters.hspace.maxphonons=2;
parameters.omegacarrier=2*pi*23e3;
parameters.sbomegacarrier=2*pi*450.e3;
parameters.omegaz=2*pi*2100000;

%parameters.odesolve=1;

%*****************************************************************************%
parameters=recalculateparameters(parameters);
initializepulseparameters;


%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fp,time)
%  Rblue(theta,phi,ion,transition,fp,time)

%p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+0*delayunit);
p = p + 1;[pulse(p),time] = Rblue(1,1,1,1,fxpa,time+15*delayunit); 
%p = p + 1;[pulse(p),time] = Rblue(2,1,0,1,fxpa,time+(0)*delayunit); 
%p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,time+(200)*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0 0; 1 0 ;],hspace);
setstatevisibility(1,hspace);
%endpopulations(T,Y,hspace);
%YTP=tracedpopulations(T,Y,hspace,1);
%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;