% Basic commands for ion trap quantum computing.
%
%Some commands: 
%   definehspace        - defines the Hilbert space.
%   setstatevisibility  - chooses which states are displayed by various routines. 
%   dispmat             - matrix (or the basis itself) in its basis.
%   dispabsmat          - absolute values of a matrix.
%   densmat             - density matrix formalism on or off.
%
%Find your way through the Hilbert space:
%   statename      - statename to an index.
%   qantumnumbers  - quantumumbers to an index.
%   index          - index of a state with certain quantumnumbers.
%   projion        - projects particular states
%
%Simulation:
%   simulateevolution  - simulates a state evolution.
%   getsimmatrix       - get the matrix of a simulation script.
