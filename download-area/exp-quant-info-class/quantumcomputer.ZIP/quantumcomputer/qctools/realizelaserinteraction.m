function Y=realizelaserinteraction(T,X,flag,pulsemap,ham,timescale,tfinal)

p=1;
temp=0;
b=0;
while(pulsemap(round(T*timescale+1),p)~=-1)
   HT=squeeze(ham(pulsemap(round(T*timescale+1),p),:,:));
   de=diag(HT);
   b=exp(-i*T*de)';
   HT=HT-diag(de);
   Hint=i*(b'*b).*triu(HT,1);
   Hint=Hint-(Hint');
   temp=temp+Hint;
   p=p+1;
end;

Y=temp*X;

if(mod(T/tfinal*100,1)<0.01)
    message(4,sprintf('ode15s: %2.0f %%',100*T/tfinal));
end;