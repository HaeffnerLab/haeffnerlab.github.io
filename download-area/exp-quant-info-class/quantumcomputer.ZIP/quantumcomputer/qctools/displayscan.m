function displayscan(PF,PH,x,xlabelname,idx)
%DISPLAYSCAN   display the results of a scan.
%  DISPLAYSCAN(FinalPopulations,FinalPhases,xaxis,xlabelname,states).


x=x';
f=figure(3);
plot(x,PF(:,idx),'.-');
xlabel(xlabelname);

f=figure(4);
plot(x,PH(:,idx),'.-');
xlabel(xlabelname);

