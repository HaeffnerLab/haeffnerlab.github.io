function [phonon,states] = quantumnumbers(ind,hspace);
%QUANTUMNUMBERS   quantum numbers.   
%   [phonon,states] = QUANTUMNUMBERS(ind,hspace);
%
%   Computes from the index ind the quantumnumbers.
%   States is a vector (or matrix in case of densitymatrix formalism) [ion_1 ion_2 ....] where ion_x specifies the state via the table 0->D 1->S 2->a.


if(exist('hspace')==0)
   global hspace;
end;


ind=ind-1;
if(hspace.densitymatrixformalism==0)
	indtemp=ind;
   for(k=1:length(hspace.maxphonons))
      phonon(k)=mod(indtemp,hspace.maxphonons(k)+1);
      indtemp=fix(indtemp/(hspace.maxphonons(k)+1));
   end;

	for k=1:hspace.nuions,
   	states(k)=mod(fix(fix(ind/prod(hspace.maxphonons+1))/((hspace.levels)^(hspace.nuions-k))),hspace.levels);
   end;

else

	dime = prod(hspace.maxphonons+1)*hspace.levels^hspace.nuions;
	ind1 = mod(ind,dime);
	ind2 = fix(ind / dime);

   indtemp=ind1;
   for(k=1:length(hspace.maxphonons))
      phonon(1,k)=mod(indtemp,hspace.maxphonons(k)+1);
      indtemp=fix(indtemp/(hspace.maxphonons(k)+1));
   end;
	for k=1:hspace.nuions,
   	states(1,k)=mod(fix(fix(ind1/prod(hspace.maxphonons+1))/((hspace.levels)^(hspace.nuions-k))),hspace.levels);
	end;


	indtemp=ind2;
   for(k=1:length(hspace.maxphonons))
      phonon(2,k)=mod(indtemp,hspace.maxphonons(k)+1);
      indtemp=fix(indtemp/(hspace.maxphonons(k)+1));
   end;
	for k=1:hspace.nuions,
   	states(2,k)=mod(fix(fix(ind2/prod(hspace.maxphonons+1))/((hspace.levels)^(hspace.nuions-k))),hspace.levels);
	end;
end;

%phonon=phonon';
