function displaypmsignal(T,Y,hspace)
%DISPLAYPMSIGNAL   photomultiplier signal
%   Displays the expected photomultiplier signal

if(length(T)>1)
		YR=abs(Y).^2;
%   	PF=YR(size(YR,1),:);
%   	PH=angle(Y(size(Y,1),:));

		f=figure(3);
      h2='';
      h3='';
   	clf
      hold on;     
      for j=1:hspace.nuions
         z=1;
         for i0=1:hspace.dimensions
            [ph,st]=quantumnumbers(i0,hspace);
            if(st(j)~=0)
               states(z)=i0;
               z=z+1;
            end;
      	end;
         EY(j,:)=sum(YR(:,states),2)'; 
      end;      
      EY=EY';
      plot(T,sum(EY,2)/hspace.nuions);
      legend('PM signal');
   	ylabel('D-state population','FontSize',14,'FontName','Timesnewroman')
      axis([min(T), max(T), 0, 1])
     	xlabel('Time / \mus','FontSize',18,'FontName','Timesnewroman');
      uiresume(f);
      hold on;
end;