

% STARTOPTI  the matrix of a simulation.

%   File:   startopti.m
%   Date:   07-Jul-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>
global noofpulses;
global resolution;

noofpulses=16;
resolution=2*0.6;

global messagehandle;
messagehandle=-1;


omz=2*pi*1714000;
phaselist=0.9*sin(0.5*[1:noofpulses-1]*resolution*10^-6*omz);
omclist=sqrt(1+0.9*cos(0.5*[1:noofpulses-1]*resolution*10^-6*omz));
omcbas=1.01;

list=[ 1.19007  0.95103  1.39354 -0.00284 -0.65371  1.03976  0.88681  0.57863  0.73345  0.82186  0.00004  0.25945  1.50000 -0.01499  0.67411  1.11602  1.01346  0.37544  1.48137  0.00024  1.50000  1.41521  1.32985  2.59963  0.78775  0.13705 -0.83250 -0.00109  1.27659  1.75612  1.15626  1.73002  1.15500  0.54011  1.50000  1.40618 
   
];   
list=reshape(list,2,length(list)/2);   
omcbas=list(1,2);
omclist=list(1,3:noofpulses+2);

phasebas=list(2,1);
phaselist=list(2,3:noofpulses+2);

if(version=='5.3.1.29215a (R11.1)')
   options = optimset('MaxFunEvals',1e8,'MaxIter',1e8);
   resultlist=fminsearch('optisim2',[list(1,1) omcbas omclist; phasebas 0 phaselist],options);   
else
   options(2)=0.0001;
	options(3)=0.0001;
	options(14)=10000000;
	options(16)=0.0001;
   resultlist=fmins('optisim2',[list(1,1) omcbas omclist; phasebas 0 phaselist],options);
end;

save startopti