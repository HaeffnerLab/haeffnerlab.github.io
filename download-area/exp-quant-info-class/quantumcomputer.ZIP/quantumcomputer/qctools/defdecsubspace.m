for(k=1:hspace.dimensions)
    [ph,el]=quantumnumbers(k);
    if((sum(el)==hspace.nuions/2)&sum(ph)==0)
        hspace.visible(k)=1;
    else
        hspace.visible(k)=0;
    end;
end;