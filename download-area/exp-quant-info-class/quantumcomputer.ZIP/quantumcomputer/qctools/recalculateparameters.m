function parameters=recalculateparameters(parameters)

if(parameters.eta(1)==-1)
   clear parameters.eta
   for(k=1:length(parameters.omegaz))
      if(min(parameters.eigenvectors(k,1:parameters.hspace.nuions))==-inf)
         error('Please specify eigenvectors!')
      end;
      parameters.eta(k,1:parameters.hspace.nuions)=parameters.eigenvectors(k,1:parameters.hspace.nuions)/norm(parameters.eigenvectors(k,1:parameters.hspace.nuions))*lambdicke(729*10^-9,parameters.omegaz(k)/2/pi,parameters.recoilangle);
	end;      
end;


if(parameters.ignorelightshift==1)
	parameters.frequencyscale=1e-6;
else
	parameters.frequencyscale=1;
end;
parameters.omegarealcarrier=parameters.omegacarrier*(1+parameters.intensitymismatch/2) * parameters.frequencyscale;
parameters.sbomegarealcarrier=parameters.sbomegacarrier*(1+parameters.intensitymismatch/2) * parameters.frequencyscale;
parameters.lightshift=-parameters.sbomegacarrier^2./parameters.omegaz * parameters.frequencyscale^2/2;
if(length(parameters.detuning)<length(parameters.omegaz))
    parameters.detuning=ones(1,length(parameters.omegaz))*parameters.detuning;
end;
parameters.detuning=parameters.detuning * parameters.frequencyscale;
parameters.tfinal=parameters.tfinal / parameters.frequencyscale;
parameters.addressing=parameters.addressing(1:parameters.hspace.nuions,size(parameters.addressing,2)-parameters.hspace.nuions+1:size(parameters.addressing,2));

parameters.y0=zeros(1,parameters.hspace.dimensions);   % starting conditions

if(length(parameters.omegaz)~=length(parameters.hspace.maxphonons)) 
   error('Not the same number of modes as axial frequencies!')
end;
