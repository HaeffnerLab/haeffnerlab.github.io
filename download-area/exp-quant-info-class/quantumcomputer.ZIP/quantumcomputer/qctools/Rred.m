function [pulse,endtime]=Rred(theta,phi,ion,mode,transition,fp,time);

if(nargin<7)
   time=fp;
   fp=transition;
   transition=mode;
   mode=1;
end;
   
pulse = struct('targetion',zeros(fp.hspace.levels,fp.hspace.nuions),'omc',0,'detuning',0,'phase',1,'starttime',0,'endtime',0); 

pulse.starttime = time;
endtime = time+theta*fp.piover2time(mode,ion);
pulse.endtime = endtime;
pulse.omc = fp.sbcarrierrabi;
pulse.detuning = fp.detuning(transition)-(fp.omz(mode)+fp.includelsdetuning*fp.lightshift(mode));
pulse.phase = (phi-0.5);   % to match Ike's and everybody elses convention
pulse.targetion = zeros(fp.hspace.levels,fp.hspace.nuions);
pulse.targetion(transition,:) = fp.addressingerror(ion,:);