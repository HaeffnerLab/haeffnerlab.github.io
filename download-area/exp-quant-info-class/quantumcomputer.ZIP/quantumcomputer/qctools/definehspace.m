function hspace=definehspace(nuions,levels,maxphonons,densitymatrixformalism)

%DEFINEHSPACE   defines a Hilbert space.
%   hspace = DEFINEHSPACE({nuions},{levels},{maxphonons},{densitymatrixformalism})
%
%   Returns the structure hspace of the corresponding Hilbert space.
%   Its also defined as a global variable. All parameters are optional.
%   Default values:
%         nuions=2, levels=2, maxphonons=2, densitymatrixformalism=0
%   If you need more than 1 vibrational mode, specify the maximal phonon number
%   in maxphonons as a vector.  
%
%   See also SETSTATEVISIBILITY, DISPMAT, DISPABSMAT, UCAR, UBLUE, URED.

%   File:   definehspace.m
%   Date:   21-Sep-02 / Revised: 24-Mar-03 
%   Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at>



global hspace;

if(exist('nuions')==0)
   nuions=2;
end;

if(exist('levels')==0)
   levels=2;
end;

if(exist('maxphonons')==0)
   maxphonons=3;
end;

if(exist('densitymatrixformalism')==0)
   densitymatrixformalism=0;
end;

if(isfield(hspace,'visible'))
   oldhspace=hspace;
else
   oldhspace.visible=-1;
end;

hspace = struct('nuions',nuions,'levels',levels,'maxphonons',maxphonons,'densitymatrixformalism',densitymatrixformalism,'dimensions',(prod(maxphonons+1)*levels^nuions)^(densitymatrixformalism+1));
if(length(oldhspace.visible)~=hspace.dimensions)
   hspace.visible=ones(1,hspace.dimensions);
else
   hspace.visible=oldhspace.visible;
end;

global projector;
projector=0;

global decoherences
decoherences = struct('frefluct',0,'det_frefluct',[0*2*pi*1000,1],'intensity_fluctuations',0);
%decoherences = struct('frefluct',0.2,'det_frefluct',[0*2*pi*1000,1],'intensity_fluctuations',0);
	