function [dat,PF]=scan(file,pu,what,displayedstates,start,stop,points)

% SCAN scan phase in a simulation.
%   SCAN (file,pulse(s),what,displayedstates,start,stop,points)
%   file is filename of the simulation script.
%   what is a string and specifies what should be scanned. All entries of the
%   pulse-structure are possible.
%   pulse is a number or vector and indicates the phase of which pulse(s) is scanned. 

%   File:   scan.m
%   Date:   27-Mar-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>




eval(file)
parameters.points=1;
xv=start;
for(k=1:points)
   s=sprintf('Set: %d, Value: %4.4f',k,xv);
   message(1,s)
   for(i0=1:length(pu))
   	pulse(pu(i0))=setfield(pulse(pu(i0)),what,xv);
   end;   
   [T,Y]=simulateevolution(pulse,parameters);
   PF(k,:)=Y(size(Y,1),:);
   xax(k)=xv;
   xv=xv+(stop-start)/points;
end;
closemessagewindow;
dat=[xax',abs(PF(:,:)).^2];
figure(2)
clf;
plot(xax,abs(PF(:,displayedstates)).^2)
xlabel(what);
ylabel('D-state population');
for(i0=1:length(displayedstates))
	s=sprintf('%s',statename(displayedstates(i0),hspace));
	leg(i0,1:length(s))=s;
end;
legend(leg);
dat=[xax',abs(PF(:,displayedstates)).^2];

save scan