function [u,projector] = projion(M,phstate,elstate,hspace)
%PROJION   projection of ion #ion with level x.
%   [M,PROJECTOR] = PROJ(M,phstate,elstate,{hspace})
%   Projects a matrix M, set to -1 if not not to be projected, e.g. elstate=[-1 1]
%   projects for a two ion crystal the second ion onto the S-state.
%
%   See also PROJ

%   File:   projion.m
%   Date:   2-Nov-04
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>

if(exist('hspace')==0)
   global hspace;
end;
 
phind=find(phstate~=-1);
elind=find(elstate~=-1);
m=0;
projector=0;
for(j=1:hspace.dimensions)
    [ph,el]=quantumnumbers(j,hspace);
    
    if((sum(abs(el(elind)==elstate(elind)))==length(elind)) && (sum(abs(ph(phind)==phstate(phind)))==length(phind)))
     	 m=m+1;   
         projector(m,j)=1;
   	elseif(m~=0)
     	 projector(m,j)=0;
   	end;   
end;
if(size(M,2)==1)
	u = projector*M;
elseif(size(M,1)==1)
	u = M*projector';   
else
	u = projector * M * projector';
end;
