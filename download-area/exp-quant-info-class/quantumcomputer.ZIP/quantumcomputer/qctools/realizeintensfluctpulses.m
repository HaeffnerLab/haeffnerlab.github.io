function Y=realizeintensfluctpulses(pulse,parameters);

maxin=10;
maxdet=10;
interr=-parameters.decoherences.intensity_fluctuations/2;
deterr=-parameters.decoherences.detuning_fluctuations/2;
if interr==0 
   maxin=1;
end;
if deterr==0 
   maxdet=1;
end;
for in=1:maxin
   parameters.intensitymismatch=interr;
   for dn=1:maxdet
    message(1,sprintf('Intensity set %d',in));
    message(2,sprintf('Detuning set %d',dn));
    Te=realizepulses(pulse,parameters,parameters.frequencyscale*deterr);
    Ytemp((in-1)*maxdet+dn,:,:,:)=Te(:,:,:);
    if maxdet>1 
      deterr=deterr+parameters.decoherences.detuning_fluctuations/(maxdet-1);
    end;
   end; 
   if maxin>1 
      interr=interr+parameters.decoherences.intensity_fluctuations/(maxin-1);
   end;
end;

Y=shiftdim(sqrt(mean(abs(Ytemp).^2,1)),1);   % here the proper averaging according to a good intensity distribution has to be added
Y=Y.*exp(i*shiftdim(mean(angle(Ytemp),1),1));

