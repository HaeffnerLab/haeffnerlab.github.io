function index = finddetfrequ(time,dec);

index = 1;

while(dec(1,index)<time)
   index = index + 1;
   if index==size(dec,2) & dec(1,index)>=time 
      fprintf('Pulses are not finished at T_{final}\n');
      break;
   end;
end;