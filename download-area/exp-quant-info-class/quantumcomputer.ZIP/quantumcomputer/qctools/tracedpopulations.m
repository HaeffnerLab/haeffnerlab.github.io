function [EY,str]=tracedpopulations(T,Y,hspace,displ)
%TRACEDPOPULATIONS   trace over each ion.
%   EY = tracedpopulations(T,Y,hspace,{display})
%
%   set the optional parameter display to 1 to plot it.

if(~exist('displ'))
   displ=0;
end;
if(length(T)>1)
   	if(hspace.densitymatrixformalism)
      	YR=abs(Y);
      else
      	YR=abs(Y).^2;
   	end;   
%   	PF=YR(size(YR,1),:);
%   	PH=angle(Y(size(Y,1),:));

      for j=1:hspace.nuions
         z=1;
         for i0=1:hspace.dimensions
            [ph,st]=quantumnumbers(i0,hspace);
            if(hspace.densitymatrixformalism)
               if(ph(1)==ph(2) & min(st(:,1)==st(:,2)) & st(j,1)~=0)
               	states(z)=i0;
               	z=z+1;
            	end;   
            elseif(st(j)~=0)
               states(z)=i0;
               z=z+1;
            end;
      	end;
         EY(j,:)=sum(YR(:,states),2)'; 
      end;      
      EY=EY';
      TI=repmat(T,hspace.nuions,1)';
      for j=1:hspace.nuions
         str(j,:)=sprintf('ion %d',hspace.nuions-j);
      end;
      if(displ)
         f=figure(2);
      	h2='';
      	h3='';
   		clf
      	hold on;     
      	p=plot(TI,EY);
      	legend(str);
   		ylabel('D-state population','FontSize',14,'FontName','Timesnewroman')
      	axis([min(T), max(T), 0, 1])
     		xlabel('Time / \mus','FontSize',18,'FontName','Timesnewroman');
         uiresume(f);
      end;
end;