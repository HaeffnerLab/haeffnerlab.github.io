function ind=index(phonon,states,hspace);
%INDEX   index of a quantum state
%   ind = INDEX(phonon,states,{hspace}) returns the index ind of the state specified by phonon and states
%   states is a vector [ion_1 ion_2 ....] where ion_I specifies the state via the table 0->D 1->S 2->a
%   In case of densitymatrix formalism phonon and states have an additional dimension;

if(exist('hspace')==0)
   global hspace;
end;

fac=1;
for(k=1:length(hspace.maxphonons))
	phfac(k)=fac;
	fac=fac*(hspace.maxphonons(k)+1);
end;
if(hspace.densitymatrixformalism)
   	if(size(phonon,1)==1)
  		states1=states(1:hspace.nuions);
		states2=states(1:hspace.nuions);
		phonon=[phonon;phonon];
   	else
		states1=states(1,1:hspace.nuions);
		states2=states(2,1:hspace.nuions);
   	end;
	statewei=[hspace.nuions-1:-1:0];
	statewei=hspace.levels.^statewei;

   	ind1=phonon(1,:)*phfac' +sum(states1*statewei')*prod(hspace.maxphonons+1);
	ind2=phonon(2,:)*phfac' +sum(states2*statewei')*prod(hspace.maxphonons+1);

   	ind = 1+ind1+ind2*hspace.levels.^hspace.nuions*prod(hspace.maxphonons+1);
else
	stat=states(1:hspace.nuions);

	statewei=[hspace.nuions-1:-1:0];
   	statewei=hspace.levels.^statewei;

   	ind=1+phonon*phfac'+sum(stat*statewei')*prod(hspace.maxphonons+1);
end;
