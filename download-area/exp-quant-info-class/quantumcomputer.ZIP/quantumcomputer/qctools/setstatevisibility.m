function [basis,hspace]=setstatevisibility(phonons,ions,diagsonly,hspace)
%SETSTATEVISIBILITY   which states to show.
%   [basis,hspace] = SETSTATEVISIBILITY({phonons},{ions},{diagsonly},{hspace})
% 
%   phonons gives the maximal phonon number visible, default is 0.
%   if phonons is a vector it is assmumed that phonons contains directly the indices to display.
%   ions is a vector specifying which ion to which level should be displayed, default is 1.
%   diagsonly is flag telling whether the diagonals of the density matrix should be displayed only, default is 0. 
%   For more control modify the hspace structure directly. Make sure to clear the projector (a global variable) then
%   Remember also that hspace might be a global variable. 
%
%   See also DISPMAT, DISPABSMAT, PROJ.

%   File:          setstatevisibility.m
%   Date:          21-Sep-02
%   Last modified: 22-Dec-02
%   Author:        Hartmut H�fner <hartmut.haeffner@uibk.ac.at>

if(exist('hspace')==0)
   global hspace;
end;

if(exist('phonons')==0)
   phonons=0;
end;

if(exist('ions','var')==0)
   ions=ones(1,hspace.nuions);
elseif(isfield(ions,'visible'))
   hspace=ions;
   ions=ones(1,hspace.nuions);
end;
if(exist('diagsonly')==0)
   diagsonly=0;
elseif(isfield(diagsonly,'visible'))
   hspace=diagsonly;
   diagsonly=0;
end;


global projector;
projector=0;
if(length(phonons)>1)         % phonons contains the indecies ...
	hspace.visible=zeros(1,hspace.dimensions);
	hspace.visible(phonons)=ones(1,length(phonons));
else
  for j=1:hspace.dimensions
   if(hspace.densitymatrixformalism)
      [p,s]=quantumnumbers(j,hspace);
      if(diagsonly & (sum(p(:,1)~=p(:,2)) | max(s(:,1)~=s(:,2))))
         p=phonons+1;
         s=s(1);
      else
         p=max(p');
      	s=max(s');
      end;   
   else
      [p,s]=quantumnumbers(j,hspace);
   end;
   if(sum(p>phonons))
      v=0;
   elseif(min(ions-s)<0)
      v=0;
   else
      v=1;
   end;
   hspace.visible(j)=v;
 end;
end;
basis=dispmat;
