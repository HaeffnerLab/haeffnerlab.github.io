function [u,projector] = proj(M,hspace)
%PROJ   projection.
%   [M,PROJECTOR] = PROJ(M,{hspace})
%   Projects a matrix M to the basis as specified in hspace.visible.
%
%   See also SETSTATEVISIBILITY.

%   File:   proj.m
%   Date:   21-Sep-02
%   Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at>

global projector;
global fastproj;   % this flag determines wether the projector should be recalculated just in case the user messed up with hspace.visibility!

if(exist('hspace')==0)
   global hspace;
end;
% we now construct the projector, if it has not been done before!
if(isempty('projector') | ~fastproj)
   m=0;
   projector=0;
	for(j=1:hspace.dimensions)
   	if(hspace.visible(j)==1)
     	 m=m+1;   
       projector(m,j)=1;
     	elseif(m~=0)
     	 projector(m,j)=0;
   	end;   
   end;
end;
M=min(M,1e39);   % solve problems if M contains  inf's.
if(size(M,2)==1)
	u = projector*M;
elseif(size(M,1)==1)
	u = M*projector';   
else
	u = projector * M * projector';
end;
