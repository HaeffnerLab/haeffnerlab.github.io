function deviation=optisim(list)

% OPTISIM  the matrix of a simulation fpr optimisation.
%   OPTISIM(phaselist)
%   phaselist.

%   File:   optisim.m
%   Date:   07-Jul-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>

goal=[
   1  0 0 0;
   0  0 0 1;
   0  0 1 0;
   0 -1 0 0;
];

clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,4,0);
parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=1;
parameters.omegacarrier=2*pi*1e6;
%parameters.recoilangle=0;
parameters.points=1;
parameters.ignorelightshift=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0 0],parameters.hspace))=1;
%parameters.y0(index(1,[0 0],parameters.hspace))=0.02;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

global noofpulses;
global resolution;



reres=resolution*list(1,1);    % resolution

for p=1:noofpulses
   [pulse(p),time] = Rcar(reres,0,1,1,fxpa,time);
end;

[temp,hspace]=setstatevisibility(1,1,0,hspace);

%pulse(1).omc=parameters.omegaz*list(1,2)*list(1,1);
%pulse(1).phase=list(2,2);   
for(pu=1:p)
   pulse(pu).omc=list(1,2)*list(1,1)*parameters.omegaz*list(1,pu+2);
   pulse(pu).phase=exp(i*pi*list(2,1))*list(2,pu+2);   
end;
z=1;
for(k=1:hspace.dimensions)
   if(hspace.visible(k)~=0)
      statesofinterest(z)=k;
      z=z+1;
   end;
end;
z=1;
for(k=statesofinterest)
      parameters.y0=zeros(1,hspace.dimensions);
      parameters.y0(k)=1;
      [T,Y]=simulateevolution(pulse,parameters);
%      sum(abs(Y(size(Y,1),statesofinterest)').^2)
      U(:,z)=Y(size(Y,1),statesofinterest)';
      z=z+1;
end;
closemessagewindow;
U
sum(sum(abs(U-goal).^2))
deviation=sum(sum(abs(U-goal).^2))+0.01*abs(list(1,1))+abs(max(abs(list(1,:)))-1.5)
time
global homepath;
fid=fopen([homepath,'\quantumcomputer\normal\optisimhistory.dat'],'a');
if(fid)
   fprintf(fid,'Deviation: %8.5f ',deviation);
   fprintf(fid,'Time: %8.5f ',time*10^6);
   fprintf(fid,'%8.5f ',list);
   fprintf(fid,'\n');
   fclose(fid);
else
   s=sprintf('File %s not opened.\n','optisimhistory.dat');
   error(s);
end;