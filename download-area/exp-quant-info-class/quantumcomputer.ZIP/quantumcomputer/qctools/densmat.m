function hspace=densmat(str,hspace)

%DENSMAT   densitymatrix formalism on.
%   hspace = DENSMATON({on/off},{hspace})

if(exist('hspace')==0)
   global hspace;
end;
if(exist('str')==0)
   if(hspace.densitymatrixformalism==0)
      str='on';
   else
      str='off';
	end;
end;   

nu=hspace.nuions;
le=hspace.levels;
ph=hspace.maxphonons;

if(strcmp(str,'off'))
   hspace=definehspace(nu,le,ph,0);
elseif(strcmp(str,'on'))
   hspace=definehspace(nu,le,ph,1);
else
   fprintf('As the first argument only "on" or "off" allowed.\n')
end;