function s=dispabsmat(M,digs,hspace)

%DISPABSMAT   absolute values of a matrix.
%   DISPABSMAT({M},{digits},{hspace}) display the absolute values of the Matrix M with precision digits.
%
%   See also DISPMAT.


if(exist('M')==0)
   global hspace;

elseif(length(M)<=1)
   hspace=M;
   clear M;
end;
if(exist('digs')==0)
   digs=4;
end;
if(exist('hspace')==0)
   global hspace;
end;
ma=M.*conj(M);
s=dispmat(ma,digs,hspace);
