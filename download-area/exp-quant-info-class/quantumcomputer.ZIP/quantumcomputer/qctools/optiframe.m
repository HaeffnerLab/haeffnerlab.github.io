% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

hspace=definehspace(1,2,2,0);
setstatevisibility(0);

parameters=standardparameters(hspace); 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=1;
parameters.omegacarrier=2*pi*1e6;
parameters.recoilangle=68;
parameters.points=1;
parameters.ignorelightshift=0;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0 0],parameters.hspace))=1;
%parameters.y0(index(1,[0 0],parameters.hspace))=0.02;

%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
%*****************************************************************************%

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxsc,time)
%  Rblue(theta,phi,ion,transition,fxsb,time)

res=2*0.05;    % resolution

p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(res,0,1,1,fxpa,time); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
closemessagewindow;
T=T*fs;;
[PF,PH]=endpopulations(T,Y,hspace);
hold on;
%*****************************************************************************%
