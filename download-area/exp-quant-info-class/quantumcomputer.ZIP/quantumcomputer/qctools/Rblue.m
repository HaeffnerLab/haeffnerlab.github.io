function [pulse,endtime]=Rblue(theta,phi,ion,mode,transition,fp,time);

;%fp = struct('carrierrabi',omcre,'omz',omz,'lightshift',dlshift,'detuning',det,'addressingerror',addreerr,'piover2time',pi2,'includelsdetuning',0,'hspace',hspace);

if(nargin<7)
   time=fp;
   fp=transition;
   transition=mode;
   mode=1;
end;
   
pulse = struct('targetion',zeros(fp.hspace.levels,fp.hspace.nuions),'omc',0,'detuning',0,'phase',1,'starttime',0,'endtime',0); 

pulse.starttime = time;
endtime = time+theta*fp.piover2time(mode,ion);
pulse.endtime = endtime;
pulse.omc = fp.sbcarrierrabi;
pulse.detuning = fp.detuning(transition)+((fp.omz(mode))+fp.includelsdetuning*fp.lightshift(mode));
pulse.phase = (phi-0.5);   % to match Ike's and everybody elses convention
pulse.targetion = zeros(fp.hspace.levels,fp.hspace.nuions);
pulse.targetion(transition,:) = fp.addressingerror(ion,:);
