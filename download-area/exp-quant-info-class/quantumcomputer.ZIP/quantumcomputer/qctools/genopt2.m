

% STARTOPTI  the matrix of a simulation.

%   File:   startopti.m
%   Date:   07-Jul-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>
global noofpulses;
global resolution;

noofpulses=32;
resolution=2*0.3;

global messagehandle;
messagehandle=-1;


omz=2*pi*1714000;
phaselist=0.9*sin(0.5*[1:noofpulses-1]*resolution*10^-6*omz);
omclist=sqrt(1+0.9*cos(0.5*[1:noofpulses-1]*resolution*10^-6*omz));
omcbas=1.01;

list=[  1.25145  0.96897  1.34070  0.01275 -0.79948  1.02757  0.55801  0.22068  1.06279  0.28364 -0.00000 -0.39299  1.44204 -0.08711  0.50699  1.51496  0.89336 -0.05438  1.26013  0.00753  1.50011  1.44985  0.67951  2.38420  0.71158  0.45670 -0.70246  0.00334  1.34926  2.54175  1.09227  1.91675  1.13476  0.60380  1.39237  1.90984 -0.69801  1.20215  0.36242  0.08037  1.10786  0.33606 -0.00009 -0.49109  1.32377 -0.33893  0.39997  1.34339  0.75222 -0.18068  1.49741  0.00063  1.50024  1.69172  1.25703  2.34304  0.50801  0.18909 -0.73259  0.08443  1.50023  2.34646  0.95467  1.28499  1.23561  0.75105  1.36397  1.71276 

 ];   
 
for(k=1:length(list))
   variableOps(k,:)=[4 0 2];
end;
startPop=[list; (1.1-0.8*rand(1,length(list))).*list; (1.1-0.8*rand(1,length(list))).*list; (1.05-0.9*rand(1,length(list))).*list; (1.05-0.9*rand(1,length(list))).*list; (1.05-0.9*rand(1,length(list))).*list; (1.05-0.9*rand(1,length(list))).*list; (1.05-0.9*rand(1,length(list))).*list; (1.05-0.9*rand(1,length(list))).*list;];
[x,endPop,bPop,traceInfo]=multiga(variableOps,'optisim3',0,startPop,[1e-6 0],'maxGenTerm',10000);

save genopt2