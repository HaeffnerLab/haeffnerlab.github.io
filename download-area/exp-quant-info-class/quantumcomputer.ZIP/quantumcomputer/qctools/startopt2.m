

% STARTOPTI  the matrix of a simulation.

%   File:   startopti.m
%   Date:   07-Jul-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>
global noofpulses;
global resolution;

noofpulses=32;
resolution=2*0.3;

global messagehandle;
messagehandle=-1;


omz=2*pi*1714000;
phaselist=0.9*sin(0.5*[1:noofpulses-1]*resolution*10^-6*omz);
omclist=sqrt(1+0.9*cos(0.5*[1:noofpulses-1]*resolution*10^-6*omz));
omcbas=1.01;

list=[  1.25785  0.96964  1.41400  0.01932 -0.44290  1.16012  0.73834  0.12130  0.95878  0.05768 -0.00676 -0.67260  1.17723 -0.23179  0.60137  1.69816  0.74056  0.03116  0.90030  0.01130  1.23721  1.62657  0.33705  2.56415  0.71223  0.66236 -0.45922  0.00726  1.41723  2.71946  0.86779  2.22058  1.16605  0.79847  1.35166  1.97362 -0.80341  1.29293  0.33470  0.02130  0.86356  0.21957 -0.00041 -0.27839  1.34822 -0.44757  0.40052  1.34575  0.45447 -0.24269  1.29239  0.00139  1.49998  1.76815  1.39316  2.32630  0.39737  0.11784 -0.84442 -0.06853  1.47518  2.33110  0.89099  1.24830  1.06878  0.80887  1.30604  1.76778 

 ];   
list=reshape(list,2,length(list)/2);   
omcbas=list(1,2);
omclist=list(1,3:noofpulses+2);

phasebas=list(2,1);
phaselist=list(2,3:noofpulses+2);

ver=version;
if(ver(1:3)=='5.3')
   options = optimset('MaxFunEvals',1e8,'MaxIter',1e8,'TolX',1e-8);
   resultlist=fminsearch('optisim2',list,options);   
else
   options(2)=0.0001;
	options(3)=0.0001;
	options(14)=10000000;
	options(16)=0.0001;
   resultlist=fmins('optisim2',[list(1,1) omcbas omclist; phasebas 0 phaselist],options);
end;

save startopti