% -*- mode: MATLAB -*-
% Time-stamp: "2006-01-10 14:40:50 c704271"

%  file      : Rshape.m
%  email     : philipp DOT emacs DOT schindler AT uibk DOT ac DOT at
%            : remove the "One And Only Editor"
%  copyright : (c) 2005 Philipp Schindler
%  rcs       : $Id$


function [pulses,endtime] = Rshape(theta,phi,ion,transition,fp,fpcomp,time,shape)

  fp0=fp;
  fpcomp0=fpcomp;
  omega=fp.sbcarrierrabi;
  omegacomp=fpcomp.sbcarrierrabi;
  step_time=shape.time/shape.steps;
  time1=2*theta/omega;
  mode=1;
  endtime=time;
  fp.piover2time(1);
  theta02=(shape.time*1e-6)/fp.piover2time(mode);
  theta0=theta-theta02;
  frequencyscale=1;

  for (i0=1:2:shape.steps*2-1)
    x=(i0+1)/2/(shape.steps+1);
    black=1.0/2.0*(0.84-cos(x*pi)+0.16*cos(2*x*pi));
    fp.sbcarrierrabi=omega*black;
    fpcomp.sbcarrierrabi=0.5*omegacomp*black;
    fp.lightshift=-fp0.sbcarrierrabi^2./fp.omz * frequencyscale^2/2;
    fpcomp.lightshift=fpcomp0.sbcarrierrabi^2./(fpcomp.omz) * frequencyscale^2/2;
    fp.piover2time=fp.piover2time/black;
    fpcomp.piover2time=fpcomp.piover2time/black;
    theta1=step_time/fp.piover2time(mode)/1e6;
    time=endtime;
    timecomp=endtime;
    [pulses(i0),endtime]=Rblue(theta1,phi,ion,transition,fp,time+0.01e-6);
    [pulses(i0+1),endtime]=Rred(theta1,phi,ion,transition,fpcomp,timecomp+0.01e-6);
  end;
  i0=i0+2;  
  fp=fp0;
  fpcomp=fpcomp0;
  fp.sbcarrierrabi=omega;
  fpcomp.sbcarrierrabi=omegacomp;
  time=endtime;
  timecomp=endtime;
  [pulses(i0),endtime]=Rblue(theta0,phi,ion,transition,fp,time+0.01e-6);
  [pulses(i0+1),endtime]=Rred(theta0,phi,ion,transition,fpcomp,timecomp+0.01e-6);

  for (i0=1:2:shape.steps*2-1)
    x=(i0+1)/2/(shape.steps+1);
    black=1-1.0/2.0*(0.84-cos(x*pi)+0.16*cos(2*x*pi));
    fp.sbcarrierrabi=omega*black;
    fpcomp.sbcarrierrabi=0.5*omegacomp*black;
    fp.lightshift=-fp0.sbcarrierrabi^2./fp.omz * frequencyscale^2/2;
    fpcomp.lightshift=fpcomp0.sbcarrierrabi^2./(fpcomp.omz) * frequencyscale^2/2;
    fp.piover2time=fp.piover2time/black;
    fpcomp.piover2time=fpcomp.piover2time/black;
    theta1=step_time/fp.piover2time(mode)/1e6;
    time=endtime;
    timecomp=endtime;
    [pulses1(i0),endtime]=Rblue(theta1,phi,ion,transition,fp,time+0.01e-6);
    [pulses1(i0+1),endtime]=Rred(theta1,phi,ion,transition,fpcomp,timecomp+0.01e-6);
  end;
 pulses=[pulses,pulses1];



