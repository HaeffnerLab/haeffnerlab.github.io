function p=parity(state,hspace)

%PARITY   parity of a state
% parity=PARITY(states,{hspace})
if(exist('hspace')==0)
   global hspace;
end;

for i0=1:hspace.dimensions
   [p,qu]=quantumnumbers(i0,hspace);
   qu=min(qu,1);
   pa(i0)=-(mod(sum(qu),2)*2-1);
end;
if(size(state,1)>1) 
    state=state';
end;
p=sum((abs(state)/norm(state)).^2.*pa);