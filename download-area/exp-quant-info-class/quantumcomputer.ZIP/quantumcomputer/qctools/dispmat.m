function s=dispmat(matr,digs,hspace)
%DISPMAT   matrix/vector display.
%   U = DISPMAT({matr},{digs},{hspace})
%
%   Displays a matrix/vector matr in its basis defined by hspace. Input is from the top, output to the side.
%   digs controls to which number of digs each entry is displayed.
%   All parameters are optional:
%       no hspace => hspace is taken from the global enviroment defined as well by definehspace
%       no digs => digs is set to 2
%       no matr   => only the basis is displayed
%
%   See also DISPABSMAT.

%   File:   dispmat.m
%   Date:   24-Sep-02
%   Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at>

if(exist('matr')==0)
   global hspace;

elseif(length(matr)<=1)
   hspace=matr;
   clear matr;
end;
if(exist('digs')~=1)
   digs=2;
end;
if(exist('hspace')==0)
   global hspace;
end;

m=0;
for j=1:hspace.dimensions
   if(hspace.visible(j)==1)
      m=m+1;
      stemp=statename(j,hspace);
      t(m,1:length(stemp))=stemp;
   end;
end;
limit=10^(-digs);
digstr=sprintf('%1d',digs);
if(exist('matr')==1)
   MA=proj(matr);
   if(size(MA,2)>1)
   	for(k=1:size(MA,2))
     	 le(1,k+1)=size(t(k,:),2);
     	 en(1,k+1,:)=t(k,1:le(1,k+1));
      end;
   end;
   for(j=1:size(MA,1))
      le(j+2,1)=size(t(j,:),2);
      en(j+2,1,1:le(j+2,1))=t(j,:);
      for(k=0:size(MA,2)-1)
        y=MA(j,k+1);
        if(abs(imag(y))<limit)
            if(isclosetointeger(real(y),limit))
               z=sprintf(['%',digstr,'.0f'],real(y));
            else
            	z=sprintf(['%',digstr,'.',digstr,'f'],real(y));
            end;
         elseif(abs(real(y))<limit)
            if(abs((abs(imag(y))-1))<limit)
               if(imag(y)>0) 
                  z=sprintf('%si',' ');
               else
                  z=sprintf('%s-i',' ');
               end;
            elseif(isclosetointeger(imag(y),limit))
            	z=sprintf(['%',digstr,'.0fi'],imag(y));
            else
            	z=sprintf(['%',digstr,'.',digstr,'fi'],imag(y));
            end; 
         else
         	z=sprintf(['%',digstr,'.',digstr,'f + %',digstr,'.',digstr,'fi'],real(y),imag(y));
         end;
         le(j+2,k+2)=length(z);
         en(j+2,k+2,1:le(j+2,k+2))=z;
 		end;   
   end;
   collen=max(le,[],1);
   xp=1;
   for(k=1:size(en,2))
      for(j=1:size(en,1))
         s(j,xp+round(collen(k)/2-le(j,k)/2):xp+round(collen(k)/2-le(j,k)/2)+le(j,k)-1)=en(j,k,1:le(j,k));
      end;
      xp=xp+collen(k)+2;
   end;
	%s=num2str(proj(matr),3);   
else
   s='';
   for(j=1:m)
      s(length(s)+1:length(s)+length(t(j,:)))=t(j,:)';
      s=[s,' '];
   end;
end;
