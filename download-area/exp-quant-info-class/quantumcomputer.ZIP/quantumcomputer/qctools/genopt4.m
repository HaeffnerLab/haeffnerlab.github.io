

% STARTOPTI  the matrix of a simulation.

%   File:   startopti.m
%   Date:   07-Jul-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>
global noofpulses;
global resolution;

noofpulses=8;
resolution=2*0.38;

global messagehandle;
messagehandle=-1;


omz=2*pi*1714000;


%list=[0.72686  1.91019  1.49814  1.71579  0.11227  1.61592  2.00000  0.31490  0.79737  0.00000  0.78011  0.00000  1.53938  2.00000  0.14422  1.88600  1.55456  2.00000  1.19221  1.08572  1.60521  0.65876  0.65389  1.35043  2.00000  0.35971  1.65224  1.81942  1.15751  2.00000  0.40553  1.01578  1.99951  0.57883  0.32174  0.11721  1.01667  0.89831  1.27927  0.07251  0.85034  2.00000  0.55879  1.53329  1.06149  2.00000  1.82646  1.33757  0.66539  0.86710  1.20869  0.62475  1.65737  1.43243  1.90114  0.00000  0.72666  1.60800  0.09452  0.45534  1.77980  1.85585  0.00000  1.08161  0.14862  1.29914  1.57793 -2.44925 ]
%optisim4(list,1)

%asdf

clear variableOps;
for(k=1:(2*noofpulses)+3)
   variableOps(k,:)=[4 0 2];
end;
variableOps(1,:)=[4 0.5 3];



popsize=10000
maxgenerations=540
%initPop=initializega(popsize,variableOps,'optisim4');
initPop=multiinitializega(popsize,variableOps,'optisim4');

%initpop=

variableOps(1,:)=[4 0.1 4];

size(initPop)
%[x,endPop,bPop,traceInfo]=multiga(variableOps,'optisim4',[],initPop,[1e-6 0 1],'maxGenTerm',30,...
%  'normGeomSelect',[0.08],['arithXover heuristicXover'],[2 0.1;2 3;2 0.1],'boundaryMutation',[4 0 0;6 100 3; 4 0 0; 5 5 5]);

global tracefile;

tracefile='c:\temp\genopt4trace.dat'

[x,endPop,bPop,traceInfo]=multiga(variableOps,'optisim4',0,initPop,[1e-6 1],'maxGenTerm',maxgenerations,...
  'normGeomSelect',[0.08],[0.1 1],'','','','multiFloatArithXover multiFloatHeuristicXover',[0],[0],[0],[0.1; 0.23; 0.1],'','','','boundaryMutation',[0],[0],[0],[[0 0; maxgenerations 3; 0 0; 0.8 4]]);

figure(2)
%Lets take a look at the performance of the ga during the run
clf;
plot(traceInfo(:,1),traceInfo(:,3),'y-')
hold on
plot(traceInfo(:,1),traceInfo(:,2),'r-')
xlabel('Generation'); ylabel('Fittness');

save genopt4