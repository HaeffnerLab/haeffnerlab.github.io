hspace=parameters.hspace;
fxpa = struct('carrierrabi',parameters.omegarealcarrier,'sbcarrierrabi',parameters.sbomegarealcarrier,'omz',parameters.omegaz,'lightshift',parameters.lightshift,'detuning',parameters.detuning,'addressingerror',parameters.addressing,'piover2time',-ones(1,4),'includelsdetuning',0,'hspace',hspace);
fxpa.piover2time=pi*(2./(2*abs(parameters.eta)))/parameters.sbomegacarrier / parameters.frequencyscale;
fs = parameters.frequencyscale;
delayunit=10^-6/fs;
time=0;
p=0;
