function U=scan(file,what,start,stop,resolution,pu)

% SCAN scan phase in a simulation.
%   SCAN (file,what,start,stop,resolution,pulse)
%   file is the simulation script.
%   what specifies what should be scanned. All entries of the
%   pulse-structure are possible.
%   pulse indicates the phase of which pulse(s) is scanned. 
%   pulse can be also a vector.

%   File:   getsimmatrix.m
%   Date:   27-Mar-03
%   Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at>



feval(file)
parameters.points=1;
phase=start;
for(k=1:abs(stop-start)*resolution)
   pulse(pu).phase=phase;
   [T,Y]=simulateevolution(pulse,parameters);
      U(:,k)=Y(size(Y,1),:)';
   phase=phase+sign(stop-start)*resolution;
end;
closemessagewindow;