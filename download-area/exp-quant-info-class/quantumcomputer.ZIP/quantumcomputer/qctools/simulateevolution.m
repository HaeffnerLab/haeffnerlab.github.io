function [T,Y]=simulateevolution(pulses,parameters)
%SIMULATEEVOLUTION   simulation of a pulse sequence.
%   [T,Y] = simulateevolution(pulses,parameters)
%   pulses is the pulse sequence as an array with structures according to
%   pulse(i) = struct('targetion','omc','detuning','phase','starttime','endtime'); 

hspace=parameters.hspace;

%openmessagewindow;

if(parameters.tfinal~=0)
   ;
else
   parameters.tfinal=pulses(length(pulses)).endtime*1.1+10^-6;
end;

if parameters.points == 1
   parameters.T(1)=parameters.tfinal;
else
   parameters.T=[0:parameters.tfinal/parameters.points:parameters.tfinal];
end;

Y=realizeintensfluctpulses(pulses,parameters);
T=parameters.T*1e6;

%closemessagewindow;
