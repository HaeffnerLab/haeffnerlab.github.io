function Lrelax=calcLrelax(decoherences,hspace)

%CALCLRELAX   relaxation part of the Liouville operator.
%   Lrelax = CALCLRELAX(decoherences,hspace)


 z=sqrt(hspace.dimensions);                    % Zahl der Niveaus
 E=eye(z);               % Einheitsmatrix
 ii=(1:z)'*ones(1,z);   
 i1=reshape(ii',1,z^2);  % i1 = (1 1 2 2)
 i2=reshape(ii,1,z^2);   % i2 = (1 2 1 2)
 clear ii


% Relaxation % decoherences = struct('s_d_width',1000,'laser_linewidth',0,'intensity_fluctuations',0);
hspace.densitymatrixformalism=0;    % we want the usual quantumnumbers.
fprintf('Attention: Aux-level does not decohere!')
  for k=1:z
     [p,states]=quantumnumbers(k,hspace);
	  C(k,:,:)=sum(sign(states))*sqrt(decoherences.frefluct)*E(:,k)*E(k,:);
  end;
  Cs_d_width = squeeze(sum(C,1));
  CCs_d_width = Cs_d_width'*Cs_d_width;
  
  -CCs_d_width(i1,i1).*E(i2,i2);
  Cs_d_width(i1,i1).*Cs_d_width(i2,i2);
  
  Lrelax = -(-CCs_d_width(i1,i1).*E(i2,i2) -  CCs_d_width(i2,i2).*E(i1,i1) + 2 * Cs_d_width(i1,i1).*Cs_d_width(i2,i2));
  

 
 