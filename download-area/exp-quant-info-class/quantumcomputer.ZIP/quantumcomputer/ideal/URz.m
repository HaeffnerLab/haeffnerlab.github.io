function u = URz(th,ion,mode,transition,hspace)

%URz(th,ion,mode,transition,hspace)
%URz  Z rotation.
%
%  U = URz(th,{ion},{mode},{transition},{hspace}) returns the matrix
%  of a z operation including decoherence. ion can either
%  indicate which ion or can be a vector specifying the addressing
%  error. transition specifies the type of the transition (1: d->s 2: d->a 3: s->a ).
%
%  See also UCAR, URED, UBlue

% File:   URz.m
% Date:   16-Jan-05
% Author: Kihwan Kim <Kihwan.Kim@uibk.ac.at>

global decoherences;

if(exist('hspace')==0)
   global hspace;
end;

if(exist('ion')==0)
   ion=1;
end;

if(length(ion)<2)
   temp=ion;
   ion=zeros(1,hspace.nuions);
   ion(temp)=1;
else
    if(size(ion,1)>1)
        ion=ion'
    end;
    ion=fliplr(ion);

end;   

if(exist('mode')==0)
   mode=1;
end;

if(exist('transition')==0)
   transition=1;
end;

th=th*pi;

%z operation
phonon=eye(hspace.maxphonons+1);

zop=zeros(hspace.levels);
if(transition==1)
    zop(1,1)=1;
   	zop(2,2)=-1;
elseif(transition==2)
   	zop(1,1)=1;
    zop(3,3)=-1;
elseif(transition==3)
   	zop(2,2)=1;
    zop(3,3)=-1;
end;

%if(hspace.densitymatrixformalism)
%   sp=zeros(hspace.levels^hspace.nuions);
%	for j=hspace.nuions:-1:1
%       spp=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*sigmap),eye(hspace.levels^(j-1)));
%		sp=sp+spp;
%	end;
%	tot=kron(sp,a);
%	liou=Liouville(exp(i*phi)*tot+exp(-i*phi)*tot')+calcLrelax(decoherences,hspace);
%    u=expm(-th/2*liou);
%else

    Z=zeros(hspace.levels^hspace.nuions);
	for j=hspace.nuions:-1:1
   	ZZ=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*zop),eye(hspace.levels^(j-1)));
		Z=Z+ZZ;
    end;


    k=1;
    while(k<mode)
      	Z=kron(Z,eye(hspace.maxphonons(k)+1));
        k=k+1;
    end;
    Z=kron(Z,phonon);
    k=k+1;
    while(k<=length(hspace.maxphonons))
        Z=kron(Z,eye(hspace.maxphonons(k)+1));
     	k=k+1;
    end;
   
    u=expm(-i*th/2*Z);
%end;