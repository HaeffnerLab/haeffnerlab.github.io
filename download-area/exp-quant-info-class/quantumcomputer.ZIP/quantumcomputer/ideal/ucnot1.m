function u = Ucnot1(ions)

% u = Ucompcnot(ionaddressing)

u=Ucar(0.5,1,ions)*Uexpphase(ions)*Ucar(0.5,0,ions);


