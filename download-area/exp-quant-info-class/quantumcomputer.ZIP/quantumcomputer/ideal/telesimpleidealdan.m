totalhspace=definehspace(3,2,2);
setstatevisibility(0);

%addressing
addre=[1 0.05 0.05; 0.05 1 0.05; 0.05 0.05 1];
%addre=eye(3);

%define algorithm
algpart1=Ublue(0.5,-0.5,addre(3,:))*[1 zeros(1,hspace.dimensions-1)]';
algpart2=Ucar(0.5,0.5,addre(3,:))*Ucar(0.5,0.5,addre(2,:))*Ucar(0.5,0.5,addre(1,:))*Ublue(1,0.5,addre(2,:))*Ucar(1,-0.5,addre(2,:))*Uexpphase(addre(1,:));

%Different state preparations.
S  =algpart2                *algpart1;
D  =algpart2*Ucar(1,0,addre(1,:))    *algpart1;
SDX=algpart2*Ucar(0.5,0,addre(1,:))  *algpart1;
SDY=algpart2*Ucar(0.5,0.5,addre(1,:))*algpart1;

time=0;
teleanalysis;