function res=Useq(l)

%best 0.00226 0.00432   3.44:  0.805 0.457 2.636 0.489  (95 %)

global deviation

d1=l(1);
d2=l(3);

%p1=l(9);
%p2=l(10);
%p3=l(11);
%p4=l(12);

p1=0;
p2=0;

%d1=0;
%d2=0;
%d3=0;
%d4=0;

goal= [ 0 1 0 0 ;  
        1 0 0 0 ;
        0 0 1 0 ; 
        0 0 0 1 ; 
];

%goal=[  1  0  0  0 ;  
%        0  0  0  1 ;
%        0  0  1  0 ; 
%        0  1  0  0 ; 
%];
bestaddr=0.1;
a1=[1 min(max(l(2),bestaddr),1/bestaddr)];
a2=[1 min(max(l(4),bestaddr),1/bestaddr)];

pu=Ucar(0.5,1.5,[1 0.1])*Ublue(d1,0.5+p1,a1)*Ublue(d2,0.5+p2,a2)*Ucar(0.5,0.5,[1 0.1]);

le=sum(max(abs(l(1:2:length(l))),abs(l(1:2:length(l)).*l(2:2:length(l)))));
if deviation==1
   restemp=sum(sum(abs(goal).*(abs(proj(pu)-goal).^2)));
   res=restemp+sum(max(max(max(-l(2:2:length(l))+bestaddr,0),max(l(2:2:length(l))-1/bestaddr,0)),0))+le*0.0006;   % add penalty for out of range
   fprintf('%1.5f %1.5f   %1.2f:  ',restemp,res,le)
   fprintf('%1.3f ',l)
   fprintf('\n')
else
   fprintf('Length: %1.3f \pi\n',le)
   res=pu;
end;
