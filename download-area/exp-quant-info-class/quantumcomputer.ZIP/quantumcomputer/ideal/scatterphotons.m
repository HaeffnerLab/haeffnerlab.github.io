      def=zeros(1,n+1);
   	def(1)=1;   % defect between atom 0 and the first one.
   	def(n+1)=1;
 %  	def(round(1:(n/defects(de)):n))=ones(1,length(round(1:n/defects(de):n)));
 		for(m=1:defects(de))
          l=round(rand(1)*(n-1)+2);
          while(def(l)==1)
             l=round(rand(1)*(n-1)+2);
          end;
    		 def(l)=1;
    	end;
 %%%def(6)=1;
 %%%def(7)=1;
 
 		exc=zeros(1,n);
      hit=zeros(1,n);
      for(p=1:scatteredphotons)

 			decatom=round(rand(1)*(n-1)+1);
         if(hit(decatom)==0)
            hit(decatom)=1;
            exc(decatom)=(pn5*0.5);           % if phase of second pi/2 pulse equal to 0.5 pi
           	if(def(decatom)==0)
               	hit(decatom-1)=1;
         			exc(decatom-1)=0.5;
        		end;
            if(def(decatom+1)==0)
              	 	hit(decatom+1)=1;
         			exc(decatom+1)=0.5;
            end;
         end;
      end;
%      max(exc)
      excitations(k)=sum(exc);