function res=Useq(l)

global deviation


pu=Ublue(l(1),l(2))*Ublue(l(3),l(4))*Ublue(l(5),l(6));%*Ublue(l(7),l(8));%*Ublue(l(9),l(10));%*Ublue(l(11),l(12))*Ublue(l(13),l(14))*Ublue(l(15),l(16));


pup=diag(proj(pu))';

if deviation==1
   res=abs(sum(abs(pup))-4)+abs(abs(angle(pup(1))+angle(pup(4))-angle(pup(3))-angle(pup(2)))-pi)+0.04*max(sum(abs(l(1:2:length(l))))-2.2,0);
   %0.04*max(sum(abs(l(1:2:length(l))))-2.2,0)
else
   res=pu;
end;
res;
