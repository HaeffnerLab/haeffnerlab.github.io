definehspace(3,3,1)

start=zeros(hspace.dimensions,1);
start(index(0,[0 0 0]))=1;
ad=eye(3);
ad=[1 0.05 0.05; 0.05 1 0.05; 0.05 0.05 1;];
dispabsmat(Ucar(1,0,ad(1,:),2)*Ublue(1,0,ad(3,:))*Ucar(1,0,ad(3,:))*Ublue(1,1,ad(1,:))*Ucar(1,1,ad(1,:))*Ucar(1,1,ad(1,:),2)*Ublue(1,0,ad(2,:))*Ucar(1,0,ad(2,:))*Ublue(0.5,0,ad(1,:))*start)