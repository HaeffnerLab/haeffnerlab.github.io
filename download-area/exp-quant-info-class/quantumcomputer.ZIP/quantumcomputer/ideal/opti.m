function bestxv=opti(fu,xv0)

global deviation
global fastmode

fastmode=1;
setstatevisibility(1);

pulses=8;
bestres=2;
for(k=1:100)
	xv0=[3/pulses 2*rand(1,pulses)];
	deviation=1;
	xv=fminsearch(fu,xv0);

	res=feval(fu,xv);

	deviation=0;

	%dispmat(feval(fu,xv))
	%dispabsmat(feval(fu,xv))


	if(res<bestres)
		bestres=res
		bestxv=xv
		fprintf('Length %d\n',pulses*xv(1));
	end;
end;
bestxv