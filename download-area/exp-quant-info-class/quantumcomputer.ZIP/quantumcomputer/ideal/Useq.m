function res=Useq(l)

global deviation

d1=l(1);
%d1=0.35;

pu=Ublue(d1,l(2))*Ublue(d1,l(3))*Ublue(d1,l(4))*Ublue(d1,l(5))*Ublue(d1,l(6))*Ublue(d1,l(7))*Ublue(d1,l(8))*Ublue(d1,l(9));
%*Ublue(d1,l(10))*Ublue(d1,l(11))*Ublue(d1,l(12))*Ublue(d1,l(13))*Ublue(d1,l(14))*Ublue(d1,l(15))*Ublue(d1,l(16))*Ublue(d1,l(17));

pup=diag(proj(pu))';

if deviation==1
   res=abs(sum(abs(pup))-4)+abs(abs(pup(1)+pup(4)-pup(3)-pup(2))-2)+0.1*sum(abs(d1));
else
   res=pu;
end;
res;
