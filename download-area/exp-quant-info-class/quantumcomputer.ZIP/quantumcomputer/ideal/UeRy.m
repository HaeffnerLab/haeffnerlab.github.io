%

function u = UeRy

u=Ucar(0.5,0.5);
