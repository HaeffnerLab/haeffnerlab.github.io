function u = Ublue(th,phi,det,ion,mode,transition,hspace)
%UBLUE  blue sideband pulse.
%
%  U = UBLUE(th,phi,detuning,{ion},{mode},{transition},{hspace}) returns the matrix
%  of a blue sideband pulse including decoherence. ion can either
%  indicate which ion or can be a vector specifying the addressing
%  error. transition specifies the type of the transition (1: s->d 2: s->a 3: d->a ).
%
%  See also UBLUE, UCAR, URED.

% File:   Ublue.m
% Date:   21-Sep-02
% Author: H. H�fner <Hartmut.Haeffner@uibk.ac.at>

global decoherences;

if(exist('hspace')==0)
   global hspace;
end;

if(exist('ion')==0)
   ion=1;
end;
if(length(ion)<2)
   temp=ion;
   ion=zeros(1,hspace.nuions);
   ion(temp)=1;
end;

if(exist('mode')==0)
   mode=1;
end;

if(exist('transition')==0)
   transition=1;
end;
th=th*pi;
phi=phi*pi;
det=det*pi;

%annihilation operator
a=zeros(hspace.maxphonons+1);
for j=2:hspace.maxphonons+1
	a(j-1,j)=1*sqrt(j-1);
end

% sigma-plus
sigmap=zeros(hspace.levels);
if(transition==1)
   sigmap(1,2)=1;
elseif(transition==2)
   sigmap(1,3)=1;
elseif(transition==3)
   sigmap(2,3)=1;
end;

if(hspace.densitymatrixformalism)
   	sp=zeros(hspace.levels^hspace.nuions);
	for j=hspace.nuions:-1:1
   		spp=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*sigmap),eye(hspace.levels^(j-1)));
		sp=sp+spp;
	end;
	tot=kron(sp,a);
	liou=Liouville(exp(i*phi)*tot+exp(-i*phi)*tot')+calcLrelax(decoherences,hspace);
   	u=expm(-th/2*liou);
else
	sp=zeros(hspace.levels^hspace.nuions);
	for j=hspace.nuions:-1:1
   		spp=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*sigmap),eye(hspace.levels^(j-1)));
		sp=sp+spp;
   	end;

   	k=length(hspace.maxphonons);
   	while(k>mode)
      		sp=kron(sp,eye(hspace.maxphonons(k)+1));
   		k=k-1;
   	end;
   	sp=kron(sp,a);
   	k=k-1;
   	while(k>0)
      		sp=kron(sp,eye(hspace.maxphonons(k)+1));
     		k=k-1;
   	end;
	u=expm(i*th/2*(exp(i*phi)*sp+exp(-i*phi)*sp'));
end;
