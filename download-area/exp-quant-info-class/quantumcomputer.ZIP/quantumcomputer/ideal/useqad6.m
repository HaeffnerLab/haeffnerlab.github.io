function res=Useq(l)

% best:  0.659 0.691 0.395 0.107 0.322 0.100 0.722 1.036 0.641 0.100 0.753 0.601

global deviation

d1=l(1);
d2=l(3);
d3=l(5);
d4=l(7);
d5=l(9);
d6=l(11);


%p1=l(5);
%p2=l(6);
%p3=l(7);
%p4=l(8);

goal= [ -1 0 0 0 ;  
        0 1 0 0 ;
        0 0 1 0 ; 
        0 0 0 1 ; 
];

%goal=[  1  0  0  0 ;  
%        0  0  0  1 ;
%        0  0  1  0 ; 
%        0  1  0  0 ; 
%];
bestaddr=0.1;
a1=[1 min(max(l(2),bestaddr),1/bestaddr)];
a2=[1 min(max(l(4),bestaddr),1/bestaddr)];
a3=[1 min(max(l(6),bestaddr),1/bestaddr)];
a4=[1 min(max(l(8),bestaddr),1/bestaddr)];
a5=[1 min(max(l(10),bestaddr),1/bestaddr)];
a6=[1 min(max(l(12),bestaddr),1/bestaddr)];
%CZ-composite
%pu=Ucar(d4,1+p4,a1)*Ublue(d3,1+p3,a1)*Ublue(1,0,a1)*Ucar(0.5,1.5,a2)*Ublue(1,0,a2)*Ublue(1/sqrt(2),0.5,a2)*Ublue(1,0,a2)*Ublue(1/sqrt(2),0.5,a2)*Ucar(0.5,0.5,a2)*Ublue(1,0,a1)*Ublue(d1,p1,a1)*Ucar(d2,1+p2); 

pu=Ublue(d1,0.5,a1)*Ublue(d2,0.5,a2)*Ublue(d3,0.5,a3)*Ublue(d4,0.5,a4)*Ublue(d5,0.5,a5)*Ublue(d6,0.5,a6);

if deviation==1
   res=sum(sum(abs(goal).*(abs(proj(pu)-goal).^2)));
   fprintf('%1.5f        ',res)
   fprintf('%1.3f ',l)
   fprintf(' \n');
else
   fprintf('Length: %1.3f \n',sum(max(abs(l(1:2:11)),abs(l(1:2:11).*l(2:2:12)))))
   res=pu;
end;
res=res+sum(max(max(max(-l(2:2:12)+bestaddr,0),max(l(2:2:12)-1/bestaddr,0)),0));   % add penalty for out of range

