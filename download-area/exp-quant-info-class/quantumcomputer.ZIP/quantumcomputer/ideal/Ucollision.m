 
function Ucollision = Ucollision(phaseevolution,edges,hspace)

% UCOLLISION   Cluster states.
% UCOLLISION(phaseevolution,edges,hspace)
%    edges is a vector indicating where the defects are. n means that 
%    the defects is between the n-1th and nth atom.

if(exist('hspace')==0)
   global hspace;
end;

if(exist('edges')==0)
   edges=[1,log2(hspace.dimensions)+1];
end;

if(hspace.levels>2)
   fprintf('Do not know what to do!\n')
end;
for i0=1:hspace.dimensions
   [p,qu]=quantumnumbers(i0,hspace);
   su=0;
   for k=1:(length(edges)-1)
      su=su+sum(max(qu(edges(k)+1:(edges(k+1)-1))-qu(edges(k):(edges(k+1)-1-1)),0));
   end;
   Ucollision(i0,i0)=phaseevolution^(su);
end;
