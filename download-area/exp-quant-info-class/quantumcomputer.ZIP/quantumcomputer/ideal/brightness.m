function b=brightness(state,hspace)

%BRIGHTNESS   brightness of a state
% b=brightness(state,hspace)
if(exist('hspace')==0)
   global hspace;
end;

for i0=1:hspace.dimensions
   [p,qu]=quantumnumbers(i0,hspace);
   br(i0)=mean(qu);
end;
b=1-mean(br.*abs(state').^2)/mean(abs(state').^2);
plot(1:hspace.dimensions,br.*max(sign(abs(state')-0.001),0))

std(br.*max(sign(abs(state')-0.001),0))