function res=Useq(l)

% best:      1.757 0.400 0.315 1.578 0.922 0.100 0.490 0.998 
%  or: 0.00068 0.00278   3.47:  1.788 0.440 0.452 1.012 0.687 0.100 0.539 0.775 
global deviation

d1=l(1);
d2=l(3);
d3=l(5);
d4=l(7);

%p1=l(9);
%p2=l(10);
%p3=l(11);
%p4=l(12);

p1=0;
p2=0;
p3=0;
p4=0;


%d1=0;
%d2=0;
%d3=0;
%d4=0;

goal= [ -1 0 0 0 ;  
        0 1 0 0 ;
        0 0 1 0 ; 
        0 0 0 1 ; 
];

%goal=[  1  0  0  0 ;  
%        0  0  0  1 ;
%        0  0  1  0 ; 
%        0  1  0  0 ; 
%];
bestaddr=0.1;
a1=[1 min(max(l(2),bestaddr),1/bestaddr)];
a2=[1 min(max(l(4),bestaddr),1/bestaddr)];
a3=[1 min(max(l(6),bestaddr),1/bestaddr)];
a4=[1 min(max(l(8),bestaddr),1/bestaddr)];
%CZ-composite
%pu=Ucar(d4,1+p4,a1)*Ublue(d3,1+p3,a1)*Ublue(1,0,a1)*Ucar(0.5,1.5,a2)*Ublue(1,0,a2)*Ublue(1/sqrt(2),0.5,a2)*Ublue(1,0,a2)*Ublue(1/sqrt(2),0.5,a2)*Ucar(0.5,0.5,a2)*Ublue(1,0,a1)*Ublue(d1,p1,a1)*Ucar(d2,1+p2); 

pu=Ublue(d1,0.5+p1,a1)*Ublue(d2,0.5+p2,a2)*Ublue(d3,0.5+p3,a3)*Ublue(d4,0.5+p4,a4);

le=sum(max(abs(l(1:2:8)),abs(l(1:2:8).*l(2:2:8))));
if deviation==1
   restemp=sum(sum(abs(goal).*(abs(proj(pu)-goal).^2)));
   res=restemp+sum(max(max(max(-l(2:2:8)+bestaddr,0),max(l(2:2:8)-1/bestaddr,0)),0))+le*0.0006;   % add penalty for out of range
   fprintf('%1.5f %1.5f   %1.2f:  ',restemp,res,le)
   fprintf('%1.3f ',l)
   fprintf('\n')
else
   fprintf('Length: %1.3f \pi\n',le)
   res=pu;
end;
