totalhspace=definehspace(3,2,2);
setstatevisibility(0);


%addressing
addre=[1 0.05 0.05; 0.05 1 0.05; 0.05 0.05 1];
addre=eye(3);

spinecho1=1;
spinecho3=1;

det=350;

det=0;

time=[
   1
   45.7866
   57.6561
   80.3952
   92.2648
  103.1344
  165.0579
  252.6310
  314.5546
  403.1277
  425.8668
  514.4399
  526.3095
  538.1790
  850
  980
  inf
  inf
  inf
  1000
  1020
  1040
  1060
]*10^-6;

dphi=2*pi/pi*det*time;


%define algorithm
algpart1=Ublue(0.5,-0.5+dphi(1),addre(3,:))*[1 zeros(1,hspace.dimensions-1)]';
algpart2=Ucar(0.5,spinecho3+0.5+dphi(16),addre(3,:))*Ucar(spinecho1,1.5+dphi(14),addre(1,:))*Ucar(spinecho3,0.5+dphi(13),addre(3,:))*Ucar(0.5,0.5+dphi(13),addre(2,:))*Ucar(0.5,0.5+dphi(12),addre(1,:))*Ublue(1,0.5+dphi(11),addre(2,:))*Ucar(1,-0.5+dphi(10),addre(2,:))*Ucar(spinecho1,0.5+dphi(10),addre(1,:))*Ublue(1,0+dphi(9),addre(1,:))*Ublue(1/sqrt(2),0.5+dphi(8),addre(1,:))*Ublue(1,0+dphi(7),addre(1,:))*Ublue(1/sqrt(2),0.5+dphi(6),addre(1,:));

%Different state preparations.
S  =algpart2                *algpart1;
D  =algpart2*Ucar(1,0+dphi(2),addre(1,:))    *algpart1;
SDX=algpart2*Ucar(0.5,0+dphi(2),addre(1,:))  *algpart1;
SDY=algpart2*Ucar(0.5,0.5+dphi(2),addre(1,:))*algpart1;

teledetanalysis;