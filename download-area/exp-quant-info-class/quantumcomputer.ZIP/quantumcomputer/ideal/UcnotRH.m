function u = UcnotCR(ions)

% u = Ucompcnot(ionaddressing)

l=[0.5    1    sqrt(2)    0.5    0.5    0];

pu=Ublue(0.5,1,ions)*Ublue(sqrt(2),0.5,ions)*Ublue(0.5,0,ions);

ang=acos(-real(exp(pi/2*i*sqrt(2))))/pi;
u=Ucar(0.5,1+ang,ions)*pu*Ucar(0.5,0,ions);
u=pu;