function u = Ucar(th,phi,ion,transition,hspace)
%UCAR   carrier pulse.
%   u = UCAR(th,phi,{ion},{transition},{hspace}) returns the matrix
%   descibing a carrier pulse. If hspace.densitymatrixformalism set to true
%   it includes decoherence, specified in the global variable decoherences.frefluct.
%
%   Ion can either indicate which ion or can be a vector specifying the addressing error.
%   Transition specifies the type of the transition (1: D->S 2: D->a 3: S->a ).
%
%   See also URED, UBLUE.

% File:   Ucar.m
% Date:   23-Dec-02
% Author: H. H�fner <Hartmut.Haeffner@uibk.ac.at>

global decoherences;

if(exist('hspace')==0)
   global hspace;
end;

if(exist('ion')==0)
   ion=1;
end;

if(length(ion)<2)
   temp=ion;
   ion=zeros(1,hspace.nuions);
   ion(temp)=1;
else
    if(size(ion,1)>1)
        ion=ion'
    end;
    ion=fliplr(ion);
end;
if(exist('transition')==0)
   transition=1;
end;

th=th*pi;
phi=phi*pi;

% sigma-plus
sigmap=zeros(hspace.levels);
if(transition==1)
   sigmap(1,2)=1;
elseif(transition==2)
   sigmap(1,3)=1;
elseif(transition==3)
   sigmap(2,3)=1;
end;

if(hspace.densitymatrixformalism)
   sp=zeros(hspace.levels^hspace.nuions);
	for j=hspace.nuions:-1:1
   	spp=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*sigmap),eye(hspace.levels^(j-1)));
		sp=sp+spp;
   end;
   tot=kron(sp,eye(hspace.maxphonons+1));
   liou=Liouville(exp(i*phi)*tot+exp(-i*phi)*tot')+calcLrelax(decoherences,hspace);
   u=expm(-th/2*liou);
else
   sp=zeros(hspace.levels^hspace.nuions);
	for j=hspace.nuions:-1:1
   	spp=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*sigmap),eye(hspace.levels^(j-1)));
		sp=sp+spp;
   end;
   for(k=1:length(hspace.maxphonons))
      sp=kron(sp,eye(hspace.maxphonons(k)+1));
   end;
   u=expm(i*th/2*(exp(i*phi)*sp+exp(-i*phi)*sp'));
end;
