
for(nuions=2:6)
   clusterdec4;
	onions(nuions)=mean(mean(mean(mean(excitation))));
end;