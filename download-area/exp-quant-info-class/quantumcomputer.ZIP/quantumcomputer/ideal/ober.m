nuio=8;

definehspace(nuio,2,0)

re=ucar(0.5,0,ones(1,nuio))*[1; zeros(2^nuio-1,1)];
re=ucar(0.5,0,ones(1,nuio))*ucar(0.5,0,exp(i*pi/2*[0:nuio-1]))*Ucollision(-1)*re;

dispmat(re)
 
