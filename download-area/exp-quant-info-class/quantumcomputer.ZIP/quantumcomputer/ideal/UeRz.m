%

function u = UeRz

u=Ucar(0.5,0)*Ucar(1,0.5)*Ucar(0.5,1);
