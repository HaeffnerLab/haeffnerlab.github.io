function u = Ucnot(ion1,ion2)

% u = Ucnot(ionaddressing)

u=Ublue(1,1,ion1)*Ucnot1(ion2)*Ublue(1,0,ion1);


