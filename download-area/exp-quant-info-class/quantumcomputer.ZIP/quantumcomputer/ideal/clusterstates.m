definehspace(nuions,2,0);
on=ones(1,log2(hspace.dimensions));
uc1=Ucar(0.5,0.5,[on]);
uc2=Ucar(0.5,0,[on]);


%OP=(Ucar(0.5,0.5,[exp(i*pi/2*[1:log2(hspace.dimensions)]).*on])*uc2*Ucollision(-1)*uc1);
%OP=uc1;

y0=[1; zeros(hspace.dimensions-1,1)];
%re=OP*y0;
re=Ucar(0.5,0,[on])*Ucollision(-1)*Ucar(0.5,0.5,[on])*y0;
vec1=zeros(hspace.dimensions,1);
vec2=zeros(hspace.dimensions,1);
for(k=1:hspace.dimensions)
   [p,el]=quantumnumbers(k);
   if(el(4)==1)
      vec2(k)=re(k);
   else
      vec1(k)=re(k);
   end;
end;
%dispmat(re)
%dispmat(vec1)
%dispmat(vec2)
%dispmat(OP'*vec1)
%dispmat(OP'*vec2)
dispmat(Ucar(0.5,1.5,[on])*Ucollision(-1)*Ucar(0.5,1,[on])*re)
dispmat(Ucar(0.5,1.5,[on])*Ucollision(-1)*Ucar(0.5,1,[on])*vec1)
dispmat(Ucar(0.5,1.5,[on])*Ucollision(-1)*Ucar(0.5,1,[on])*vec2)
