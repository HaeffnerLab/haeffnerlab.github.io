function u = Ucardec(th,phi,ion,transition,hspace)
%u = UCARDEC(th,phi,{ion},{transition},{hspace})
%
%Returns the matrix of a carrier pulse including some decoherence. 
%Ion can either indicate which ion or can be a vector specifying the addressing error. 
%Transition specifies the type of the transition (1: s->d 2: s->a 3: d->a ).
%
%see also UCAR, URED, UBLUE.

% File:   Ucardec.m
% Date:   23-Dec-02
% Author: H. H�ffner <Hartmut.Haeffner@uibk.ac.at>

if(exist('hspace')==0)
   global hspace;
end;

if(exist('ion')==0)
   ion=1;
end;
if(length(ion)<2)
   temp=ion;
   ion=zeros(1,hspace.nuions);
   ion(temp)=1;
end;   
if(exist('transition')==0)
   transition=1;
end;

th=th*pi;
phi=phi*pi;

% sigma-plus
sigmap=zeros(hspace.levels);
if(transition==1)
   sigmap(1,2)=1;
elseif(transition==2)
   sigmap(1,3)=1;
elseif(transition==3)
   sigmap(2,3)=1;
end;

if(hspace.densitymatrixformalism) 
   sp=zeros(hspace.levels^hspace.nuions);
	for j=hspace.nuions:-1:1
   	spp=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*sigmap),eye(hspace.levels^(j-1)));
		sp=sp+spp;
   end;
   tot=kron(sp,eye(hspace.maxphonons+1));
   decoherences = struct('frefluct',0.2,'det_frefluct',[0*2*pi*1000,1],'intensity_fluctuations',0);
	liou=Liouville(exp(i*phi)*tot+exp(-i*phi)*tot')+calcLrelax(decoherences,hspace);
   u=expm(-th/2*liou);
else
   sp=zeros(hspace.levels^hspace.nuions);
	for j=hspace.nuions:-1:1
   	spp=kron(kron(eye(hspace.levels^(hspace.nuions-j)),ion(j)*sigmap),eye(hspace.levels^(j-1)));
		sp=sp+spp;
   end;
   tot=kron(sp,eye(hspace.maxphonons+1));
   u=expm(i*th/2*(exp(i*phi)*tot+exp(-i*phi)*tot'));
end;