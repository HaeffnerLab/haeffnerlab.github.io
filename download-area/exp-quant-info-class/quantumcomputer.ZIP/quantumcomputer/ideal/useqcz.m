function res=Useq(l)

global deviation

d1=l(1);
d2=l(2);
d3=l(3);
d4=l(4);


p1=l(5);
p2=l(6);
p3=l(7);
p4=l(8);

goal=[1 0 0 0 ;  
       0 -1 0 0 ;
       0 0 1 0 ; 
       0 0 0 1 ; 
];

goal=[  1  0  0  0 ;  
        0  0  0  1 ;
        0  0  1  0 ; 
        0  1  0  0 ; 
];
a1=[1 0.1];
a2=[0.1 1];
   
pu=Ucar(d4,1+p4,a1)*Ublue(d3,1+p3,a1)*Ublue(1,0,a1)*Ucar(0.5,1.5,a2)*Ublue(1,0,a2)*Ublue(1/sqrt(2),0.5,a2)*Ublue(1,0,a2)*Ublue(1/sqrt(2),0.5,a2)*Ucar(0.5,0.5,a2)*Ublue(1,0,a1)*Ublue(d1,p1,a1)*Ucar(d2,1+p2); 
if deviation==1
   res=max(max(abs(goal).*(abs(proj(pu)-goal).^2)));
   fprintf('%1.5f        ',res)
   fprintf('%1.3f ',l)
   fprintf(' \n');
else
   res=pu;
end;
res;

