function u = Uexpphase(ions)

%UEXPPHASE(ion)

u=Ublue(1,0,ions)*Ublue(1/sqrt(2),0.5,ions)*Ublue(1,0,ions)*Ublue(1/sqrt(2),0.5,ions);


