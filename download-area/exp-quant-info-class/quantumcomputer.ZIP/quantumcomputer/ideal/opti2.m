function bestxv=opti(fu,xv0)

global deviation
global fastmode

fastmode=1;
definehspace(1,2);
setstatevisibility(1);

pulses=3;
bestres=2;
for(k=1:8)
	xv0=[2*rand(1,2*pulses)];
	xv0(1:2:2*pulses)=xv0(1:2:2*pulses)*2.5/pulses/2;
	deviation=1;
	xv=fminsearch(fu,xv0);

	res=feval(fu,xv);

	deviation=0;

	%dispmat(feval(fu,xv))
	%dispabsmat(feval(fu,xv))


	if(res<bestres)
		bestres=res
		bestxv=xv
		fprintf('Length %d\n',sum(abs(xv(1:2:2*pulses))));
	end;
end;
bestxv
dispmat(feval(fu,bestxv))
dispabsmat(feval(fu,bestxv))
