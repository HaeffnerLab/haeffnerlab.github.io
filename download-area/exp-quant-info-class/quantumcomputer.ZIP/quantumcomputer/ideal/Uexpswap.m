function U=Uexpswap

th=1/sqrt(2)*pi;
dp=acos(cos(th)*(1+cos(2*th))/(sin(th)*sin(2*th)))/pi;
%po= 0.02785;
po=0;

U=Ublue(1/sqrt(2),po)*Ublue(2/sqrt(2),dp+po)*Ublue(1/sqrt(2),po);