edges=[1,nuions+1];
feval(scr);
mexc(1)=mean(mean(mean(mean(excitation))));
edg(1,1:length(edges))=edges;


edges=[1,round(nuions/2+1),nuions+1];
feval(scr);
mexc(2)=mean(mean(mean(mean(excitation))));
edg(2,1:length(edges))=edges;

%edges=[1,round(nuions/3+1),round(nuions*2/3+1),nuions+1];
%feval(scr);
%mexc(3)=mean(mean(mean(mean(excitation))));
%edg(3,1:length(edges))=edges;

%edges=[1,round(nuions/4+1),round(nuions*2/4+1),round(nuions*3/4+1),nuions+1];
%feval(scr);
%mexc(4)=mean(mean(mean(mean(excitation))));
%edg(4,1:length(edges))=edges;


mexc

mexc(1)/mexc(2)
