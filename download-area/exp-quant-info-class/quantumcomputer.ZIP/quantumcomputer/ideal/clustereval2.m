n=100;

excitations=0;
mexc=0;
defects=0;
res=3;
for(de=1:res*log(n)+1)
   defects(de)=min(round(exp(de/res))-1,n-1);
   for(k=1:	50000/sqrt(scatteredphotons))
 		scatterphotons;
   end;
   mexc(de)=mean(excitations);
end;

figure(1)
plot((n)./(defects(2:length(defects))+1),mexc(2:length(defects)),'k*-');
axis([1 30 max(mexc)*0.8 max(mexc)*1.001] )
xlabel('Average number of atoms linked')
ylabel('Mean excitation  \chi_{exp}')

figure(2)
plot(defects,mexc,'k*-');
xlabel('# defects')
ylabel('Mean excitation  \chi_{exp}')