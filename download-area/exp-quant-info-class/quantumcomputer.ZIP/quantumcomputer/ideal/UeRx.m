%

function u = UeRx

u=Ucar(0.5,0);
