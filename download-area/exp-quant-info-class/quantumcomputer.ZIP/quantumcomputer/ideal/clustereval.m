n=60;

exc=1.5*ones(1,n);

for(defects=1:n)
   exc(defects)=max(exc(defects)-0.5,0.5);
   exc(defects+1)=max(exc(defects)-0.5,0.5);
   mexc(defects)=mean(exc);
end;

plot((1:n),mexc);
%axis([1 60 1.3 1.5])
xlabel('Atoms entangled')
ylabel('Mean excitation')