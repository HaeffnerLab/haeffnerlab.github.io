clear Sproj;
clear Dproj;
clear SDXproj;
clear SDYproj;

%Bell state measurement
for(k=1:hspace.dimensions)
   [ph,el]=quantumnumbers(k);
   if(el(1:2)==[1 1])
      cas=1;
   elseif(el(1:2)==[0 1])
      cas=2;
   elseif(el(1:2)==[1 0])
      cas=3;
   elseif(el(1:2)==[0 0])
      cas=4;
   end;   
   
   Sproj(k,cas)=S(k);
   Dproj(k,cas)=D(k);
   SDXproj(k,cas)=SDX(k);
   SDYproj(k,cas)=SDY(k);
end;

X=Ucar(1,0+dphi(20),addre(3,:));
Z=Ucar(1,0.5+dphi(22),addre(3,:))*Ucar(1,0+dphi(21),addre(3,:));

FinalPulse=eye(totalhspace.dimensions);

% reconstruction
clear rec;

rec(1,:,:)=eye(totalhspace.dimensions);
rec(2,:,:)=Z;
rec(3,:,:)=X;
rec(4,:,:)=X*Z;    

%analysis
fidelity=[0 0 0 0];

%fprintf('\n\n\n----------------------------------------\n')
%dispmat((Ucar(0,0,1)*[1 zeros(1,hspace.dimensions-1)]'))
%fprintf('-----------------------------------------\n')
for(cas=1:4)
   dispmat((squeeze(rec(cas,:,:))*Sproj(:,cas)));
   ab=abs(proj(FinalPulse*squeeze(rec(cas,:,:))*Sproj(:,cas))).^2;
	fidelity(1)=fidelity(1)+sum(ab(1:4));
end;

%fprintf('\n\n\n----------------------------------------\n')
%dispmat((Ucar(1,0,1)*[1 zeros(1,hspace.dimensions-1)]'))
%fprintf('-----------------------------------------\n')
for(cas=1:4)
	dispmat(squeeze(rec(cas,:,:))*Dproj(:,cas));
   ab=abs(proj(FinalPulse*Ucar(1,1+dphi(23),addre(3,:))*squeeze(rec(cas,:,:))*Dproj(:,cas))).^2;
	fidelity(2)=fidelity(2)+sum(ab(1:4));
end;

%fprintf('\n\n\n----------------------------------------\n')
%dispmat((Ucar(0.5,0,3)*[1 zeros(1,hspace.dimensions-1)]'))
%fprintf('-----------------------------------------\n')
for(cas=1:4)
	dispmat(squeeze(rec(cas,:,:))*SDXproj(:,cas));
   ab=abs(proj(FinalPulse*Ucar(0.5,1+dphi(23),addre(3,:))*squeeze(rec(cas,:,:))*SDXproj(:,cas))).^2;
%   dispmat(squeeze(rec(cas,:,:))*SDXproj(cas,:)')
	fidelity(3)=fidelity(3)+sum(ab(1:4));
end;

%fprintf('\n\n\n----------------------------------------\n')
%dispmat((Ucar(0.5,0.5,1)*[1 zeros(1,hspace.dimensions-1)]'))
%fprintf('-----------------------------------------\n')
for(cas=1:4)
	dispmat(squeeze(rec(cas,:,:))*SDYproj(:,cas));
   ab=abs(proj(FinalPulse*Ucar(0.5,1.5+dphi(23),addre(3,:))*squeeze(rec(cas,:,:))*SDYproj(:,cas))).^2;
	fidelity(4)=fidelity(4)+sum(ab(1:4));
end;

fidelity

sum(fidelity)/4
