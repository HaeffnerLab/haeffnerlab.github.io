clear excitation;
clear el;

definehspace(nuions,2,0);

on=ones(nuions,1);
%OP=ucar(0.5,0,exp(i*pi/2*[1:nuions]))*ucar(0.5,0.5,on)*Ucollision(-1,edges)*ucar(0.5,0,on);
%OP=Ucollision(-1,edges)*ucar(0.5,0,on);
OP=ucar(0.5,0.5,on)*Ucollision(-1,edges)*ucar(0.5,0,on);
%OP=ucar(0.5,0,on)*Ucollision(-1,edges)*ucar(0.5,0,on);
%OP=ucar(0.5,0.5,exp(i*pi/2*[1:nuions]));
cluster=OP*[1;zeros(hspace.dimensions-1,1)];

%dispmat(ucar(0.5,0,[1 i -1 -i 1])*cluster)

for(decion1=1:nuions)
   decion1
   	   vec=zeros(hspace.dimensions,2);
  			for(k=1:hspace.dimensions)
            [ph,el(k,1:nuions)]=quantumnumbers(k);
   	    	vec(k,1+el(k,decion1)*2^0)=cluster(k);
         end;
         res=OP'*vec;
	hspace.visible=(abs(res(:,1))>0.000001);
   if(sum(hspace.visible))
      dispmat(res(:,1))
   end;
   hspace.visible=(abs(res(:,2))>0.000001);
	if(sum(hspace.visible))
      dispmat(res(:,2))
   end;
   
   temp=sum(sum(el'*abs(res).^2));
			excitation(decion1)=temp;

end;