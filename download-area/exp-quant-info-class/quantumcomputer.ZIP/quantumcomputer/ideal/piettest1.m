hspace=definehspace(2,2,3);
setstatevisibility(1,[2 2],hspace)
istate=state([0 0 0],[1 1],hspace);
U=Ublue(1,1,2)*Ublue(1/2,0,1)*Ucar(1,3/2,2);

dispmat(U*istate)
