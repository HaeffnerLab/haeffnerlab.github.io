totalhspace=definehspace(3,2,2);
setstatevisibility(0);

%addressing
addre=[1 0.05 0.05; 0.05 1 0.05; 0.05 0.05 1];
%addre=eye(3);

%define algorithm
algpart1=Ublue(0.5,0,addre(3,:))*[1 zeros(1,hspace.dimensions-1)]';
algpart2=Ucar(0.5,0,addre(2,:))*Ublue(1,0,addre(2,:))*Ucar(1,0,addre(2,:))*Ucnot1(addre(1,:));

%Different state preparations.
S  =algpart2                *algpart1;
D  =algpart2*Ucar(1,0,addre(1,:))    *algpart1;
SDX=algpart2*Ucar(0.5,0,addre(1,:))  *algpart1;
SDY=algpart2*Ucar(0.5,0.5,addre(1,:))*algpart1;

clear Sproj;
clear Dproj;
clear SDXproj;
clear SDYproj;

%Bell state measurement
for(k=1:hspace.dimensions)
   [ph,el]=quantumnumbers(k);
   if(el(1:2)==[0 0])
      cas=1;
   elseif(el(1:2)==[1 0])
      cas=2;
   elseif(el(1:2)==[0 1])
      cas=3;
   elseif(el(1:2)==[1 1])
      cas=4;
   end;   
   
   Sproj(k,cas)=S(k);
   Dproj(k,cas)=D(k);
   SDXproj(k,cas)=SDX(k);
   SDYproj(k,cas)=SDY(k);
end;

X=Ucar(1,0,addre(3,:));
Z=Ucar(0.5,1,addre(3,:))*Ucar(1,0.5-0,addre(3,:))*Ucar(0.5,0,addre(3,:));

% reconstruction
clear rec;

rec(1,:,:)=X;
rec(2,:,:)=Z;
rec(3,:,:)=X*Z;
rec(4,:,:)=X*X;    % identity works as well up to a global phase!


%analysis
phi=0;
fidelity=[0 0 0 0];

fprintf('\n\n\n----------------------------------------\n')
dispmat((Ucar(0,0,1)*[1 zeros(1,hspace.dimensions-1)]'))
fprintf('-----------------------------------------\n')
for(cas=1:4)
   dispmat((squeeze(rec(cas,:,:))*Sproj(:,cas)))
   ab=abs(proj(squeeze(rec(cas,:,:))*Sproj(:,cas))).^2;
	fidelity(1)=fidelity(1)+sum(ab(1:4));
end;

fprintf('\n\n\n----------------------------------------\n')
dispmat((Ucar(1,0,1)*[1 zeros(1,hspace.dimensions-1)]'))
fprintf('-----------------------------------------\n')
for(cas=1:4)
	dispmat(squeeze(rec(cas,:,:))*Dproj(:,cas))
   ab=abs(proj(Ucar(1,1,addre(3,:))*squeeze(rec(cas,:,:))*Dproj(:,cas))).^2;
	fidelity(2)=fidelity(2)+sum(ab(1:4));
end;

fprintf('\n\n\n----------------------------------------\n')
dispmat((Ucar(0.5,0,3)*[1 zeros(1,hspace.dimensions-1)]'))
fprintf('-----------------------------------------\n')
for(cas=1:4)
	dispmat(squeeze(rec(cas,:,:))*SDXproj(:,cas))
   ab=abs(proj(Ucar(0.5,1,addre(3,:))*squeeze(rec(cas,:,:))*SDXproj(:,cas))).^2;
%   dispmat(squeeze(rec(cas,:,:))*SDXproj(cas,:)')
	fidelity(3)=fidelity(3)+sum(ab(1:4));
end;

fprintf('\n\n\n----------------------------------------\n')
dispmat((Ucar(0.5,0.5,1)*[1 zeros(1,hspace.dimensions-1)]'))
fprintf('-----------------------------------------\n')
for(cas=1:4)
	dispmat(squeeze(rec(cas,:,:))*SDYproj(:,cas))
   ab=abs(proj(Ucar(0.5,1.5,addre(3,:))*squeeze(rec(cas,:,:))*SDYproj(:,cas))).^2;
	fidelity(4)=fidelity(4)+sum(ab(1:4));
end;

fidelity

sum(fidelity)/4