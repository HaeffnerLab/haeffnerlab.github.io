clear excitation;
clear el;

definehspace(nuions,2,0);

on=ones(nuions,1);
%OP=ucar(0.5,0.25,exp(i*pi/2*[1:nuions]))*ucar(0.5,0.5,on)*Ucollision(-1,edges)*ucar(0.5,0,on);
%OP=ucar(0.5,0.5,on)*Ucollision(-1,edges)*ucar(0.5,0,on);
OP=ucar(0.5,0.5,exp(i*pi/2*[1:nuions]));
cluster=OP*[1;zeros(hspace.dimensions-1,1)];

%dispmat(ucar(0.5,0,[1 i -1 -i 1])*cluster)

for(decion1=1:nuions)
   decion1
   for(decion2=decion1:nuions)
	   for(decion3=decion2:nuions)
		   vec=zeros(hspace.dimensions,8);
  			for(k=1:hspace.dimensions)
            [ph,el(k,1:nuions)]=quantumnumbers(k);
            1+el(k,decion1)*2^0+el(k,decion2)*2^1+el(k,decion3)*2^2;
   	    	vec(k,1+el(k,decion1)*2^0+el(k,decion2)*2^1+el(k,decion3)*2^2)=cluster(k);
         end;
         res=OP'*vec;
	%	hspace.visible=(abs(res1)>0.000001);
%	dispmat(res1)
%	hspace.visible=(abs(res2)>0.000001);
%	dispmat(res2)

			temp=sum(sum(el'*abs(res).^2));
			excitation(decion1,decion2,decion3)=temp;
			excitation(decion1,decion3,decion2)=temp;
         excitation(decion2,decion1,decion3)=temp;
			excitation(decion2,decion3,decion1)=temp;   
         excitation(decion3,decion1,decion2)=temp;
			excitation(decion3,decion2,decion1)=temp;   
      end;     
   end;
end;
