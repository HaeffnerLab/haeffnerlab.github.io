scatteredphotons=1;
for(decatom=1:8)
   scatterphotons
   decatom
   exc
end;