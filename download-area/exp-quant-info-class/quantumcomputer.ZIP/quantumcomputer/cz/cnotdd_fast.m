% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
parameters.ignorelightshift=1;

parameters.omegacarrier=1.5*2*pi/29.4e-6;
parameters.sbomegacarrier=2*pi/(0.157e-3*0.0176);
parameters.hspace.nuions=2;
parameters.hspace.maxphonons=3;
parameters.addressing=[1 0.05; 0.05 1];
parameters.recoilangle=68;
parameters.omegaz=2100000*2*pi;
parameters.detuning=2*pi*0e3;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
delayunit=delayunit*1.05;

fxpa1=fxpa;


fxpa2=fxpa;
fxpa2.carrierrabi=fxpa.carrierrabi/(48/30);
fxpa2.sbcarrierrabi=fxpa.sbcarrierrabi/(48/30);
fxpa2.piover2time=fxpa.piover2time*(48/30);

fxpa1sb=fxpa1;
%fxpa1sb.detuning=0*-200*2*pi*parameters.frequencyscale;

fxpa1sbv3=fxpa1;
fxpa1sbv3.carrierrabi=fxpa1.carrierrabi/(143/153);
fxpa1sbv3.sbcarrierrabi=fxpa1.sbcarrierrabi/(143/153);
fxpa1sbv3.piover2time=fxpa1.piover2time*(143/153);



fxpasb2=fxpa1;
fxpasb2.carrierrabi=fxpa1.carrierrabi/(189/153);
fxpasb2.sbcarrierrabi=fxpa1.sbcarrierrabi/(189/153);
fxpasb2.piover2time=fxpa1.piover2time*(189/153);
%*****************************************************************************%



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa2,(15)*delayunit); 
p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa2,(60)*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa1,75*delayunit); 

off=-0;
p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa1,174*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5+off,1,1,fxpa1sbv3,182*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0+off,1,1,fxpa1,time); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5+off,1,1,fxpa1sbv3,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0+off,1,1,fxpa1sb,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa2,440*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(1,1,2,1,fxpasb2,(465)*delayunit); 

% auslaufende blaue Flops
%p = p + 1;[pulse(p),time] = Rcar(1,1,2,1,fxpa1,770*delayunit); 
%p = p + 1;[pulse(p),time] = Rblue(5,1,2,1,fxpa2,(800+1)*delayunit); 

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%

[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
Tprep=78.7500;
T=T-Tprep;
displaypopulations(T,Y,[0 0; 1 0; 0 1; 1 1;],hspace);
setstatevisibility(1,hspace);
%endpopulations(T,Y,hspace);

file='0321.sca';


YTP=tracedpopulations(T,Y,hspace);
fig=figure(11);
clf;
plo=plot(repmat(T,hspace.nuions,1)',YTP);
hold on;
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')

set(plo,'LineWidth',1.5)

%dat=read_data('p:\daten\20021122\esc1026.sca',3);
dat=read_data(['p:\daten\20021213\esc',file],3);

p1=plot(dat(1,:)-Tprep,dat(2,:),'b.');
p2=plot(dat(1,:)-Tprep,dat(3,:),'g.');
set(p1,'LineWidth',1.5)
set(p1,'MarkerSize',14)
set(p2,'LineWidth',1.5)
set(p2,'MarkerSize',14)

pop1=mean(dat(2,1:10));
err1=std(dat(2,1:10))/10;
pop2=mean(dat(3,1:10));
err2=std(dat(3,1:10))/10;

%clear s;
%s(1,:)=sprintf('P_{Ion1} = %1.3f (%1.3f)',pop1,err1);
%te=text(300,0.8,s);
%set(te,'FontSize',12);
%
%s(3,:)=sprintf('P_{Ion2} = %1.3f (%1.3f)',pop2,err2);
%te=text(300,0.25,s);
%set(te,'FontSize',12);
%set(te,'Box','on')

[YPTP,statenames]=phonontracedpopulations(T,Y,[0 0; 1 0; 0 1; 1 1;],hspace);
fig=figure(12);
clf;
hold on;
%dat=read_data('p:\daten\20021122\csc1026.sca',9);
dat=read_data(['p:\daten\20021213\csc',file],9);
subplot(4,1,1)
hold on
plo1=plot(T,YPTP(:,1)','k');
p1=plot(dat(1,:)-Tprep,dat(2,:),'k.');
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')
axis([min(T) max(T) 0 1])
legend(statenames(1,:));



subplot(4,1,2)
hold on
plo2=plot(T,YPTP(:,2)','k');
p2=plot(dat(1,:)-Tprep,dat(6,:),'k.');

ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')
axis([min(T) max(T) 0 1])
legend(statenames(2,:));



subplot(4,1,3)
hold on
plo3=plot(T,YPTP(:,3)','k');
p3=plot(dat(1,:)-Tprep,dat(4,:),'k.');
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')
axis([min(T) max(T) 0 1])
legend(statenames(3,:));


subplot(4,1,4)
hold on
plo4=plot(T,YPTP(:,4)','k');
p4=plot(dat(1,:)-Tprep,dat(8,:),'k.');
axis([min(T) max(T) 0 1])
legend(statenames(4,:));
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')

set(plo1,'LineWidth',1.5)
set(plo2,'LineWidth',1.5)
set(plo3,'LineWidth',1.5)
set(plo4,'LineWidth',1.5)

set(p1,'LineWidth',1.5)
set(p1,'MarkerSize',14)
set(p2,'LineWidth',1.5)
set(p2,'MarkerSize',14)
set(p3,'LineWidth',1.5)
set(p3,'MarkerSize',14)
set(p4,'LineWidth',1.5)
set(p4,'MarkerSize',14)



finalt1=sign(max((dat(1,:)-568),0));
finalt2=sign(max((dat(1,:)-568),0));
finalt3=sign(max((dat(1,:)-568),0));
finalt4=sign(max((dat(1,:)-568),0));
s=[sprintf('|ss>: %2.2f \n',sum(finalt1.*dat(2,:)/sum(finalt1))*100)...
   sprintf('|sd>: %2.2f \n',sum(finalt2.*dat(4,:)/sum(finalt2))*100)...
   sprintf('|ds>: %2.2f \n',sum(finalt3.*dat(6,:)/sum(finalt3))*100)...
   sprintf('|dd>: %2.2f \n',sum(finalt4.*dat(8,:)/sum(finalt4))*100)...
];
s



%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;

print -depsc2 cnotdd_fast