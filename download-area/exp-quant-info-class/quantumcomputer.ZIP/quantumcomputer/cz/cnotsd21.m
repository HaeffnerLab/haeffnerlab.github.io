% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at
% edited by Mark Riebe 20041104
% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

hspace=definehspace(2,2,[3],0);
parameters=standardparameters(hspace);

 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi/42e-6;
parameters.sbomegacarrier=2*pi*265e3;

parameters.addressing=[1 0.05; 0.05 1];
parameters.recoilangle=68;
parameters.omegaz=2100000*2*pi;
parameters.detuning=2*pi*0e3;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[1 1],parameters.hspace))=1;




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
delayunit=delayunit*1.05;
fxpa1=fxpa;
fxpa1.carrierrabi=fxpa.carrierrabi*1.1;
fxpa1.sbcarrierrabi=fxpa.sbcarrierrabi*1.1;
fxpa1.piover2time=fxpa.piover2time/1.1;
fxpa2=fxpa;
%*****************************************************************************%



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa2,time+(10)*delayunit); 
%p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa2,75*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa1,100*delayunit); 

p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa1,215*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa1,240*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,2,1,fxpa1,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa1,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,2,1,fxpa1,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rcar(0.5,1,2,1,fxpa1,565*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(1,1,1,1,fxpa2,620+1*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
Tprep=100;
T=T-Tprep;
displaypopulations(T,Y,[0 0; 1 0; 0 1; 1 1;],hspace);
setstatevisibility(1,hspace);
%endpopulations(T,Y,hspace);

YTP=tracedpopulations(T,Y,hspace);
fig=figure(11);
clf;
plo=plot(repmat(T,hspace.nuions,1)',YTP);
hold on;
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')

set(plo,'LineWidth',1.5)


dat=read_data('p:\lindaten\2002\20021122\csc1101.sca',9);
p1=plot(dat(1,:)-100,dat(2,:),'b.');
p2=plot(dat(1,:)-100,dat(3,:),'g.');
set(p1,'LineWidth',1.5)
set(p1,'MarkerSize',14)
set(p2,'LineWidth',1.5)
set(p2,'MarkerSize',14)

pop1=mean(dat(2,1:10));
err1=std(dat(2,1:10))/10;
pop2=mean(dat(3,1:10));
err2=std(dat(3,1:10))/10;

%clear s;
%s(1,:)=sprintf('P_{Ion1} = %1.3f (%1.3f)',pop1,err1);
%te=text(300,0.8,s);
%set(te,'FontSize',12);
%
%s(3,:)=sprintf('P_{Ion2} = %1.3f (%1.3f)',pop2,err2);
%te=text(300,0.25,s);
%set(te,'FontSize',12);
%set(te,'Box','on')


[YPTP,statenames]=phonontracedpopulations(T,Y,[0 0; 1 0; 0 1; 1 1;],hspace);
fig=figure(12);
clf;
hold on;
subplot(4,1,1)
hold on
plo1=plot(T,YPTP(:,1)','b');
p1=plot(dat(1,:)-Tprep,dat(8,:),'ro');
ax=get(fig,'CurrentAxes');
%set(ax,'xTick',-200);
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')
axis([min(T) max(T) 0 1])
%legend(statenames(1,:));



subplot(4,1,2)
hold on
plo2=plot(T,YPTP(:,2)','b');
p2=plot(dat(1,:)-Tprep,dat(4,:),'ro');

ax=get(fig,'CurrentAxes');;
%set(ax,'xTick',-200);
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')
axis([min(T) max(T) 0 1])
%legend(statenames(2,:));



subplot(4,1,3)
hold on
plo3=plot(T,YPTP(:,3)','b');
p3=plot(dat(1,:)-Tprep,dat(6,:),'ro');
ax=get(fig,'CurrentAxes');;
%set(ax,'xTick',-200);
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')
axis([min(T) max(T) 0 1])
%legend(statenames(3,:));


subplot(4,1,4)
hold on
plo4=plot(T,YPTP(:,4)','b');
p4=plot(dat(1,:)-Tprep,dat(2,:),'ro');
axis([min(T) max(T) 0 1])
%legend(statenames(4,:));
ax=get(fig,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')

set(plo1,'LineWidth',1.5)
set(plo2,'LineWidth',1.5)
set(plo3,'LineWidth',1.5)
set(plo4,'LineWidth',1.5)

set(p1,'LineWidth',1.5)
set(p1,'MarkerSize',4)
set(p2,'LineWidth',1.5)
set(p2,'MarkerSize',4)
set(p3,'LineWidth',1.5)
set(p3,'MarkerSize',4)
set(p4,'LineWidth',1.5)
set(p4,'MarkerSize',4)

finalt1=sign(max((dat(1,:)-750),0));
finalt2=sign(max((dat(1,:)-750),0));
finalt3=sign(max((dat(1,:)-750),0));
finalt4=sign(max((dat(1,:)-750),0));
s=[sprintf('|ss>: %2.2f \n',sum(finalt1.*dat(2,:)/sum(finalt1))*100)...
   sprintf('|sd>: %2.2f \n',sum(finalt2.*dat(4,:)/sum(finalt2))*100)...
   sprintf('|ds>: %2.2f \n',sum(finalt3.*dat(6,:)/sum(finalt3))*100)...
   sprintf('|dd>: %2.2f \n',sum(finalt4.*dat(8,:)/sum(finalt4))*100)...
];
s

std(dat(2,1:7))*100
std(dat(4,1:7))*100
std(dat(6,1:7))*100
std(dat(8,1:7))*100

%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;

print -depsc2 cnotdd2