% simulates the population evolution with experimental imperfections
% Date:   03-Sep-02
% Author: Hartmut H�ffner <hartmut.haeffner@uibk.ac.at

% type <edit simulate> to specify the parameters directly in the script
% 
clear T;
clear Y;
clear pulse;

parameters=standardparameters; 

%****************** Changes to the standardparameters  ***********************%
% parameters.nolightshift=0;
parameters.omegacarrier=2*pi/42e-6;
parameters.sbomegacarrier=2*pi*265e3;
parameters.hspace.nuions=2;
parameters.hspace.maxphonons=3;
parameters.addressing=[1 0.05; 0.05 1];
parameters.recoilangle=68;
parameters.omegaz=2100000*2*pi;
parameters.detuning=2*pi*0e3;

%*****************************************************************************%
parameters=recalculateparameters(parameters);

%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;




%****************** Definitions for the pulse definition  ***********************%
initializepulseparameters
fxpa1=fxpa;
fxpa1.carrierrabi=fxpa.carrierrabi*1.07;
fxpa1.sbcarrierrabi=fxpa.sbcarrierrabi*1.07;
fxpa1.piover2time=fxpa.piover2time/1.07;
fxpa2=fxpa;
%*****************************************************************************%



%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fxpa,starttime)
%  Rblue(theta,phi,ion,transition,fxpa,starttime)


p = p + 1;[pulse(p),time] = Rcar(1,0,2,1,fxpa2,time+(10)*delayunit); 
p = p + 1;[pulse(p),time] = Rcar(1,0,1,1,fxpa2,time+(75-20)*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(1,0,1,1,fxpa1,time+(99-75-19-21)*delayunit); 

p = p + 1;[pulse(p),time] = Rcar(0.5,0,2,1,fxpa2,time+(16)*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa2,time+4*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,2,1,fxpa2,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1,0,2,1,fxpa2,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0.5,2,1,fxpa2,time+0*delayunit); 
p = p + 1;[pulse(p),time] = Rcar(0.5,1,2,1,fxpa2,time+(2)*delayunit); 

p = p + 1;[pulse(p),time] = Rblue(1,1,1,1,fxpa1,time+1*delayunit); 
%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
T=T-100;
displaypopulations(T,Y,[0 0; 1 0; 0 1; 1 1;],hspace);
setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
figure(11);
clf;
[YTP]=tracedpopulations(T,Y,hspace);
hold on;
plo1=plot(T,YTP(:,1),'b');
plo2=plot(T,YTP(:,2),'g');
ax=get(gcf,'CurrentAxes');;
set(ax,'LineWidth',1.5)
set(ax,'FontSize',12);
set(ax,'Box','on')

set(plo1,'LineWidth',1.5)
set(plo2,'LineWidth',1.5)

dat=read_data('p:\auswertungen\CZ_14Nov2002\esc0657.txt',3);
p1=plot(dat(1,:)-100,dat(2,:),'b.');
p2=plot(dat(1,:)-100,dat(3,:),'g.');
set(p1,'LineWidth',1.5)
set(p1,'MarkerSize',14)
set(p2,'LineWidth',1.5)
set(p2,'MarkerSize',14)

pop1=mean(dat(2,1:8));
err1=std(dat(2,1:8))/8;
pop2=mean(dat(3,1:8));
err2=std(dat(3,1:8))/8;

clear s;
s(1,:)=sprintf('P_{Ion1} = %1.3f (%1.3f)',pop1,err1);
%te=text(300,0.8,s);
%set(te,'FontSize',12);

s(3,:)=sprintf('P_{Ion2} = %1.3f (%1.3f)',pop2,err2);
te=text(300,0.25,s);
set(te,'FontSize',12);
%set(te,'Box','on')



%displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;

print -depsc2 cnotdd