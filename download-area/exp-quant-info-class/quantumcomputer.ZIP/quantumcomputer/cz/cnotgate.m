% simulates the population evolution with experimental imperfections
% requires the scripts in qctools
% Date:   03-Sep-02
% Author: Hartmut H�fner <hartmut.haeffner@uibk.ac.at
%
% type <edit simulate> to specify the parameters directly in the script
% 

clear T;
clear Y;
clear pulse;

parameters=standardparameters; 
%****************** Changes to the standardparameters  ***********************%
parameters.recoilangle=68;
parameters.omegaz=2*pi*2*1050000;
parameters.hspace=definehspace(2,2,2);
parameters.omegacarrier=2*pi/42*1e6;
% parameters.nolightshift=0;

parameters=recalculateparameters(parameters);  % to get eta!
parameters.sbomegacarrier=2*pi/211*1e6./parameters.eta;
%*****************************************************************************%
parameters=recalculateparameters(parameters);
initializepulseparameters;


%****************    Start population         ****************************%
parameters.y0(index(0,[0 0],parameters.hspace))=1;

%****************** Pulse definition  ***********************%
%  Rcar(theta,phi,ion,transition,fp,time)
%  Rblue(theta,phi,ion,transition,fp,time)


p = p + 1;[pulse(p),time] = Rcar(0.5,0,1,1,fxpa,225*delayunit);
time+5*delayunit
p = p + 1;[pulse(p),time] = Rblue(1,0.5,1,1,fxpa,time+5*delayunit); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rblue(1,0.5,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rblue(1/sqrt(2),0,1,1,fxpa,time); 
p = p + 1;[pulse(p),time] = Rcar(0.5,1,1,1,fxpa,time+15*delayunit);

%*****************************************************************************%

%****************** And ... here we go ...  ***********************%
[T,Y]=simulateevolution(pulse,parameters);
T=T*fs;
displaypopulations(T,Y,[0 0; 1 0;],hspace);
setstatevisibility(1,hspace);
endpopulations(T,Y,hspace);
tracedpopulations(T,Y,hspace,1);
displaypmsignal(T,Y,hspace);
hold on;
%*****************************************************************************%
closemessagewindow;

dat=read_data('p:\daten\20021106\qf0739',3);
plot(dat(1,:),dat(2,:),'k.');

mean(dat(2,1:8))
std(dat(2,1:8))/8
