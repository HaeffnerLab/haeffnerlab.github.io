
x=lsode("diffeq",[1 0 0 0 0 0],(t=linspace(0,10,500)'));

X=x(:,1:3)+i*x(:,4:6);
plot(t,abs(X).^2)
