function xdot = diffeq(x,t)

	Om=0.01;
	oma12=10;
	oma13=11;
	om=10;
	
	xnew=x(1:3)+i*x(4:6);
	A=[	0 				 i*Om*cos(om*t)*exp(i*oma12*t)  i*Om*cos(om*t)*exp(i*oma13*t); 
	  	i*Om*cos(om*t)*exp(-i*oma12*t) 0 				   0;
		i*Om*cos(om*t)*exp(-i*oma13*t) 0  0];
#	A=0.5*[	0 				 i*Om*exp(-i*om*t)*exp(i*oma12*t)  i*Om*exp(-i*om*t)*exp(i*oma13*t); 
#	  	i*Om*exp(i*om*t)*exp(-i*oma12*t) 0 				   0;
#		i*Om*exp(i*om*t)*exp(-i*oma13*t) 0  0];

	temp=A*xnew;
	xdot(1:3)=real(temp);
	xdot(4:6)=imag(temp);
endfunction

