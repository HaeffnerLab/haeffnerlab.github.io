clear
nbar=10;
om=2*pi*1/sqrt(nbar);
t=[0:0.1:10];
n=[1:3*nbar];

for(j=1:length(t))
	exc(j)=exp(-nbar)*sum(nbar.^n./factorial(n).*cos(om*t(j)*sqrt(n+1)));
end;

plot(t,exc)

