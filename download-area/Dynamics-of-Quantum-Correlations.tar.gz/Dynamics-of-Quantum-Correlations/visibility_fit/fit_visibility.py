import numpy as np
from scipy.misc import comb
import math
import matplotlib.pyplot as plt

def binomial_dist(k, n, p):
    return comb(n, k)*(p**k)*(1-p)**(n-k)

def log_likelihood(params, p_measured, theta, n):
    '''
    fringe visibility is defined as
    v = amplitude/mean
    
    the data should go as (c/2)(1 + sin(theta + phi)) + b
    amplitude = (c/2)
    mean = (c/2) + b so 
    v = (c/2)/((c/2) + b) which we rearrange as
    c = -2*b*v/(v - 1) so
    (c/2)(1 + sin(theta + phi)) + b ==
    
    b*v/(1-v)(1 + sin(theta + phi)) + b
    
    '''

    V, phi, b = params
    p = b*V/(1 - V)*(1 + np.sin(theta + phi)) + b
    log_likelihood = 0
    p_measured = np.array(p_measured)
    lkhood = np.sum(np.log(binomial_dist( (n*p_measured).round(), n, p)))
    if np.isnan(lkhood): return -np.inf
    if np.isinf(lkhood): return -np.inf
    else: return lkhood

def log_prior(params):
    # restrict the amplitude of the oscillation to 1
    V, phi, b = params
    c = -2*b*V/(V - 1)
    if c < 1e-6 or c > 1:
        return -np.inf
    elif b < 0 or b > 1:
        return -np.inf
    elif c + b > 1:
        return -np.inf
    else:
        return 0
def log_posterior(params, p_measured, theta, n):
    return log_prior(params) + log_likelihood(params, p_measured, theta, n)

def posterior(params, p_measured, theta, n):
    return np.exp(log_posterior(params, p_measured, theta, n))

def marginalized_posterior(p_measured, theta, regions_to_sample, n):
    V_grid, phi_grid, b_grid = regions_to_sample
    posterior_grid = np.zeros([len(V_grid), len(phi_grid), len(b_grid)])
    for i, v in enumerate(V_grid):
        for j, p in enumerate(phi_grid):
            for k, b in enumerate(b_grid):
                posterior_grid[i][j][k] = posterior([v, p, b], p_measured, theta, n)
                if math.isnan(posterior_grid[i][j][k]): posterior_grid[i][j][k] = 0.

    # posterior distribution in each parameter
    marginalized_posterior = [np.sum(posterior_grid,axis=(1,2)), np.sum(posterior_grid,axis=(0,2)), np.sum(posterior_grid,axis=(0,1))]
    marginalized_posterior = [post/sum(post) for post in marginalized_posterior] # normalize
    return marginalized_posterior

def fine_grain(marginals, grids, grain_size = 30, cutoff = 1e-3):
    v, p, b = grids
    bin_size = v[1] - v[0]
    clips = [np.where( marginal >= cutoff*np.max(marginal))[0] for marginal in marginals]
    # This looks complicated. What it does:
    # evaluate each grid region (V, phi, b) at the endpoints of the clips, and add half a bin on each side
    # then return the values
    roi = [ grid[[clp[0], clp[-1]]] + [-bin_size/2, bin_size/2] for clp, grid in zip(clips, [v, p, b]) ]
    vf, pf, bf = [np.linspace(mn, mx, grain_size) for mn, mx in roi]
    return vf, pf, bf

def generate_errorbars(p_measured, theta, n = 100, plotting = False):
    # first do a coarse pass
    bin_size = 0.03
    cutoff = 1e-3
    v, p, b = np.arange(0., 1., bin_size), np.arange(0, 2*np.pi, bin_size), np.arange(0., 1., bin_size)
    marginals_coarse = marginalized_posterior(p_measured, theta, [v, p, b], n)
    # now do a finer pass
    vf, pf, bf = fine_grain(marginals_coarse, [v, p, b], grain_size = 30)
    marginals = marginalized_posterior(p_measured, theta, [vf, pf, bf], n)
    try:
        cumdist = [ np.cumsum(marginals[0]), np.cumsum(marginals[1]) ]
        vcr, pcr = [np.where((cd>.05)&(cd<0.95))[0] for cd in cumdist] # credible regions for vis. and phase
        vmin, vmax = vcr[0], vcr[-1]
        pmin, pmax = pcr[0], pcr[-1]
    
    except IndexError: # this means we haven't fine grained enough probably.
        print "regraining"
        vf, pf, bf = fine_grain(marginals, [vf, pf, bf], grain_size = 60)
        marginals = marginalized_posterior(p_measured, theta, [vf, pf, bf], n)
        cumdist = [ np.cumsum(marginals[0]), np.cumsum(marginals[1]) ]
        vcr, pcr = [np.where((cd>.05)&(cd<0.95))[0] for cd in cumdist] # credible regions for vis. and phase
        vmin, vmax = vcr[0], vcr[-1]
        pmin, pmax = pcr[0], pcr[-1]

    v_dist, p_dist, b_dist = marginals
    if not plotting:
        output = [ [vf[np.where(v_dist == np.max(v_dist))][0], (vf[vmin], vf[vmax])],
                   [pf[np.where(p_dist == np.max(p_dist))][0], (pf[pmin], pf[pmax])]]

    else:
        output = [vf[np.where(v_dist == np.max(v_dist))][0], pf[np.where(p_dist == np.max(p_dist))][0], bf[np.where(b_dist == np.max(b_dist))][0]]
        vm, pm, bm = output
        model = lambda t: bm*vm/(1-vm)*(1 + np.sin(t + pm)) + bm
        tr = np.linspace(0, 2*np.pi, 60)
        plt.plot(theta, p_measured, 'o')
        plt.plot(tr, model(tr))
        plt.show()
    return output    
