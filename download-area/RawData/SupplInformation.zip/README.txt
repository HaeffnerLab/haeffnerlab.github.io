The following files contain the real and imaginary parts of the 4-,5-,6-,7-
and 8-ion density matrices as indicated by the file name. 
The first element of each file corresponds to the real (imaginary) part of 
<DD...D|rho|DD...D>.

In addition, the files <WitnessN8_filter.real> (<WitnessN8_filter.imag>) contain
the real (imaginary) part of the entanglement witness used for detecting 8-ion
entanglement.